"use client";

import React, { useState, useEffect, useRef } from "react";
import * as pdfjsLib from "pdfjs-dist";
import PDFPage from "./PDFPage";

pdfjsLib.GlobalWorkerOptions.workerSrc = "/pdf.worker.js";

const DEFAULT_SCALE = 1.5;
const SCALE_STEP = 0.1;
const MIN_SCALE = 0.1;

const PDFViewer = ({ pdfUrl }) => {
  const [pdf, setPdf] = useState(null);
  const [numPages, setNumPages] = useState(0);
  const [pageDimensions, setPageDimensions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [currentPage, setCurrentPage] = useState(1);
  const [pageInput, setPageInput] = useState("1");
  const [pagesToRender, setPagesToRender] = useState(5);
  const [scale, setScale] = useState(DEFAULT_SCALE);
  const [highlightMode, setHighlightMode] = useState(false);
  const [privateInfoMode, setPrivateInfoMode] = useState(false);
  const [imageMode, setImageMode] = useState(false); // image annotation mode
  const [highlightColor, setHighlightColor] = useState("#FFFF00");
  const [texts, setTexts] = useState({}); // Text annotations per page
  const [textMode, setTextMode] = useState(false); // Track text annotation mode

  // Data stored per page.
  const [highlights, setHighlights] = useState({});
  const [privateInfos, setPrivateInfos] = useState({});
  const [images, setImages] = useState({}); // image annotations per page
  const sentinelRef = useRef(null);
  const contentRef = useRef(null);
  const ignoreScrollRef = useRef(false);
  const pinchStartDistanceRef = useRef(null);
  const pinchStartScaleRef = useRef(null);

  // New: state to hold the imported image data URL.
  const [imageSrc, setImageSrc] = useState("");

  // State to hold a target page that needs scrolling after rendering.
  const [targetPage, setTargetPage] = useState(null);

  const [drawingText, setDrawingText] = useState(null); // for new text annotations
  const [activeTextIndex, setActiveTextIndex] = useState(null); // Active text index
  const [textInput, setTextInput] = useState(""); // input for text annotation

  // Load the PDF document.
  useEffect(() => {
    setLoading(true);
    pdfjsLib
      .getDocument(pdfUrl)
      .promise.then((pdfDoc) => {
        setPdf(pdfDoc);
        setNumPages(pdfDoc.numPages);
        setLoading(false);
      })
      .catch((error) => {
        console.error("Error loading PDF:", error);
        setLoading(false);
      });
  }, [pdfUrl]);

  // Pre-fetch page dimensions.
  useEffect(() => {
    if (pdf && numPages > 0) {
      let cancelled = false;
      const promises = [];
      for (let i = 1; i <= numPages; i++) {
        promises.push(
          pdf.getPage(i).then((page) => {
            const viewport = page.getViewport({ scale });
            return viewport.height;
          })
        );
      }
      Promise.all(promises).then((heights) => {
        if (!cancelled) setPageDimensions(heights);
      });
      return () => {
        cancelled = true;
      };
    }
  }, [pdf, numPages, scale]);

  // Automatically add an image annotation when an image is imported.
  useEffect(() => {
    if (imageSrc) {
      // Add the image to the current page with a default rectangle.
      // (Normalized: x=0.1, y=0.1, width=0.3, height=0.3)
      handleAddImage(currentPage, {
        x: 0.1,
        y: 0.1,
        width: 0.3,
        height: 0.3,
        src: imageSrc,
      });
      setImageSrc(""); // Reset after adding
    }
  }, [imageSrc, currentPage]);

  // --- Navigation Functions ---
  const scrollToPage = (page, instant = false) => {
    const pageElement = document.getElementById(`page-${page}`);
    if (pageElement && contentRef.current) {
      const containerRect = contentRef.current.getBoundingClientRect();
      const elementRect = pageElement.getBoundingClientRect();
      const offset = elementRect.top - containerRect.top;
      contentRef.current.scrollTo({
        top: contentRef.current.scrollTop + offset,
        behavior: instant ? "auto" : "smooth",
      });
      ignoreScrollRef.current = true;
      setTimeout(() => {
        ignoreScrollRef.current = false;
      }, 500);
      setCurrentPage(page);
      setPageInput(page.toString());
    }
  };

  const goToPage = (page, instant = false) => {
    if (page < 1 || page > numPages) return;
    if (page > pagesToRender) {
      setPagesToRender(page);
      setTargetPage({ page, instant });
    } else {
      scrollToPage(page, instant);
    }
  };

  const handlePrevious = () => {
    if (currentPage > 1) goToPage(currentPage - 1);
  };

  const handleNext = () => {
    if (currentPage < numPages) goToPage(currentPage + 1);
  };

  const handleGoToPage = () => {
    const page = Number(pageInput);
    if (!isNaN(page)) goToPage(page, true);
  };

  const handleZoomIn = () => setScale((prev) => prev + SCALE_STEP);
  const handleZoomOut = () =>
    setScale((prev) => Math.max(MIN_SCALE, prev - SCALE_STEP));

  // --- Mode Toggles ---
  const toggleHighlightMode = () => {
    setHighlightMode((prev) => !prev);
    // Turn off the other modes
    if (privateInfoMode) setPrivateInfoMode(false);
    if (imageMode) setImageMode(false);
    if (textMode) setTextMode(false);
  };

  const togglePrivateInfoMode = () => {
    setPrivateInfoMode((prev) => !prev);
    // Turn off the other modes
    if (highlightMode) setHighlightMode(false);
    if (imageMode) setImageMode(false);
    if (textMode) setTextMode(false);
  };

  const toggleImageMode = () => {
    setImageMode((prev) => !prev);
    // Turn off the other modes
    if (highlightMode) setHighlightMode(false);
    if (privateInfoMode) setPrivateInfoMode(false);
    if (textMode) setTextMode(false);
  };

  const toggleTextMode = () => {
    setTextMode((prev) => !prev);
    // Turn off the other modes
    if (highlightMode) setHighlightMode(false);
    if (privateInfoMode) setPrivateInfoMode(false);
    if (imageMode) setImageMode(false);
  };
  
  // --- Handlers for Highlights ---
  const handleAddHighlight = (pageNumber, highlightRect) => {
    setHighlights((prev) => {
      const pageHighlights = prev[pageNumber] || [];
      return { ...prev, [pageNumber]: [...pageHighlights, highlightRect] };
    });
  };

  const handleRemoveHighlight = (pageNumber, indexToRemove) => {
    setHighlights((prev) => {
      const pageHighlights = prev[pageNumber] || [];
      return {
        ...prev,
        [pageNumber]: pageHighlights.filter((_, idx) => idx !== indexToRemove),
      };
    });
  };

  const handleUpdateHighlight = (pageNumber, indexToUpdate, newData) => {
    setHighlights((prev) => {
      const pageHighlights = prev[pageNumber] || [];
      const updatedHighlights = pageHighlights.map((hl, idx) =>
        idx === indexToUpdate ? { ...hl, ...newData } : hl
      );
      return { ...prev, [pageNumber]: updatedHighlights };
    });
  };

  // --- Handlers for Private Info Boxes ---
  const handleAddPrivateInfo = (pageNumber, boxRect) => {
    setPrivateInfos((prev) => {
      const pageBoxes = prev[pageNumber] || [];
      return { ...prev, [pageNumber]: [...pageBoxes, boxRect] };
    });
  };

  const handleRemovePrivateInfo = (pageNumber, indexToRemove) => {
    setPrivateInfos((prev) => {
      const pageBoxes = prev[pageNumber] || [];
      return {
        ...prev,
        [pageNumber]: pageBoxes.filter((_, idx) => idx !== indexToRemove),
      };
    });
  };

  const handleUpdatePrivateInfo = (pageNumber, indexToUpdate, newRect) => {
    setPrivateInfos((prev) => {
      const pageBoxes = prev[pageNumber] || [];
      const updatedBoxes = pageBoxes.map((box, idx) =>
        idx === indexToUpdate ? { ...box, ...newRect } : box
      );
      return { ...prev, [pageNumber]: updatedBoxes };
    });
  };

  // --- Handlers for Image Annotations (NEW) ---
  const handleAddImage = (pageNumber, imageRect) => {
    setImages((prev) => {
      const pageImages = prev[pageNumber] || [];
      return { ...prev, [pageNumber]: [...pageImages, imageRect] };
    });
  };

  const handleRemoveImage = (pageNumber, indexToRemove) => {
    setImages((prev) => {
      const pageImages = prev[pageNumber] || [];
      return {
        ...prev,
        [pageNumber]: pageImages.filter((_, idx) => idx !== indexToRemove),
      };
    });
  };

  const handleUpdateImage = (pageNumber, indexToUpdate, newRect) => {
    setImages((prev) => {
      const pageImages = prev[pageNumber] || [];
      const updatedImages = pageImages.map((img, idx) =>
        idx === indexToUpdate ? { ...img, ...newRect } : img
      );
      return { ...prev, [pageNumber]: updatedImages };
    });
  };

  // --- Handler for Text Annotations ---
  const handleAddText = (pageNumber, textData) => {
    setTexts((prev) => {
      const pageTexts = prev[pageNumber] || [];
      return { ...prev, [pageNumber]: [...pageTexts, textData] };
    });
  };

  const handleUpdateText = (pageNumber, indexToUpdate, newTextData) => {
    setTexts((prev) => {
      const pageTexts = prev[pageNumber] || [];
      const updatedTexts = pageTexts.map((text, idx) =>
        idx === indexToUpdate ? { ...text, ...newTextData } : text
      );
      return { ...prev, [pageNumber]: updatedTexts };
    });
  };

  // Add this function to remove the text annotation
  const handleRemoveText = (pageNumber, textIndex) => {
    // Remove the text annotation based on the page number and text index
    setTexts((prevTexts) => {
      const pageTexts = prevTexts[pageNumber] || [];
      return {
        ...prevTexts,
        [pageNumber]: pageTexts.filter((_, idx) => idx !== textIndex),
      };
    });
  };

  // --- Update Current Page Based on Scrolling ---
  useEffect(() => {
    const container = contentRef.current;
    if (!container) return;
    const handleScroll = () => {
      if (ignoreScrollRef.current) return;
      const pages = container.querySelectorAll("[id^='page-']");
      let bestPageNumber = null;
      let maxVisible = 0;
      pages.forEach((page) => {
        const rect = page.getBoundingClientRect();
        const containerRect = container.getBoundingClientRect();
        const visibleHeight = Math.max(
          0,
          Math.min(rect.bottom, containerRect.bottom) -
            Math.max(rect.top, containerRect.top)
        );
        const pageNumber = parseInt(page.id.replace("page-", ""), 10);
        if (visibleHeight > maxVisible) {
          maxVisible = visibleHeight;
          bestPageNumber = pageNumber;
        }
      });
      if (bestPageNumber !== null) {
        setCurrentPage((prev) => {
          if (bestPageNumber !== prev) {
            setPageInput(bestPageNumber.toString());
            return bestPageNumber;
          }
          return prev;
        });
      }
    };
    container.addEventListener("scroll", handleScroll);
    return () => container.removeEventListener("scroll", handleScroll);
  }, []);

  // When pagesToRender updates, check if there is a pending target page to scroll to.
  useEffect(() => {
    if (targetPage) {
      const timeout = setTimeout(() => {
        scrollToPage(targetPage.page, targetPage.instant);
        setTargetPage(null);
      }, 100);
      return () => clearTimeout(timeout);
    }
  }, [pagesToRender, targetPage]);

  // --- Lazy-Load More Pages When Scrolling Near the End ---
  useEffect(() => {
    if (!loading && pdf && pagesToRender < numPages && sentinelRef.current) {
      const observer = new IntersectionObserver(
        (entries) => {
          entries.forEach((entry) => {
            if (entry.isIntersecting) {
              setPagesToRender((prev) => Math.min(prev + 5, numPages));
            }
          });
        },
        { threshold: 0.1 }
      );
      observer.observe(sentinelRef.current);
      return () => observer.disconnect();
    }
  }, [loading, pdf, pagesToRender, numPages]);

  // --- Zoom Handling via Mouse Wheel (with Ctrl key) ---
  useEffect(() => {
    const container = contentRef.current;
    if (!container) return;
    let lastCall = 0;
    const handleWheel = (event) => {
      if (event.ctrlKey) {
        event.preventDefault();
        const now = Date.now();
        if (now - lastCall < 50) return;
        lastCall = now;
        const zoomSensitivity = 0.002;
        setScale((prevScale) =>
          Math.max(MIN_SCALE, prevScale - event.deltaY * zoomSensitivity)
        );
      }
    };
    container.addEventListener("wheel", handleWheel, { passive: false });
    return () => container.removeEventListener("wheel", handleWheel);
  }, []);

  // --- Pinch-to-Zoom Handling on Touch Devices ---
  useEffect(() => {
    const container = contentRef.current;
    if (!container) return;
    const handleTouchStart = (e) => {
      if (e.touches.length === 2) {
        const dx = e.touches[0].clientX - e.touches[1].clientX;
        const dy = e.touches[0].clientY - e.touches[1].clientY;
        const distance = Math.hypot(dx, dy);
        pinchStartDistanceRef.current = distance;
        pinchStartScaleRef.current = scale;
      }
    };
    const handleTouchMove = (e) => {
      if (e.touches.length === 2 && pinchStartDistanceRef.current) {
        e.preventDefault();
        const dx = e.touches[0].clientX - e.touches[1].clientX;
        const dy = e.touches[0].clientY - e.touches[1].clientY;
        const currentDistance = Math.hypot(dx, dy);
        const pinchRatio = currentDistance / pinchStartDistanceRef.current;
        const TOUCH_SENSITIVITY = 0.8;
        const adjustedRatio = 1 + (pinchRatio - 1) * TOUCH_SENSITIVITY;
        const newScale = Math.max(
          MIN_SCALE,
          pinchStartScaleRef.current * adjustedRatio
        );
        setScale(newScale);
      }
    };
    const handleTouchEnd = (e) => {
      if (e.touches.length < 2) {
        pinchStartDistanceRef.current = null;
        pinchStartScaleRef.current = null;
      }
    };
    container.addEventListener("touchstart", handleTouchStart, {
      passive: false,
    });
    container.addEventListener("touchmove", handleTouchMove, {
      passive: false,
    });
    container.addEventListener("touchend", handleTouchEnd, { passive: false });
    container.addEventListener("touchcancel", handleTouchEnd, {
      passive: false,
    });
    return () => {
      container.removeEventListener("touchstart", handleTouchStart);
      container.removeEventListener("touchmove", handleTouchMove);
      container.removeEventListener("touchend", handleTouchEnd);
      container.removeEventListener("touchcancel", handleTouchEnd);
    };
  }, [scale]);

  // --- Handler for Importing Image (NEW) ---
  const handleImageFileChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setImageSrc(reader.result);
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <div style={{ fontFamily: "Arial, sans-serif" }}>
      {/* Fixed Navigation Controls */}
      {!loading && numPages > 0 && (
        <div
          style={{
            position: "fixed",
            top: 0,
            left: 0,
            right: 0,
            padding: "10px 20px",
            backgroundColor: "black",
            color: "white",
            boxShadow: "0 2px 5px rgba(0,0,0,0.3)",
            zIndex: 1000,
            textAlign: "center",
            display: "flex",
            flexWrap: "wrap",
            alignItems: "center",
            justifyContent: "center",
            gap: "10px",
            overflowX: "auto",
          }}
        >
          <button onClick={handlePrevious} disabled={currentPage <= 1}>
            Previous
          </button>
          <span>
            Page {currentPage} of {numPages}
          </span>
          <button onClick={handleNext} disabled={currentPage >= numPages}>
            Next
          </button>
          <span>
            Go to page:{" "}
            <input
              type="number"
              min="1"
              max={numPages}
              value={pageInput}
              onChange={(e) => setPageInput(e.target.value)}
              style={{ width: "50px", color: "black" }}
            />
            <button onClick={handleGoToPage}>Go</button>
          </span>
          <span>
            <button onClick={handleZoomOut} disabled={scale <= MIN_SCALE}>
              Zoom Out
            </button>
            <span style={{ margin: "0 5px" }}>{(scale * 100).toFixed(0)}%</span>
            <button onClick={handleZoomIn}>Zoom In</button>
          </span>
          <span>
            <button
              onClick={toggleHighlightMode}
              style={{
                backgroundColor: highlightMode ? "yellow" : "white",
                color: "black",
              }}
            >
              {highlightMode ? "Exit Highlight" : "Highlight"}
            </button>
          </span>
          <span>
            <button
              onClick={togglePrivateInfoMode}
              style={{
                backgroundColor: privateInfoMode ? "gray" : "white",
                color: "black",
              }}
            >
              {privateInfoMode ? "Exit Private Info" : "Private Info"}
            </button>
          </span>
          <span>
            <button
              onClick={toggleImageMode}
              style={{
                backgroundColor: imageMode ? "#ADD8E6" : "white",
                color: "black",
              }}
            >
              {imageMode ? "Exit Image" : "Image Annotation"}
            </button>
          </span>
          {imageMode && (
            <span>
              <label htmlFor="image-file">Import Image: </label>
              <input
                id="image-file"
                type="file"
                accept="image/*"
                onChange={handleImageFileChange}
              />
            </span>
          )}
          <span>
            <button
              onClick={toggleTextMode}
              style={{
                backgroundColor: textMode ? "#90EE90" : "white",
                color: "black",
              }}
            >
              {textMode ? "Exit Text" : "Text Annotation"}
            </button>
          </span>

          <span>
            <label htmlFor="highlight-color">Highlight Color: </label>
            <select
              id="highlight-color"
              style={{ color: "black" }}
              value={highlightColor}
              onChange={(e) => setHighlightColor(e.target.value)}
            >
              <option value="#FFFF00">Yellow</option>
              <option value="#00FF00">Green</option>
              <option value="#0000FF">Blue</option>
              <option value="#FFC0CB">Pink</option>
              <option value="#FFA500">Orange</option>
            </select>
          </span>
        </div>
      )}

      {/* Main Content Container */}
      <div
        ref={contentRef}
        style={{
          height: "calc(100vh - 70px)",
          overflowY: "auto",
          padding: "20px",
          marginTop: "50px",
          display: "flex",
          flexDirection: "column",
          touchAction: "pan-x pan-y",
        }}
      >
        {loading && <p>Loading PDF...</p>}
        {!loading &&
          pdf &&
          Array.from(
            { length: Math.min(pagesToRender, numPages) },
            (_, index) => (
              <PDFPage
                key={index}
                pdf={pdf}
                pageNumber={index + 1}
                scale={scale}
                estimatedHeight={pageDimensions[index]}
                highlightMode={highlightMode}
                privateInfoMode={privateInfoMode}
                imageMode={imageMode} // new
                highlights={highlights[index + 1] || []}
                privateInfos={privateInfos[index + 1] || []}
                images={images[index + 1] || []} // new
                onAddHighlight={handleAddHighlight}
                onRemoveHighlight={handleRemoveHighlight}
                onUpdateHighlight={handleUpdateHighlight}
                onAddPrivateInfo={handleAddPrivateInfo}
                onRemovePrivateInfo={handleRemovePrivateInfo}
                onUpdatePrivateInfo={handleUpdatePrivateInfo}
                onAddImage={handleAddImage} // new
                onRemoveImage={handleRemoveImage} // new
                onUpdateImage={handleUpdateImage} // new
                highlightColor={highlightColor}
                imageSrc={imageSrc} // new
                texts={texts[index + 1] || []}
                textMode={textMode}
                onAddText={handleAddText}
                onUpdateText={handleUpdateText}
                onRemoveText={handleRemoveText} // Pass the function as a prop
              />
            )
          )}
        {!loading && pdf && pagesToRender < numPages && (
          <div ref={sentinelRef} style={{ height: "20px" }}></div>
        )}
      </div>
    </div>
  );
};

export default PDFViewer;
