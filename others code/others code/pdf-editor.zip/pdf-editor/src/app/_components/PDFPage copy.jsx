"use client";

import React, { useState, useEffect, useRef, useCallback } from "react";
import * as pdfjsLib from "pdfjs-dist";

// Set the PDF.js worker source – ensure pdf.worker.js is in your public/ folder.
pdfjsLib.GlobalWorkerOptions.workerSrc = "/pdf.worker.js";

// Fixed render scale for PDF.js (pages are rendered once at this scale)
const DEFAULT_SCALE = 1.5;
// Default font size for text annotations.
const DEFAULT_FONT_SIZE = 14;

// Long-press constants for mobile (touch events)
const LONG_PRESS_DURATION = 300; // milliseconds before long press is detected
const MOVE_THRESHOLD = 10; // maximum movement (in pixels) allowed before canceling long press

/**
 * computeNewAnnotation
 *
 * Given an original normalized annotation {x, y, width, height}, normalized
 * delta changes (ndx, ndy), and a handle direction (one of "nw", "n", "ne", "e",
 * "se", "s", "sw", "w"), compute a new annotation.
 */
function computeNewAnnotation(original, ndx, ndy, direction) {
  let newX = original.x;
  let newY = original.y;
  let newWidth = original.width;
  let newHeight = original.height;

  switch (direction) {
    case "nw":
      newX = original.x + ndx;
      newY = original.y + ndy;
      newWidth = original.width - ndx;
      newHeight = original.height - ndy;
      break;
    case "n":
      newY = original.y + ndy;
      newHeight = original.height - ndy;
      break;
    case "ne":
      newY = original.y + ndy;
      newWidth = original.width + ndx;
      newHeight = original.height - ndy;
      break;
    case "e":
      newWidth = original.width + ndx;
      break;
    case "se":
      newWidth = original.width + ndx;
      newHeight = original.height + ndy;
      break;
    case "s":
      newHeight = original.height + ndy;
      break;
    case "sw":
      newX = original.x + ndx;
      newWidth = original.width - ndx;
      newHeight = original.height + ndy;
      break;
    case "w":
      newX = original.x + ndx;
      newWidth = original.width - ndx;
      break;
    default:
      break;
  }

  // Enforce a minimum size.
  const minSize = 0.05;
  if (newWidth < minSize) {
    newWidth = minSize;
    if (["nw", "w", "sw"].includes(direction)) {
      newX = original.x + original.width - minSize;
    }
  }
  if (newHeight < minSize) {
    newHeight = minSize;
    if (["nw", "n", "ne"].includes(direction)) {
      newY = original.y + original.height - minSize;
    }
  }

  // Clamp to boundaries (0 to 1)
  newX = Math.max(0, newX);
  newY = Math.max(0, newY);
  if (newX + newWidth > 1) {
    newWidth = 1 - newX;
  }
  if (newY + newHeight > 1) {
    newHeight = 1 - newY;
  }

  return { x: newX, y: newY, width: newWidth, height: newHeight };
}

/**
 * PDFPage Component
 *
 * Renders a PDF page on a canvas and overlays several kinds of annotations:
 * - Highlights
 * - Private info boxes (redact)
 * - Image annotations
 * - **Text annotations**
 *
 * When textMode is enabled the following text annotation functionality is active:
 * - Clicking (or tapping) on an empty part of the page adds a new text annotation and immediately
 *   activates its textarea (with a blinking I‑beam cursor).
 * - The textarea is initially one row tall and auto-resizes so that its height (and width)
 *   is not fixed.
 * - When not editing, text annotations are draggable and their hover cursor is set to "move".
 * - Double‑clicking an annotation enters edit mode.
 *
 * Additionally, if the user creates a new text annotation while a previously added one remains empty,
 * the previous empty annotation is removed before adding the new one.
 *
 * Now the user can also change the font size for each text annotation.
 */
const PDFPage = ({
  pdf,
  pageNumber,
  scale = DEFAULT_SCALE,
  estimatedHeight,
  // Modes:
  highlightMode = false,
  privateInfoMode = false,
  imageMode = false,
  textMode = false,
  // Annotation arrays:
  highlights = [],
  privateInfos = [],
  images = [],
  texts = [],
  // Callbacks for highlights:
  onAddHighlight = () => {},
  onRemoveHighlight = () => {},
  onUpdateHighlight = () => {},
  // Callbacks for private info boxes:
  onAddPrivateInfo = () => {},
  onRemovePrivateInfo = () => {},
  onUpdatePrivateInfo = () => {},
  // Callbacks for image annotations:
  onAddImage = () => {},
  onRemoveImage = () => {},
  onUpdateImage = () => {},
  // Callbacks for text annotations:
  onAddText = () => {},
  onRemoveText = () => {},
  onUpdateText = () => {},
  // Colors and image source:
  highlightColor = "#FFFF00",
  imageSrc = "",
}) => {
  const containerRef = useRef(null);
  const canvasRef = useRef(null);

  // Refs for long-press detection (touch events)
  const longPressTimerRef = useRef(null);
  const initialTouchRef = useRef({ x: 0, y: 0 });
  const privateLongPressTimerRef = useRef(null);
  const highlightLongPressTimerRef = useRef(null);
  const imageLongPressTimerRef = useRef(null);
  const textLongPressTimerRef = useRef(null);

  // Resizing state and refs for each annotation type
  const [resizingImageIndex, setResizingImageIndex] = useState(null);
  const resizingImageDataRef = useRef(null);

  const [resizingHighlightIndex, setResizingHighlightIndex] = useState(null);
  const resizingHighlightDataRef = useRef(null);

  const [resizingPrivateIndex, setResizingPrivateIndex] = useState(null);
  const resizingPrivateDataRef = useRef(null);

  // State for text annotation dragging and editing
  const [draggingTextIndex, setDraggingTextIndex] = useState(null);
  const [dragTextOffset, setDragTextOffset] = useState({ x: 0, y: 0 });
  const [activeTextIndex, setActiveTextIndex] = useState(null);
  const [editingTextIndex, setEditingTextIndex] = useState(null);

  // Other state: dragging, drawing, active indices, canvas dimensions, etc.
  const [canvasDimensions, setCanvasDimensions] = useState({
    width: 1,
    height: 1,
  });
  const [isVisible, setIsVisible] = useState(false);
  const [loaded, setLoaded] = useState(false);
  const renderTaskRef = useRef(null);

  // For highlights and private info, we keep drawing states.
  const [drawingRect, setDrawingRect] = useState(null); // for new highlights
  const [drawingPrivate, setDrawingPrivate] = useState(null); // for new private info boxes
  // Removed drawingText state because text is now added immediately.
  const [drawingImage, setDrawingImage] = useState(null); // for new image annotations

  const [draggingPrivateIndex, setDraggingPrivateIndex] = useState(null);
  const [dragOffset, setDragOffset] = useState({ x: 0, y: 0 });
  const [draggingHighlightIndex, setDraggingHighlightIndex] = useState(null);
  const [dragHighlightOffset, setDragHighlightOffset] = useState({
    x: 0,
    y: 0,
  });
  const [draggingImageIndex, setDraggingImageIndex] = useState(null);
  const [dragImageOffset, setDragImageOffset] = useState({ x: 0, y: 0 });

  const [activeHighlightIndex, setActiveHighlightIndex] = useState(null);
  const [activePrivateIndex, setActivePrivateIndex] = useState(null);
  const [activeImageIndex, setActiveImageIndex] = useState(null);

  // Helper: convert hex color to rgba string.
  const hexToRgba = (hex, alpha = 0.3) => {
    if (!hex) return `rgba(255,255,0,${alpha})`;
    hex = hex.replace("#", "");
    if (hex.length === 3) {
      hex = hex
        .split("")
        .map((c) => c + c)
        .join("");
    }
    const r = parseInt(hex.substring(0, 2), 16);
    const g = parseInt(hex.substring(2, 4), 16);
    const b = parseInt(hex.substring(4, 6), 16);
    return `rgba(${r}, ${g}, ${b}, ${alpha})`;
  };

  // Update canvas dimensions.
  useEffect(() => {
    const updateCanvasDimensions = () => {
      if (canvasRef.current) {
        const rect = canvasRef.current.getBoundingClientRect();
        setCanvasDimensions({ width: rect.width, height: rect.height });
      }
    };
    updateCanvasDimensions();
    window.addEventListener("resize", updateCanvasDimensions);
    return () => window.removeEventListener("resize", updateCanvasDimensions);
  }, [loaded, scale]);

  // When scale or pdf changes, reset the loaded state so the page is re-rendered.
  useEffect(() => {
    setLoaded(false);
  }, [scale, pdf]);

  // IntersectionObserver for lazy loading.
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            setIsVisible(true);
            observer.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.1 }
    );
    if (containerRef.current) observer.observe(containerRef.current);
    return () => {
      if (containerRef.current) observer.unobserve(containerRef.current);
    };
  }, []);

  // Load and render PDF page.
  useEffect(() => {
    let isMounted = true;
    if (isVisible && !loaded) {
      pdf.getPage(pageNumber).then((page) => {
        if (!isMounted) return;
        const viewport = page.getViewport({ scale });
        const canvas = canvasRef.current;
        if (!canvas) return;
        const devicePixelRatio = window.devicePixelRatio || 1;
        canvas.width = viewport.width * devicePixelRatio;
        canvas.height = viewport.height * devicePixelRatio;
        canvas.style.width = `${viewport.width}px`;
        canvas.style.height = `${viewport.height}px`;
        const context = canvas.getContext("2d");
        context.scale(devicePixelRatio, devicePixelRatio);
        const renderContext = { canvasContext: context, viewport };
        renderTaskRef.current = page.render(renderContext);
        renderTaskRef.current.promise
          .then(() => {
            if (isMounted) setLoaded(true);
          })
          .catch((error) => {
            if (error && error.name === "RenderingCancelledException") {
              // Ignore cancellation.
            } else {
              console.error("Error during rendering:", error);
            }
          });
      });
    }
    return () => {
      isMounted = false;
      if (renderTaskRef.current && renderTaskRef.current.cancel) {
        renderTaskRef.current.cancel();
      }
    };
  }, [isVisible, loaded, pdf, pageNumber, scale]);

  const getReferenceRect = () => {
    if (canvasRef.current) return canvasRef.current.getBoundingClientRect();
    return containerRef.current.getBoundingClientRect();
  };

  const clamp = (val, min, max) => Math.max(min, Math.min(val, max));

  // --- Basic Mouse Handlers for Drawing & Dragging ---
  const handleMouseDown = (e) => {
    // If any resizing is active, do nothing.
    if (
      resizingHighlightIndex !== null ||
      resizingPrivateIndex !== null ||
      resizingImageIndex !== null
    )
      return;

    const rect = getReferenceRect();
    const x = clamp(e.clientX - rect.left, 0, rect.width);
    const y = clamp(e.clientY - rect.top, 0, rect.height);

    if (highlightMode) {
      setDrawingRect({ startX: x, startY: y, x, y, width: 0, height: 0 });
    } else if (privateInfoMode) {
      setDrawingPrivate({ startX: x, startY: y, x, y, width: 0, height: 0 });
    } else if (textMode && e.target === containerRef.current) {
      // If there is an existing text annotation with empty text,
      // remove it before adding a new one.
      const emptyTextIndex = texts.findIndex((t) => t.text.trim() === "");
      if (emptyTextIndex !== -1) {
        onRemoveText(pageNumber, emptyTextIndex);
      }
      // When textMode is on and the user clicks the background,
      // add a new text annotation with default dimensions and start editing.
      const defaultWidth = 100; // pixels
      const defaultHeight = 30; // pixels
      const normalizedText = {
        x: x / rect.width,
        y: y / rect.height,
        width: defaultWidth / rect.width,
        height: defaultHeight / rect.height,
        text: "",
        fontSize: DEFAULT_FONT_SIZE,
      };
      onAddText(pageNumber, normalizedText);
      // Assume the new annotation is appended; set its index as the new text.
      const newIndex = texts.length;
      setActiveTextIndex(newIndex);
      setEditingTextIndex(newIndex);
    }
  };

  const handleMouseMove = (e) => {
    // Do not process drag events if resizing is active.
    if (
      resizingHighlightIndex !== null ||
      resizingPrivateIndex !== null ||
      resizingImageIndex !== null
    )
      return;

    const rect = getReferenceRect();
    if (draggingHighlightIndex !== null) {
      let newX = (e.clientX - rect.left - dragHighlightOffset.x) / rect.width;
      let newY = (e.clientY - rect.top - dragHighlightOffset.y) / rect.height;
      const hl = highlights[draggingHighlightIndex];
      newX = clamp(newX, 0, 1 - hl.width);
      newY = clamp(newY, 0, 1 - hl.height);
      onUpdateHighlight(pageNumber, draggingHighlightIndex, {
        ...hl,
        x: newX,
        y: newY,
      });
      return;
    }
    if (draggingPrivateIndex !== null) {
      const { x: offsetX, y: offsetY } = dragOffset;
      let newX = (e.clientX - rect.left - offsetX) / rect.width;
      let newY = (e.clientY - rect.top - offsetY) / rect.height;
      const box = privateInfos[draggingPrivateIndex];
      newX = clamp(newX, 0, 1 - box.width);
      newY = clamp(newY, 0, 1 - box.height);
      onUpdatePrivateInfo(pageNumber, draggingPrivateIndex, {
        ...box,
        x: newX,
        y: newY,
      });
      return;
    }
    if (draggingImageIndex !== null) {
      // Handled in global pointer listeners.
      return;
    }
    if (draggingTextIndex !== null) {
      // Handled in its own global pointer listener.
      return;
    }
    const currentX = clamp(e.clientX - rect.left, 0, rect.width);
    const currentY = clamp(e.clientY - rect.top, 0, rect.height);
    if (highlightMode && drawingRect) {
      const x = Math.min(drawingRect.startX, currentX);
      const y = Math.min(drawingRect.startY, currentY);
      const width = Math.abs(currentX - drawingRect.startX);
      // Use drawingRect.startY for height calculation.
      const height = Math.abs(currentY - drawingRect.startY);
      setDrawingRect({ ...drawingRect, x, y, width, height });
    } else if (privateInfoMode && drawingPrivate) {
      const x = Math.min(drawingPrivate.startX, currentY);
      const y = Math.min(drawingPrivate.startY, currentY);
      const width = Math.abs(currentX - drawingPrivate.startX);
      const height = Math.abs(currentY - drawingPrivate.startY);
      setDrawingPrivate({ ...drawingPrivate, x, y, width, height });
    }
    // No drawing state for text since it is added immediately.
  };

  const handleMouseUp = (e) => {
    if (draggingHighlightIndex !== null) {
      setDraggingHighlightIndex(null);
      setDragHighlightOffset({ x: 0, y: 0 });
      return;
    }
    if (draggingPrivateIndex !== null) {
      setDraggingPrivateIndex(null);
      setDragOffset({ x: 0, y: 0 });
      return;
    }
    if (draggingImageIndex !== null) {
      setDraggingImageIndex(null);
      setDragImageOffset({ x: 0, y: 0 });
      return;
    }
    if (draggingTextIndex !== null) {
      // Handled by pointerup listener.
      return;
    }
    if (highlightMode && drawingRect) {
      if (drawingRect.width > 5 && drawingRect.height > 5) {
        const rect = getReferenceRect();
        const normalizedHighlight = {
          x: drawingRect.x / rect.width,
          y: drawingRect.y / rect.height,
          width: drawingRect.width / rect.width,
          height: drawingRect.height / rect.height,
          color: highlightColor,
        };
        onAddHighlight(pageNumber, normalizedHighlight);
      }
      setDrawingRect(null);
    } else if (privateInfoMode && drawingPrivate) {
      if (drawingPrivate.width > 5 && drawingPrivate.height > 5) {
        const rect = getReferenceRect();
        const normalizedPrivate = {
          x: drawingPrivate.x / rect.width,
          y: drawingPrivate.y / rect.height,
          width: drawingPrivate.width / rect.width,
          height: drawingPrivate.height / rect.height,
        };
        onAddPrivateInfo(pageNumber, normalizedPrivate);
      }
      setDrawingPrivate(null);
    }
    // No text-mode handling needed on mouse up.
  };

  const handleHighlightMouseDown = (e, idx) => {
    e.stopPropagation();
    const rect = getReferenceRect();
    const hl = highlights[idx];
    const absX = hl.x * rect.width;
    const absY = hl.y * rect.height;
    const offsetX = e.clientX - rect.left - absX;
    const offsetY = e.clientY - rect.top - absY;
    setDraggingHighlightIndex(idx);
    setDragHighlightOffset({ x: offsetX, y: offsetY });
    setActiveHighlightIndex(idx);
  };

  const handlePrivateMouseDown = (e, idx) => {
    e.stopPropagation();
    const rect = getReferenceRect();
    const box = privateInfos[idx];
    const absX = box.x * rect.width;
    const absY = box.y * rect.height;
    const offsetX = e.clientX - rect.left - absX;
    const offsetY = e.clientY - rect.top - absY;
    setDraggingPrivateIndex(idx);
    setDragOffset({ x: offsetX, y: offsetY });
    setActivePrivateIndex(idx);
  };

  const handleImageMouseDown = (e, idx) => {
    e.stopPropagation();
    const rect = getReferenceRect();
    const imgAnno = images[idx];
    const absX = imgAnno.x * rect.width;
    const absY = imgAnno.y * rect.height;
    const offsetX = e.clientX - rect.left - absX;
    const offsetY = e.clientY - rect.top - absY;
    setDraggingImageIndex(idx);
    setDragImageOffset({ x: offsetX, y: offsetY });
    setActiveImageIndex(idx);
  };

  // --- TEXT ANNOTATION HANDLERS (Active only if textMode is enabled) ---
  const handleTextMouseDown = (e, idx) => {
    if (!textMode) return;
    // If the annotation is in editing mode, do not start dragging.
    if (editingTextIndex === idx) return;
    e.stopPropagation();
    const rect = getReferenceRect();
    const textAnno = texts[idx];
    const absX = textAnno.x * canvasDimensions.width;
    const absY = textAnno.y * canvasDimensions.height;
    const offsetX = e.clientX - rect.left - absX;
    const offsetY = e.clientY - rect.top - absY;
    setDraggingTextIndex(idx);
    setDragTextOffset({ x: offsetX, y: offsetY });
    setActiveTextIndex(idx);
  };

  useEffect(() => {
    if (draggingTextIndex !== null && textMode) {
      const handlePointerMove = (e) => {
        const rect = getReferenceRect();
        let newX = (e.clientX - rect.left - dragTextOffset.x) / rect.width;
        let newY = (e.clientY - rect.top - dragTextOffset.y) / rect.height;
        const textAnno = texts[draggingTextIndex];
        newX = clamp(newX, 0, 1 - textAnno.width);
        newY = clamp(newY, 0, 1 - textAnno.height);
        onUpdateText(pageNumber, draggingTextIndex, {
          ...textAnno,
          x: newX,
          y: newY,
        });
      };

      const handlePointerUp = () => {
        setDraggingTextIndex(null);
        setDragTextOffset({ x: 0, y: 0 });
      };

      window.addEventListener("pointermove", handlePointerMove);
      window.addEventListener("pointerup", handlePointerUp);
      return () => {
        window.removeEventListener("pointermove", handlePointerMove);
        window.removeEventListener("pointerup", handlePointerUp);
      };
    }
  }, [
    draggingTextIndex,
    dragTextOffset,
    texts,
    pageNumber,
    onUpdateText,
    textMode,
  ]);

  const handleTextTouchStart = (e, idx) => {
    if (!textMode) return;
    e.stopPropagation();
    if (e.touches.length !== 1) return;
    const touch = e.touches[0];
    const rect = getReferenceRect();
    initialTouchRef.current = { x: touch.clientX, y: touch.clientY, idx };
    textLongPressTimerRef.current = setTimeout(() => {
      const textAnno = texts[idx];
      const absX = textAnno.x * canvasDimensions.width;
      const absY = textAnno.y * canvasDimensions.height;
      const offsetX = touch.clientX - rect.left - absX;
      const offsetY = touch.clientY - rect.top - absY;
      setDraggingTextIndex(idx);
      setDragTextOffset({ x: offsetX, y: offsetY });
      setActiveTextIndex(idx);
      textLongPressTimerRef.current = null;
    }, LONG_PRESS_DURATION);
  };

  const handleTextTouchMove = (e, idx) => {
    if (!textMode) return;
    if (e.touches.length !== 1) return;
    const touch = e.touches[0];
    const rect = getReferenceRect();
    const { x, y } = initialTouchRef.current;
    const distance = Math.hypot(touch.clientX - x, touch.clientY - y);
    if (textLongPressTimerRef.current && distance > MOVE_THRESHOLD) {
      clearTimeout(textLongPressTimerRef.current);
      textLongPressTimerRef.current = null;
    }
    if (draggingTextIndex === idx) {
      let newX = (touch.clientX - rect.left - dragTextOffset.x) / rect.width;
      let newY = (touch.clientY - rect.top - dragTextOffset.y) / rect.height;
      const textAnno = texts[idx];
      newX = clamp(newX, 0, 1 - textAnno.width);
      newY = clamp(newY, 0, 1 - textAnno.height);
      onUpdateText(pageNumber, idx, { ...textAnno, x: newX, y: newY });
      e.preventDefault();
    }
  };

  const handleTextTouchEnd = (e, idx) => {
    if (!textMode) return;
    if (textLongPressTimerRef.current) {
      clearTimeout(textLongPressTimerRef.current);
      textLongPressTimerRef.current = null;
    }
    if (draggingTextIndex === idx) {
      setDraggingTextIndex(null);
      setDragTextOffset({ x: 0, y: 0 });
      e.preventDefault();
    }
  };

  // Handlers for text editing.
  // We use an auto-resize technique by setting the height and width based on scrollHeight and scrollWidth.
  const handleTextChange = (e, idx) => {
    e.target.style.height = "auto";
    e.target.style.width = "auto";
    e.target.style.height = e.target.scrollHeight + "px";
    const containerWidth = containerRef.current.getBoundingClientRect().width;
    e.target.style.width =
      Math.min(e.target.scrollWidth, containerWidth) + "px";
    const newText = e.target.value;
    const textAnno = texts[idx];
    onUpdateText(pageNumber, idx, { ...textAnno, text: newText });
  };

  const finishTextEditing = (idx) => {
    setEditingTextIndex(null);
  };

  // --- RESIZING HANDLERS USING POINTER EVENTS (for images, highlights, private infos) ---
  // IMAGE RESIZING
  const handleImageResizePointerDown = (e, idx, direction) => {
    e.stopPropagation();
    e.preventDefault();
    e.target.setPointerCapture(e.pointerId);
    const rect = getReferenceRect();
    const imgAnno = images[idx];
    resizingImageDataRef.current = {
      idx,
      startClientX: e.clientX,
      startClientY: e.clientY,
      original: { ...imgAnno },
      direction,
      canvasRect: rect,
    };
    setResizingImageIndex(idx);
    window.addEventListener("pointermove", handleImageResizePointerMove);
    window.addEventListener("pointerup", handleImageResizePointerUp);
  };

  const handleImageResizePointerMove = (e) => {
    if (!resizingImageDataRef.current) return;
    const { idx, canvasRect, original, direction, startClientX, startClientY } =
      resizingImageDataRef.current;
    const deltaX = e.clientX - startClientX;
    const deltaY = e.clientY - startClientY;
    const ndx = deltaX / canvasRect.width;
    const ndy = deltaY / canvasRect.height;
    const newAnno = computeNewAnnotation(original, ndx, ndy, direction);
    onUpdateImage(pageNumber, idx, newAnno);
  };

  const handleImageResizePointerUp = (e) => {
    setResizingImageIndex(null);
    resizingImageDataRef.current = null;
    window.removeEventListener("pointermove", handleImageResizePointerMove);
    window.removeEventListener("pointerup", handleImageResizePointerUp);
  };

  // HIGHLIGHT RESIZING
  const handleHighlightResizePointerDown = (e, idx, direction) => {
    e.stopPropagation();
    e.preventDefault();
    e.target.setPointerCapture(e.pointerId);
    const rect = getReferenceRect();
    const hl = highlights[idx];
    resizingHighlightDataRef.current = {
      idx,
      startClientX: e.clientX,
      startClientY: e.clientY,
      original: { ...hl },
      direction,
      canvasRect: rect,
    };
    setResizingHighlightIndex(idx);
    window.addEventListener("pointermove", handleHighlightResizePointerMove);
    window.addEventListener("pointerup", handleHighlightResizePointerUp);
  };

  const handleHighlightResizePointerMove = (e) => {
    if (!resizingHighlightDataRef.current) return;
    const { idx, canvasRect, original, direction, startClientX, startClientY } =
      resizingHighlightDataRef.current;
    const deltaX = e.clientX - startClientX;
    const deltaY = e.clientY - startClientY;
    const ndx = deltaX / canvasRect.width;
    const ndy = deltaY / canvasRect.height;
    const newAnno = computeNewAnnotation(original, ndx, ndy, direction);
    onUpdateHighlight(pageNumber, idx, newAnno);
  };

  const handleHighlightResizePointerUp = (e) => {
    setResizingHighlightIndex(null);
    resizingHighlightDataRef.current = null;
    window.removeEventListener("pointermove", handleHighlightResizePointerMove);
    window.removeEventListener("pointerup", handleHighlightResizePointerUp);
  };

  // PRIVATE INFO (REDACT) RESIZING
  const handlePrivateResizePointerDown = (e, idx, direction) => {
    e.stopPropagation();
    e.preventDefault();
    e.target.setPointerCapture(e.pointerId);
    const rect = getReferenceRect();
    const pi = privateInfos[idx];
    resizingPrivateDataRef.current = {
      idx,
      startClientX: e.clientX,
      startClientY: e.clientY,
      original: { ...pi },
      direction,
      canvasRect: rect,
    };
    setResizingPrivateIndex(idx);
    window.addEventListener("pointermove", handlePrivateResizePointerMove);
    window.addEventListener("pointerup", handlePrivateResizePointerUp);
  };

  const handlePrivateResizePointerMove = (e) => {
    if (!resizingPrivateDataRef.current) return;
    const { idx, canvasRect, original, direction, startClientX, startClientY } =
      resizingPrivateDataRef.current;
    const deltaX = e.clientX - startClientX;
    const deltaY = e.clientY - startClientY;
    const ndx = deltaX / canvasRect.width;
    const ndy = deltaY / canvasRect.height;
    const newAnno = computeNewAnnotation(original, ndx, ndy, direction);
    onUpdatePrivateInfo(pageNumber, idx, newAnno);
  };

  const handlePrivateResizePointerUp = (e) => {
    setResizingPrivateIndex(null);
    resizingPrivateDataRef.current = null;
    window.removeEventListener("pointermove", handlePrivateResizePointerMove);
    window.removeEventListener("pointerup", handlePrivateResizePointerUp);
  };

  // --- Global Pointer Listeners for Image Dragging ---
  useEffect(() => {
    if (draggingImageIndex !== null) {
      const handlePointerMove = (e) => {
        const rect = getReferenceRect();
        let newX = (e.clientX - rect.left - dragImageOffset.x) / rect.width;
        let newY = (e.clientY - rect.top - dragImageOffset.y) / rect.height;
        const imgAnno = images[draggingImageIndex];
        newX = clamp(newX, 0, 1 - imgAnno.width);
        newY = clamp(newY, 0, 1 - imgAnno.height);
        onUpdateImage(pageNumber, draggingImageIndex, {
          ...imgAnno,
          x: newX,
          y: newY,
        });
      };

      const handlePointerUp = () => {
        setDraggingImageIndex(null);
        setDragImageOffset({ x: 0, y: 0 });
      };

      window.addEventListener("pointermove", handlePointerMove);
      window.addEventListener("pointerup", handlePointerUp);
      return () => {
        window.removeEventListener("pointermove", handlePointerMove);
        window.removeEventListener("pointerup", handlePointerUp);
      };
    }
  }, [draggingImageIndex, dragImageOffset, images, pageNumber, onUpdateImage]);

  // --- Touch Handlers for New Annotations ---
  const handleTouchStart = useCallback(
    (e) => {
      if (e.touches.length !== 1) return;
      const touch = e.touches[0];
      const containerRect = containerRef.current.getBoundingClientRect();
      const x = clamp(
        touch.clientX - containerRect.left,
        0,
        containerRect.width
      );
      const y = clamp(
        touch.clientY - containerRect.top,
        0,
        containerRect.height
      );
      // Avoid starting a new annotation if tapping inside an existing one.
      if (highlightMode && highlights.length > 0) {
        for (let i = 0; i < highlights.length; i++) {
          const hl = highlights[i];
          const hlX = hl.x * canvasDimensions.width;
          const hlY = hl.y * canvasDimensions.height;
          const hlW = hl.width * canvasDimensions.width;
          const hlH = hl.height * canvasDimensions.height;
          if (x >= hlX && x <= hlX + hlW && y >= hlY && y <= hlH + hlY) return;
        }
      }
      if (privateInfoMode && privateInfos.length > 0) {
        for (let i = 0; i < privateInfos.length; i++) {
          const pi = privateInfos[i];
          const boxX = pi.x * canvasDimensions.width;
          const boxY = pi.y * canvasDimensions.height;
          const boxW = pi.width * canvasDimensions.width;
          const boxH = pi.height * canvasDimensions.height;
          if (x >= boxX && x <= boxX + boxW && y >= boxY && y <= boxY + boxH)
            return;
        }
      }
      if (imageMode && images.length > 0) {
        for (let i = 0; i < images.length; i++) {
          const imgAnno = images[i];
          const imgX = imgAnno.x * canvasDimensions.width;
          const imgY = imgAnno.y * canvasDimensions.height;
          const imgW = imgAnno.width * canvasDimensions.width;
          const imgH = imgAnno.height * canvasDimensions.height;
          if (x >= imgX && x <= imgX + imgW && y >= imgY && y <= imgY + imgH)
            return;
        }
      }
      if (textMode) {
        // Check if the touch is inside an existing text annotation.
        for (let i = 0; i < texts.length; i++) {
          const textAnno = texts[i];
          const textX = textAnno.x * canvasDimensions.width;
          const textY = textAnno.y * canvasDimensions.height;
          const textW = textAnno.width * canvasDimensions.width;
          const textH = textAnno.height * canvasDimensions.height;
          if (
            x >= textX &&
            x <= textX + textW &&
            y >= textY &&
            y <= textY + textH
          )
            return;
        }
        // Remove previous empty text annotation if exists.
        const emptyTextIndex = texts.findIndex((t) => t.text.trim() === "");
        if (emptyTextIndex !== -1) {
          onRemoveText(pageNumber, emptyTextIndex);
        }
        // Immediately add a text annotation on tap with default dimensions.
        const defaultWidth = 100;
        const defaultHeight = 30;
        const normalizedText = {
          x: x / containerRect.width,
          y: y / containerRect.height,
          width: defaultWidth / containerRect.width,
          height: defaultHeight / containerRect.height,
          text: "",
          fontSize: DEFAULT_FONT_SIZE,
        };
        onAddText(pageNumber, normalizedText);
        const newIndex = texts.length;
        setActiveTextIndex(newIndex);
        setEditingTextIndex(newIndex);
        return; // Skip setting up the long-press timer.
      }
      initialTouchRef.current = { x, y };
      longPressTimerRef.current = setTimeout(() => {
        if (highlightMode) {
          setDrawingRect({ startX: x, startY: y, x, y, width: 0, height: 0 });
        } else if (privateInfoMode) {
          setDrawingPrivate({
            startX: x,
            startY: y,
            x,
            y,
            width: 0,
            height: 0,
          });
        }
        longPressTimerRef.current = null;
      }, LONG_PRESS_DURATION);
    },
    [
      highlightMode,
      privateInfoMode,
      textMode,
      highlights,
      privateInfos,
      images,
      texts,
      canvasDimensions,
    ]
  );

  const handleTouchMove = useCallback(
    (e) => {
      if (e.touches.length !== 1) return;
      const touch = e.touches[0];
      const containerRect = containerRef.current.getBoundingClientRect();
      const currentX = clamp(
        touch.clientX - containerRect.left,
        0,
        containerRect.width
      );
      const currentY = clamp(
        touch.clientY - containerRect.top,
        0,
        containerRect.height
      );
      if (longPressTimerRef.current) {
        const { x, y } = initialTouchRef.current;
        const distance = Math.hypot(currentX - x, currentY - y);
        if (distance > MOVE_THRESHOLD) {
          clearTimeout(longPressTimerRef.current);
          longPressTimerRef.current = null;
        }
      }
      if (highlightMode && drawingRect) {
        const x = Math.min(drawingRect.startX, currentX);
        const y = Math.min(drawingRect.startY, currentY);
        const width = Math.abs(currentX - drawingRect.startX);
        // Use drawingRect.startY for height calculation
        const height = Math.abs(currentY - drawingRect.startY);
        setDrawingRect({ ...drawingRect, x, y, width, height });
        e.preventDefault();
      } else if (privateInfoMode && drawingPrivate) {
        const x = Math.min(drawingPrivate.startX, currentX);
        const y = Math.min(drawingPrivate.startY, currentY);
        const width = Math.abs(currentX - drawingPrivate.startX);
        const height = Math.abs(currentY - drawingPrivate.startY);
        setDrawingPrivate({ ...drawingPrivate, x, y, width, height });
        e.preventDefault();
      } else if (imageMode && drawingImage) {
        const x = Math.min(drawingImage.startX, currentX);
        const y = Math.min(drawingImage.startY, currentY);
        const width = Math.abs(currentX - drawingImage.startX);
        const height = Math.abs(currentY - drawingImage.startY);
        setDrawingImage({ ...drawingImage, x, y, width, height });
        e.preventDefault();
      }
    },
    [
      highlightMode,
      drawingRect,
      privateInfoMode,
      drawingPrivate,
      imageMode,
      drawingImage,
    ]
  );

  const handleTouchEnd = useCallback(
    (e) => {
      if (longPressTimerRef.current) {
        clearTimeout(longPressTimerRef.current);
        longPressTimerRef.current = null;
      }
      if (highlightMode && drawingRect) {
        if (drawingRect.width > 5 && drawingRect.height > 5) {
          const rect = getReferenceRect();
          const normalizedHighlight = {
            x: drawingRect.x / rect.width,
            y: drawingRect.y / rect.height,
            width: drawingRect.width / rect.width,
            height: drawingRect.height / rect.height,
            color: highlightColor,
          };
          onAddHighlight(pageNumber, normalizedHighlight);
        }
        setDrawingRect(null);
        e.preventDefault();
      } else if (privateInfoMode && drawingPrivate) {
        if (drawingPrivate.width > 5 && drawingPrivate.height > 5) {
          const rect = getReferenceRect();
          const normalizedPrivate = {
            x: drawingPrivate.x / rect.width,
            y: drawingPrivate.y / rect.height,
            width: drawingPrivate.width / rect.width,
            height: drawingPrivate.height / rect.height,
          };
          onAddPrivateInfo(pageNumber, normalizedPrivate);
        }
        setDrawingPrivate(null);
        e.preventDefault();
      } else if (imageMode && drawingImage) {
        if (drawingImage.width > 5 && drawingImage.height > 5) {
          const rect = getReferenceRect();
          const normalizedImage = {
            x: drawingImage.x / rect.width,
            y: drawingImage.y / rect.height,
            width: drawingImage.width / rect.width,
            height: drawingImage.height / rect.height,
            src: imageSrc,
          };
          onAddImage(pageNumber, normalizedImage);
        }
        setDrawingImage(null);
        e.preventDefault();
      }
    },
    [
      highlightMode,
      drawingRect,
      privateInfoMode,
      drawingPrivate,
      imageMode,
      drawingImage,
      highlightColor,
      onAddHighlight,
      onAddPrivateInfo,
      onAddImage,
      pageNumber,
      imageSrc,
    ]
  );

  // --- Touch Handlers for Existing Annotations ---
  const handlePrivateTouchStart = (e, idx) => {
    e.stopPropagation();
    if (e.touches.length !== 1) return;
    const touch = e.touches[0];
    const rect = getReferenceRect();
    initialTouchRef.current = { x: touch.clientX, y: touch.clientY, idx };
    privateLongPressTimerRef.current = setTimeout(() => {
      const box = privateInfos[idx];
      const absX = box.x * rect.width;
      const absY = box.y * rect.height;
      const offsetX = touch.clientX - rect.left - absX;
      const offsetY = touch.clientY - rect.top - absY;
      setDraggingPrivateIndex(idx);
      setDragOffset({ x: offsetX, y: offsetY });
      setActivePrivateIndex(idx);
      privateLongPressTimerRef.current = null;
    }, LONG_PRESS_DURATION);
  };

  const handlePrivateTouchMove = (e, idx) => {
    if (e.touches.length !== 1) return;
    const touch = e.touches[0];
    const rect = getReferenceRect();
    const { x, y } = initialTouchRef.current;
    const distance = Math.hypot(touch.clientX - x, touch.clientY - y);
    if (privateLongPressTimerRef.current && distance > MOVE_THRESHOLD) {
      clearTimeout(privateLongPressTimerRef.current);
      privateLongPressTimerRef.current = null;
    }
    if (draggingPrivateIndex === idx) {
      let newX = (touch.clientX - rect.left - dragOffset.x) / rect.width;
      let newY = (touch.clientY - rect.top - dragOffset.y) / rect.height;
      const box = privateInfos[idx];
      newX = clamp(newX, 0, 1 - box.width);
      newY = clamp(newY, 0, 1 - box.height);
      onUpdatePrivateInfo(pageNumber, idx, { ...box, x: newX, y: newY });
      e.preventDefault();
    }
  };

  const handlePrivateTouchEnd = (e, idx) => {
    if (privateLongPressTimerRef.current) {
      clearTimeout(privateLongPressTimerRef.current);
      privateLongPressTimerRef.current = null;
    }
    if (draggingPrivateIndex === idx) {
      setDraggingPrivateIndex(null);
      setDragOffset({ x: 0, y: 0 });
      e.preventDefault();
    }
  };

  const handleHighlightTouchStart = (e, idx) => {
    e.stopPropagation();
    if (e.touches.length !== 1) return;
    const touch = e.touches[0];
    const rect = getReferenceRect();
    initialTouchRef.current = { x: touch.clientX, y: touch.clientY, idx };
    highlightLongPressTimerRef.current = setTimeout(() => {
      const hl = highlights[idx];
      const absX = hl.x * rect.width;
      const absY = hl.y * rect.height;
      const offsetX = touch.clientX - rect.left - absX;
      const offsetY = touch.clientY - rect.top - absY;
      setDraggingHighlightIndex(idx);
      setDragHighlightOffset({ x: offsetX, y: offsetY });
      setActiveHighlightIndex(idx);
      highlightLongPressTimerRef.current = null;
    }, LONG_PRESS_DURATION);
  };

  const handleHighlightTouchMove = (e, idx) => {
    if (e.touches.length !== 1) return;
    const touch = e.touches[0];
    const rect = getReferenceRect();
    const { x, y } = initialTouchRef.current;
    const distance = Math.hypot(touch.clientX - x, touch.clientY - y);
    if (highlightLongPressTimerRef.current && distance > MOVE_THRESHOLD) {
      clearTimeout(highlightLongPressTimerRef.current);
      highlightLongPressTimerRef.current = null;
    }
    if (draggingHighlightIndex === idx) {
      let newX =
        (touch.clientX - rect.left - dragHighlightOffset.x) / rect.width;
      let newY =
        (touch.clientY - rect.top - dragHighlightOffset.y) / rect.height;
      const hl = highlights[idx];
      newX = clamp(newX, 0, 1 - hl.width);
      newY = clamp(newY, 0, 1 - hl.height);
      onUpdateHighlight(pageNumber, idx, { ...hl, x: newX, y: newY });
      e.preventDefault();
    }
  };

  const handleHighlightTouchEnd = (e, idx) => {
    if (highlightLongPressTimerRef.current) {
      clearTimeout(highlightLongPressTimerRef.current);
      highlightLongPressTimerRef.current = null;
    }
    if (draggingHighlightIndex === idx) {
      setDraggingHighlightIndex(null);
      setDragHighlightOffset({ x: 0, y: 0 });
      e.preventDefault();
    }
  };

  const handleImageTouchStart = (e, idx) => {
    e.stopPropagation();
    if (e.touches.length !== 1) return;
    const touch = e.touches[0];
    const rect = getReferenceRect();
    initialTouchRef.current = { x: touch.clientX, y: touch.clientY, idx };
    imageLongPressTimerRef.current = setTimeout(() => {
      const imgAnno = images[idx];
      const absX = imgAnno.x * rect.width;
      const absY = imgAnno.y * rect.height;
      const offsetX = touch.clientX - rect.left - absX;
      const offsetY = touch.clientY - rect.top - absY;
      setDraggingImageIndex(idx);
      setDragImageOffset({ x: offsetX, y: offsetY });
      setActiveImageIndex(idx);
      imageLongPressTimerRef.current = null;
    }, LONG_PRESS_DURATION);
  };

  const handleImageTouchMove = (e, idx) => {
    if (e.touches.length !== 1) return;
    const touch = e.touches[0];
    const rect = getReferenceRect();
    const { x, y } = initialTouchRef.current;
    const distance = Math.hypot(touch.clientX - x, touch.clientY - y);
    if (imageLongPressTimerRef.current && distance > MOVE_THRESHOLD) {
      clearTimeout(imageLongPressTimerRef.current);
      imageLongPressTimerRef.current = null;
    }
    if (draggingImageIndex === idx) {
      let newX = (touch.clientX - rect.left - dragImageOffset.x) / rect.width;
      let newY = (touch.clientY - rect.top - dragImageOffset.y) / rect.height;
      const imgAnno = images[idx];
      newX = clamp(newX, 0, 1 - imgAnno.width);
      newY = clamp(newY, 0, 1 - imgAnno.height);
      onUpdateImage(pageNumber, idx, { ...imgAnno, x: newX, y: newY });
      e.preventDefault();
    }
  };

  const handleImageTouchEnd = (e, idx) => {
    if (imageLongPressTimerRef.current) {
      clearTimeout(imageLongPressTimerRef.current);
      imageLongPressTimerRef.current = null;
    }
    if (draggingImageIndex === idx) {
      setDraggingImageIndex(null);
      setDragImageOffset({ x: 0, y: 0 });
      e.preventDefault();
    }
  };

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;
    container.addEventListener("touchstart", handleTouchStart, {
      passive: false,
    });
    container.addEventListener("touchmove", handleTouchMove, {
      passive: false,
    });
    container.addEventListener("touchend", handleTouchEnd, { passive: false });
    container.addEventListener("touchcancel", handleTouchEnd, {
      passive: false,
    });
    return () => {
      container.removeEventListener("touchstart", handleTouchStart);
      container.removeEventListener("touchmove", handleTouchMove);
      container.removeEventListener("touchend", handleTouchEnd);
      container.removeEventListener("touchcancel", handleTouchEnd);
    };
  }, [handleTouchStart, handleTouchMove, handleTouchEnd]);

  // --- RENDER RESIZE HANDLES ---
  const renderResizeHandles = (type, idx) => {
    const handlePositions = [
      { direction: "nw", style: { left: -5, top: -5 } },
      {
        direction: "n",
        style: { left: "50%", top: -5, transform: "translateX(-50%)" },
      },
      { direction: "ne", style: { right: -5, top: -5 } },
      {
        direction: "e",
        style: { right: -5, top: "50%", transform: "translateY(-50%)" },
      },
      { direction: "se", style: { right: -5, bottom: -5 } },
      {
        direction: "s",
        style: { left: "50%", bottom: -5, transform: "translateX(-50%)" },
      },
      { direction: "sw", style: { left: -5, bottom: -5 } },
      {
        direction: "w",
        style: { left: -5, top: "50%", transform: "translateY(-50%)" },
      },
    ];
    return handlePositions.map((handle) => {
      const onPointerDown = (e) => {
        e.stopPropagation();
        e.preventDefault();
        e.target.setPointerCapture(e.pointerId);
        if (type === "image") {
          handleImageResizePointerDown(e, idx, handle.direction);
        } else if (type === "highlight") {
          handleHighlightResizePointerDown(e, idx, handle.direction);
        } else if (type === "private") {
          handlePrivateResizePointerDown(e, idx, handle.direction);
        }
      };
      return (
        <div
          key={handle.direction}
          style={{
            position: "absolute",
            width: 10,
            height: 10,
            backgroundColor: "white",
            border: "1px solid black",
            cursor: "nwse-resize",
            zIndex: 20,
            touchAction: "none",
            ...handle.style,
          }}
          onPointerDown={onPointerDown}
        ></div>
      );
    });
  };

  // --- RENDERING ---
  return (
    <div
      ref={containerRef}
      id={`page-${pageNumber}`}
      style={{
        marginBottom: "120px",
        position: "relative",
        margin: "0 auto",
        width: "fit-content",
      }}
      onMouseDown={(e) => {
        if (e.target === containerRef.current) {
          setActiveHighlightIndex(null);
          setActivePrivateIndex(null);
          setActiveImageIndex(null);
          setActiveTextIndex(null);
          // Also exit text editing if clicking on the background.
          setEditingTextIndex(null);
        }
        handleMouseDown(e);
      }}
      onMouseMove={handleMouseMove}
      onMouseUp={handleMouseUp}
      onMouseLeave={handleMouseUp}
    >
      {isVisible ? (
        <>
          <canvas
            ref={canvasRef}
            style={{
              display: "block",
              opacity: loaded ? 1 : 0,
              transition: "opacity 0.5s ease-in-out",
              marginBottom: "20px",
              pointerEvents: "none",
            }}
          />
          {/* Render Highlights */}
          {highlights.map((hl, idx) => {
            const hlColor = hl.color || highlightColor;
            return (
              <div
                key={`hl-${idx}`}
                style={{
                  cursor: "pointer",
                  position: "absolute",
                  left: hl.x * canvasDimensions.width,
                  top: hl.y * canvasDimensions.height,
                  width: hl.width * canvasDimensions.width,
                  height: hl.height * canvasDimensions.height,
                  touchAction: "none",
                }}
                onMouseDown={(e) => handleHighlightMouseDown(e, idx)}
                onTouchStart={(e) => handleHighlightTouchStart(e, idx)}
                onTouchMove={(e) => handleHighlightTouchMove(e, idx)}
                onTouchEnd={(e) => handleHighlightTouchEnd(e, idx)}
                onClick={(e) => {
                  e.stopPropagation();
                  setActiveHighlightIndex(idx);
                }}
              >
                <div
                  style={{
                    width: "100%",
                    height: "100%",
                    backgroundColor: hexToRgba(hlColor, 0.3),
                    pointerEvents: "none",
                    boxSizing: "border-box",
                  }}
                ></div>
                {activeHighlightIndex === idx &&
                  renderResizeHandles("highlight", idx)}
                {activeHighlightIndex === idx && (
                  <div
                    style={{
                      position: "absolute",
                      bottom: "100%",
                      left: 0,
                      zIndex: 10,
                      display: "flex",
                      flexDirection: "column",
                      alignItems: "flex-start",
                    }}
                    onMouseDown={(e) => e.stopPropagation()}
                    onClick={(e) => e.stopPropagation()}
                  >
                    <button
                      style={{
                        fontSize: "10px",
                        cursor: "pointer",
                        backgroundColor: "black",
                        color: "white",
                        marginBottom: "2px",
                      }}
                      onClick={(e) => {
                        e.stopPropagation();
                        onRemoveHighlight(pageNumber, idx);
                        setActiveHighlightIndex(null);
                      }}
                    >
                      Remove
                    </button>
                    <select
                      value={hlColor}
                      onChange={(e) =>
                        onUpdateHighlight(pageNumber, idx, {
                          color: e.target.value,
                        })
                      }
                      onMouseDown={(e) => e.stopPropagation()}
                      style={{
                        fontSize: "10px",
                        cursor: "pointer",
                        color: "black",
                      }}
                    >
                      <option value="#FFFF00">Yellow</option>
                      <option value="#00FF00">Green</option>
                      <option value="#0000FF">Blue</option>
                      <option value="#FFC0CB">Pink</option>
                      <option value="#FFA500">Orange</option>
                    </select>
                  </div>
                )}
              </div>
            );
          })}
          {/* Render Private Info Boxes (Redact) */}
          {privateInfos.map((pi, idx) => (
            <div
              key={`pi-${idx}`}
              style={{
                cursor: "move",
                position: "absolute",
                left: pi.x * canvasDimensions.width,
                top: pi.y * canvasDimensions.height,
                width: pi.width * canvasDimensions.width,
                height: pi.height * canvasDimensions.height,
                touchAction: "none",
              }}
              onMouseDown={(e) => handlePrivateMouseDown(e, idx)}
              onTouchStart={(e) => handlePrivateTouchStart(e, idx)}
              onTouchMove={(e) => handlePrivateTouchMove(e, idx)}
              onTouchEnd={(e) => handlePrivateTouchEnd(e, idx)}
              onClick={(e) => {
                e.stopPropagation();
                setActivePrivateIndex(idx);
              }}
            >
              <div
                style={{
                  width: "100%",
                  height: "100%",
                  backgroundColor: "black",
                  pointerEvents: "none",
                  boxSizing: "border-box",
                }}
              ></div>
              {activePrivateIndex === idx &&
                renderResizeHandles("private", idx)}
              {activePrivateIndex === idx && (
                <div
                  style={{
                    position: "absolute",
                    bottom: "100%",
                    left: 0,
                    zIndex: 10,
                    display: "flex",
                    flexDirection: "column",
                    alignItems: "flex-start",
                  }}
                  onClick={(e) => e.stopPropagation()}
                >
                  <button
                    style={{
                      fontSize: "10px",
                      cursor: "pointer",
                      backgroundColor: "black",
                      color: "white",
                      marginBottom: "2px",
                    }}
                    onClick={(e) => {
                      e.stopPropagation();
                      onRemovePrivateInfo(pageNumber, idx);
                      setActivePrivateIndex(null);
                    }}
                  >
                    Remove
                  </button>
                </div>
              )}
            </div>
          ))}
          {/* Render Image Annotations */}
          {images.map((img, idx) => (
            <div
              key={`img-${idx}`}
              style={{
                cursor: "move",
                position: "absolute",
                left: img.x * canvasDimensions.width,
                top: img.y * canvasDimensions.height,
                width: img.width * canvasDimensions.width,
                height: img.height * canvasDimensions.height,
                touchAction: "none",
              }}
              onMouseDown={(e) => handleImageMouseDown(e, idx)}
              onTouchStart={(e) => handleImageTouchStart(e, idx)}
              onTouchMove={(e) => handleImageTouchMove(e, idx)}
              onTouchEnd={(e) => handleImageTouchEnd(e, idx)}
              onClick={(e) => {
                e.stopPropagation();
                setActiveImageIndex(idx);
              }}
            >
              <img
                src={img.src}
                alt=""
                style={{
                  width: "100%",
                  height: "100%",
                  pointerEvents: "none",
                  objectFit: "cover",
                }}
              />
              {activeImageIndex === idx && renderResizeHandles("image", idx)}
              {activeImageIndex === idx && (
                <div
                  style={{
                    position: "absolute",
                    bottom: "100%",
                    left: 0,
                    zIndex: 10,
                    display: "flex",
                    flexDirection: "column",
                    alignItems: "flex-start",
                  }}
                  onClick={(e) => e.stopPropagation()}
                >
                  <button
                    style={{
                      fontSize: "10px",
                      cursor: "pointer",
                      backgroundColor: "black",
                      color: "white",
                      marginBottom: "2px",
                    }}
                    onClick={(e) => {
                      e.stopPropagation();
                      onRemoveImage(pageNumber, idx);
                      setActiveImageIndex(null);
                    }}
                  >
                    Remove
                  </button>
                </div>
              )}
            </div>
          ))}
          {/* Render Text Annotations (always visible) */}
          {texts.map((textAnno, idx) => {
            // Compute available width for the annotation so it stays within the container.
            const containerRect = containerRef.current
              ? containerRef.current.getBoundingClientRect()
              : { width: canvasDimensions.width };
            const leftPos = textAnno.x * canvasDimensions.width;
            const maxTextWidth = containerRect.width - leftPos;
            return (
              <div
                key={`text-${idx}`}
                style={{
                  position: "absolute",
                  left: textAnno.x * canvasDimensions.width,
                  top: textAnno.y * canvasDimensions.height,
                  maxWidth: `${maxTextWidth}px`,
                  wordBreak: "break-word",
                  overflowWrap: "break-word",
                  cursor: textMode
                    ? editingTextIndex === idx
                      ? "text"
                      : "move"
                    : "default",
                  touchAction: "none",
                  border:
                    textMode && activeTextIndex === idx
                      ? "1px dashed blue"
                      : "1px solid transparent",
                  padding: "2px",
                  backgroundColor: "transparent",
                  boxSizing: "border-box",
                  userSelect: "none",
                  textAlign: "left",
                  overflow: "visible",
                }}
                onMouseDown={
                  textMode && editingTextIndex !== idx
                    ? (e) => handleTextMouseDown(e, idx)
                    : undefined
                }
                onDoubleClick={
                  textMode
                    ? (e) => {
                        e.stopPropagation();
                        setEditingTextIndex(idx);
                      }
                    : undefined
                }
                onClick={
                  textMode
                    ? (e) => {
                        e.stopPropagation();
                        setActiveTextIndex(idx);
                      }
                    : undefined
                }
              >
                {editingTextIndex === idx ? (
                  <textarea
                    wrap="off"
                    ref={(el) => {
                      if (el) {
                        el.style.height = "auto";
                        el.style.width = "auto";
                        el.style.height = `${el.scrollHeight}px`;
                        el.style.width = `${Math.min(
                          el.scrollWidth,
                          maxTextWidth
                        )}px`;
                      }
                    }}
                    style={{
                      overflow: "hidden",
                      resize: "none",
                      textAlign: "left",
                      border: "none",
                      background: "transparent",
                      outline: "none",
                      color: "black",
                      whiteSpace: "pre",
                      width: "fit-content",
                      maxWidth: "100%",
                      fontSize: textAnno.fontSize
                        ? textAnno.fontSize + "px"
                        : DEFAULT_FONT_SIZE + "px",
                    }}
                    value={textAnno.text}
                    onInput={(e) => {
                      e.target.style.height = "auto";
                      e.target.style.width = "auto";
                      e.target.style.height = `${e.target.scrollHeight}px`;
                      e.target.style.width = `${Math.min(
                        e.target.scrollWidth,
                        maxTextWidth
                      )}px`;
                      handleTextChange(e, idx);
                    }}
                    onBlur={() => finishTextEditing(idx)}
                    autoFocus
                  />
                ) : (
                  <div
                    style={{
                      color: "black",
                      whiteSpace: "pre-wrap",
                      fontSize: textAnno.fontSize
                        ? textAnno.fontSize + "px"
                        : DEFAULT_FONT_SIZE + "px",
                    }}
                  >
                    {textAnno.text || "New Text"}
                  </div>
                )}
                {textMode && activeTextIndex === idx && (
                  <div
                    style={{
                      position: "absolute",
                      bottom: "100%",
                      left: 0,
                      zIndex: 10,
                      display: "flex",
                      flexDirection: "column",
                      alignItems: "flex-start",
                    }}
                    onClick={(e) => e.stopPropagation()}
                  >
                    <button
                      style={{
                        fontSize: "10px",
                        cursor: "pointer",
                        backgroundColor: "black",
                        color: "white",
                        marginBottom: "2px",
                        touchAction: "auto", // Allow native touch behavior
                      }}
                      onClick={(e) => {
                        e.stopPropagation();
                        onRemoveText(pageNumber, idx);
                        setActiveTextIndex(null);
                      }}
                      onTouchStart={(e) => e.stopPropagation()} // Also stop propagation on touch
                    >
                      Remove
                    </button>
                    <select
                      value={textAnno.fontSize || DEFAULT_FONT_SIZE}
                      onChange={(e) => {
                        const newFontSize = parseInt(e.target.value, 10);
                        onUpdateText(pageNumber, idx, {
                          ...textAnno,
                          fontSize: newFontSize,
                        });
                      }}
                      onMouseDown={(e) => e.stopPropagation()}
                      onTouchStart={(e) => e.stopPropagation()} // Ensure touch events don’t bubble up
                      style={{
                        fontSize: "10px",
                        cursor: "pointer",
                        touchAction: "auto", // Allow native interaction
                      }}
                    >
                      <option value="10">10px</option>
                      <option value="12">12px</option>
                      <option value="14">14px</option>
                      <option value="16">16px</option>
                      <option value="18">18px</option>
                      <option value="20">20px</option>
                      <option value="24">24px</option>
                      <option value="28">28px</option>
                      <option value="32">32px</option>
                    </select>
                  </div>
                )}
              </div>
            );
          })}
          {/* Render in-progress drawings */}
          {drawingRect && (
            <div
              style={{
                position: "absolute",
                left: drawingRect.x,
                top: drawingRect.y,
                width: drawingRect.width,
                height: drawingRect.height,
                backgroundColor: hexToRgba(highlightColor, 0.3),
                border: `1px solid ${highlightColor}`,
                pointerEvents: "none",
                boxSizing: "border-box",
              }}
            ></div>
          )}
          {drawingPrivate && (
            <div
              style={{
                position: "absolute",
                left: drawingPrivate.x,
                top: drawingPrivate.y,
                width: drawingPrivate.width,
                height: drawingPrivate.height,
                backgroundColor: "black",
                border: "1px solid white",
                pointerEvents: "none",
                boxSizing: "border-box",
              }}
            ></div>
          )}
          {drawingImage && (
            <div
              style={{
                position: "absolute",
                left: drawingImage.x,
                top: drawingImage.y,
                width: drawingImage.width,
                height: drawingImage.height,
                backgroundColor: "rgba(255,255,255,0.7)",
                border: "1px solid black",
                pointerEvents: "none",
                boxSizing: "border-box",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                color: "black",
                fontSize: "12px",
                userSelect: "none",
              }}
            >
              New Image
            </div>
          )}
        </>
      ) : (
        <div
          style={{
            height: estimatedHeight
              ? `${estimatedHeight}px`
              : `${scale * 800}px`,
            backgroundColor: "#f0f0f0",
            border: "1px solid #ccc",
          }}
        ></div>
      )}
    </div>
  );
};

export default PDFPage;
