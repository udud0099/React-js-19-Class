"use client";

import dynamic from "next/dynamic";

const PDFViewer = dynamic(() => import("./_components/PDFViewer"), {
  ssr: false,
});

export default function Home() {
  return (
    <div
      style={{
        overflow: "auto",
        maxWidth: "100vw",
      }}
    >
      <PDFViewer pdfUrl="/sample.pdf" />
    </div>
  );
}
