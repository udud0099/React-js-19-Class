(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push(["static/chunks/src_app__components_PDFViewer_jsx_45a66c._.js", {

"[project]/src/app/_components/PDFViewer.jsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, k: __turbopack_refresh__, m: module, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$pdfjs$2d$dist$2f$build$2f$pdf$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/pdfjs-dist/build/pdf.mjs [app-client] (ecmascript)");
;
var _s = __turbopack_refresh__.signature();
"use client";
;
;
__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$pdfjs$2d$dist$2f$build$2f$pdf$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__.GlobalWorkerOptions.workerSrc = "/pdf.worker.js";
const DEFAULT_SCALE = 1.5;
const SCALE_STEP = 0.1;
const MIN_SCALE = 0.1;
const PDFViewer = ({ pdfUrl })=>{
    _s();
    const [pdf, setPdf] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [numPages, setNumPages] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    const [pageDimensions, setPageDimensions] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(true);
    const [currentPage, setCurrentPage] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(1);
    const [pageInput, setPageInput] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("1");
    const [pagesToRender, setPagesToRender] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(5);
    const [scale, setScale] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(DEFAULT_SCALE);
    const [highlightMode, setHighlightMode] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [privateInfoMode, setPrivateInfoMode] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [highlightColor, setHighlightColor] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("#FFFF00");
    // Data stored per page.
    const [highlights, setHighlights] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({});
    const [privateInfos, setPrivateInfos] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({});
    const sentinelRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const contentRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const ignoreScrollRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(false);
    const pinchStartDistanceRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const pinchStartScaleRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    // Load the PDF document.
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "PDFViewer.useEffect": ()=>{
            setLoading(true);
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$pdfjs$2d$dist$2f$build$2f$pdf$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__.getDocument(pdfUrl).promise.then({
                "PDFViewer.useEffect": (pdfDoc)=>{
                    setPdf(pdfDoc);
                    setNumPages(pdfDoc.numPages);
                    setLoading(false);
                }
            }["PDFViewer.useEffect"]).catch({
                "PDFViewer.useEffect": (error)=>{
                    console.error("Error loading PDF:", error);
                    setLoading(false);
                }
            }["PDFViewer.useEffect"]);
        }
    }["PDFViewer.useEffect"], [
        pdfUrl
    ]);
    // Pre-fetch page dimensions.
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "PDFViewer.useEffect": ()=>{
            if (pdf && numPages > 0) {
                let cancelled = false;
                const promises = [];
                for(let i = 1; i <= numPages; i++){
                    promises.push(pdf.getPage(i).then({
                        "PDFViewer.useEffect": (page)=>{
                            const viewport = page.getViewport({
                                scale
                            });
                            return viewport.height;
                        }
                    }["PDFViewer.useEffect"]));
                }
                Promise.all(promises).then({
                    "PDFViewer.useEffect": (heights)=>{
                        if (!cancelled) setPageDimensions(heights);
                    }
                }["PDFViewer.useEffect"]);
                return ({
                    "PDFViewer.useEffect": ()=>{
                        cancelled = true;
                    }
                })["PDFViewer.useEffect"];
            }
        }
    }["PDFViewer.useEffect"], [
        pdf,
        numPages,
        scale
    ]);
    const goToPage = (page, instant = false)=>{
        if (page < 1 || page > numPages) return;
        if (page > pagesToRender) setPagesToRender(page);
        const pageElement = document.getElementById(`page-${page}`);
        if (pageElement && contentRef.current) {
            const containerRect = contentRef.current.getBoundingClientRect();
            const elementRect = pageElement.getBoundingClientRect();
            const offset = elementRect.top - containerRect.top;
            contentRef.current.scrollTo({
                top: contentRef.current.scrollTop + offset,
                behavior: instant ? "auto" : "smooth"
            });
            ignoreScrollRef.current = true;
            setTimeout(()=>{
                ignoreScrollRef.current = false;
            }, 500);
            setCurrentPage(page);
            setPageInput(page.toString());
        }
    };
    const handlePrevious = ()=>{
        if (currentPage > 1) goToPage(currentPage - 1);
    };
    const handleNext = ()=>{
        if (currentPage < numPages) goToPage(currentPage + 1);
    };
    const handleGoToPage = ()=>{
        const page = Number(pageInput);
        if (!isNaN(page)) goToPage(page, true);
    };
    const handleZoomIn = ()=>setScale((prev)=>prev + SCALE_STEP);
    const handleZoomOut = ()=>setScale((prev)=>Math.max(MIN_SCALE, prev - SCALE_STEP));
    const toggleHighlightMode = ()=>{
        setHighlightMode((prev)=>!prev);
        if (privateInfoMode) setPrivateInfoMode(false);
    };
    const togglePrivateInfoMode = ()=>{
        setPrivateInfoMode((prev)=>!prev);
        if (highlightMode) setHighlightMode(false);
    };
    // Handlers for highlights.
    const handleAddHighlight = (pageNumber, highlightRect)=>{
        setHighlights((prev)=>{
            const pageHighlights = prev[pageNumber] || [];
            return {
                ...prev,
                [pageNumber]: [
                    ...pageHighlights,
                    highlightRect
                ]
            };
        });
    };
    const handleRemoveHighlight = (pageNumber, indexToRemove)=>{
        setHighlights((prev)=>{
            const pageHighlights = prev[pageNumber] || [];
            return {
                ...prev,
                [pageNumber]: pageHighlights.filter((_, idx)=>idx !== indexToRemove)
            };
        });
    };
    const handleUpdateHighlight = (pageNumber, indexToUpdate, newData)=>{
        setHighlights((prev)=>{
            const pageHighlights = prev[pageNumber] || [];
            const updatedHighlights = pageHighlights.map((hl, idx)=>idx === indexToUpdate ? {
                    ...hl,
                    ...newData
                } : hl);
            return {
                ...prev,
                [pageNumber]: updatedHighlights
            };
        });
    };
    // Handlers for private info boxes.
    const handleAddPrivateInfo = (pageNumber, boxRect)=>{
        setPrivateInfos((prev)=>{
            const pageBoxes = prev[pageNumber] || [];
            return {
                ...prev,
                [pageNumber]: [
                    ...pageBoxes,
                    boxRect
                ]
            };
        });
    };
    const handleRemovePrivateInfo = (pageNumber, indexToRemove)=>{
        setPrivateInfos((prev)=>{
            const pageBoxes = prev[pageNumber] || [];
            return {
                ...prev,
                [pageNumber]: pageBoxes.filter((_, idx)=>idx !== indexToRemove)
            };
        });
    };
    const handleUpdatePrivateInfo = (pageNumber, indexToUpdate, newRect)=>{
        setPrivateInfos((prev)=>{
            const pageBoxes = prev[pageNumber] || [];
            const updatedBoxes = pageBoxes.map((box, idx)=>idx === indexToUpdate ? {
                    ...box,
                    ...newRect
                } : box);
            return {
                ...prev,
                [pageNumber]: updatedBoxes
            };
        });
    };
    // Update current page based on scroll.
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "PDFViewer.useEffect": ()=>{
            const container = contentRef.current;
            if (!container) return;
            const handleScroll = {
                "PDFViewer.useEffect.handleScroll": ()=>{
                    if (ignoreScrollRef.current) return;
                    const pages = container.querySelectorAll("[id^='page-']");
                    let bestPageNumber = null;
                    let maxVisible = 0;
                    pages.forEach({
                        "PDFViewer.useEffect.handleScroll": (page)=>{
                            const rect = page.getBoundingClientRect();
                            const containerRect = container.getBoundingClientRect();
                            const visibleHeight = Math.max(0, Math.min(rect.bottom, containerRect.bottom) - Math.max(rect.top, containerRect.top));
                            const pageNumber = parseInt(page.id.replace("page-", ""), 10);
                            if (visibleHeight > maxVisible) {
                                maxVisible = visibleHeight;
                                bestPageNumber = pageNumber;
                            }
                        }
                    }["PDFViewer.useEffect.handleScroll"]);
                    if (bestPageNumber !== null) {
                        setCurrentPage({
                            "PDFViewer.useEffect.handleScroll": (prev)=>{
                                if (bestPageNumber !== prev) {
                                    setPageInput(bestPageNumber.toString());
                                    return bestPageNumber;
                                }
                                return prev;
                            }
                        }["PDFViewer.useEffect.handleScroll"]);
                    }
                }
            }["PDFViewer.useEffect.handleScroll"];
            container.addEventListener("scroll", handleScroll);
            return ({
                "PDFViewer.useEffect": ()=>container.removeEventListener("scroll", handleScroll)
            })["PDFViewer.useEffect"];
        }
    }["PDFViewer.useEffect"], []);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "PDFViewer.useEffect": ()=>{
            if (!loading && pdf && pagesToRender < numPages && sentinelRef.current) {
                const observer = new IntersectionObserver({
                    "PDFViewer.useEffect": (entries)=>{
                        entries.forEach({
                            "PDFViewer.useEffect": (entry)=>{
                                if (entry.isIntersecting) {
                                    setPagesToRender({
                                        "PDFViewer.useEffect": (prev)=>Math.min(prev + 5, numPages)
                                    }["PDFViewer.useEffect"]);
                                }
                            }
                        }["PDFViewer.useEffect"]);
                    }
                }["PDFViewer.useEffect"], {
                    threshold: 0.1
                });
                observer.observe(sentinelRef.current);
                return ({
                    "PDFViewer.useEffect": ()=>observer.disconnect()
                })["PDFViewer.useEffect"];
            }
        }
    }["PDFViewer.useEffect"], [
        loading,
        pdf,
        pagesToRender,
        numPages
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "PDFViewer.useEffect": ()=>{
            const container = contentRef.current;
            if (!container) return;
            let lastCall = 0;
            const handleWheel = {
                "PDFViewer.useEffect.handleWheel": (event)=>{
                    if (event.ctrlKey) {
                        event.preventDefault();
                        const now = Date.now();
                        if (now - lastCall < 50) return;
                        lastCall = now;
                        const zoomSensitivity = 0.002;
                        setScale({
                            "PDFViewer.useEffect.handleWheel": (prevScale)=>Math.max(MIN_SCALE, prevScale - event.deltaY * zoomSensitivity)
                        }["PDFViewer.useEffect.handleWheel"]);
                    }
                }
            }["PDFViewer.useEffect.handleWheel"];
            container.addEventListener("wheel", handleWheel, {
                passive: false
            });
            return ({
                "PDFViewer.useEffect": ()=>container.removeEventListener("wheel", handleWheel)
            })["PDFViewer.useEffect"];
        }
    }["PDFViewer.useEffect"], []);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "PDFViewer.useEffect": ()=>{
            const container = contentRef.current;
            if (!container) return;
            const handleTouchStart = {
                "PDFViewer.useEffect.handleTouchStart": (e)=>{
                    if (e.touches.length === 2) {
                        const dx = e.touches[0].clientX - e.touches[1].clientX;
                        const dy = e.touches[0].clientY - e.touches[1].clientY;
                        const distance = Math.hypot(dx, dy);
                        pinchStartDistanceRef.current = distance;
                        pinchStartScaleRef.current = scale;
                    }
                }
            }["PDFViewer.useEffect.handleTouchStart"];
            const handleTouchMove = {
                "PDFViewer.useEffect.handleTouchMove": (e)=>{
                    if (e.touches.length === 2 && pinchStartDistanceRef.current) {
                        e.preventDefault();
                        const dx = e.touches[0].clientX - e.touches[1].clientX;
                        const dy = e.touches[0].clientY - e.touches[1].clientY;
                        const currentDistance = Math.hypot(dx, dy);
                        const pinchRatio = currentDistance / pinchStartDistanceRef.current;
                        const TOUCH_SENSITIVITY = 0.8;
                        const adjustedRatio = 1 + (pinchRatio - 1) * TOUCH_SENSITIVITY;
                        const newScale = Math.max(MIN_SCALE, pinchStartScaleRef.current * adjustedRatio);
                        setScale(newScale);
                    }
                }
            }["PDFViewer.useEffect.handleTouchMove"];
            const handleTouchEnd = {
                "PDFViewer.useEffect.handleTouchEnd": (e)=>{
                    if (e.touches.length < 2) {
                        pinchStartDistanceRef.current = null;
                        pinchStartScaleRef.current = null;
                    }
                }
            }["PDFViewer.useEffect.handleTouchEnd"];
            container.addEventListener("touchstart", handleTouchStart, {
                passive: false
            });
            container.addEventListener("touchmove", handleTouchMove, {
                passive: false
            });
            container.addEventListener("touchend", handleTouchEnd, {
                passive: false
            });
            container.addEventListener("touchcancel", handleTouchEnd, {
                passive: false
            });
            return ({
                "PDFViewer.useEffect": ()=>{
                    container.removeEventListener("touchstart", handleTouchStart);
                    container.removeEventListener("touchmove", handleTouchMove);
                    container.removeEventListener("touchend", handleTouchEnd);
                    container.removeEventListener("touchcancel", handleTouchEnd);
                }
            })["PDFViewer.useEffect"];
        }
    }["PDFViewer.useEffect"], [
        scale
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        style: {
            fontFamily: "Arial, sans-serif"
        },
        children: [
            !loading && numPages > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                style: {
                    position: "fixed",
                    top: 0,
                    left: 0,
                    right: 0,
                    padding: "10px 20px",
                    backgroundColor: "black",
                    color: "white",
                    boxShadow: "0 2px 5px rgba(0,0,0,0.3)",
                    zIndex: 1000,
                    textAlign: "center",
                    display: "flex",
                    flexWrap: "wrap",
                    alignItems: "center",
                    justifyContent: "center",
                    gap: "10px",
                    overflowX: "auto"
                },
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: handlePrevious,
                        disabled: currentPage <= 1,
                        children: "Previous"
                    }, void 0, false, {
                        fileName: "[project]/src/app/_components/PDFViewer.jsx",
                        lineNumber: 326,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        children: [
                            "Page ",
                            currentPage,
                            " of ",
                            numPages
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/_components/PDFViewer.jsx",
                        lineNumber: 329,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: handleNext,
                        disabled: currentPage >= numPages,
                        children: "Next"
                    }, void 0, false, {
                        fileName: "[project]/src/app/_components/PDFViewer.jsx",
                        lineNumber: 332,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        children: [
                            "Go to page:",
                            " ",
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                type: "number",
                                min: "1",
                                max: numPages,
                                value: pageInput,
                                onChange: (e)=>setPageInput(e.target.value),
                                style: {
                                    width: "50px",
                                    color: "black"
                                }
                            }, void 0, false, {
                                fileName: "[project]/src/app/_components/PDFViewer.jsx",
                                lineNumber: 337,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: handleGoToPage,
                                children: "Go"
                            }, void 0, false, {
                                fileName: "[project]/src/app/_components/PDFViewer.jsx",
                                lineNumber: 345,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/_components/PDFViewer.jsx",
                        lineNumber: 335,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: handleZoomOut,
                                disabled: scale <= MIN_SCALE,
                                children: "Zoom Out"
                            }, void 0, false, {
                                fileName: "[project]/src/app/_components/PDFViewer.jsx",
                                lineNumber: 348,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                style: {
                                    margin: "0 5px"
                                },
                                children: [
                                    (scale * 100).toFixed(0),
                                    "%"
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/_components/PDFViewer.jsx",
                                lineNumber: 351,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: handleZoomIn,
                                children: "Zoom In"
                            }, void 0, false, {
                                fileName: "[project]/src/app/_components/PDFViewer.jsx",
                                lineNumber: 352,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/_components/PDFViewer.jsx",
                        lineNumber: 347,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            onClick: toggleHighlightMode,
                            style: {
                                backgroundColor: highlightMode ? "yellow" : "white",
                                color: "black"
                            },
                            children: highlightMode ? "Exit Highlight" : "Highlight"
                        }, void 0, false, {
                            fileName: "[project]/src/app/_components/PDFViewer.jsx",
                            lineNumber: 355,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/app/_components/PDFViewer.jsx",
                        lineNumber: 354,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            onClick: togglePrivateInfoMode,
                            style: {
                                backgroundColor: privateInfoMode ? "gray" : "white",
                                color: "black"
                            },
                            children: privateInfoMode ? "Exit Private Info" : "Private Info"
                        }, void 0, false, {
                            fileName: "[project]/src/app/_components/PDFViewer.jsx",
                            lineNumber: 366,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/app/_components/PDFViewer.jsx",
                        lineNumber: 365,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                htmlFor: "highlight-color",
                                children: "Highlight Color: "
                            }, void 0, false, {
                                fileName: "[project]/src/app/_components/PDFViewer.jsx",
                                lineNumber: 377,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                id: "highlight-color",
                                value: highlightColor,
                                onChange: (e)=>setHighlightColor(e.target.value),
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                        value: "#FFFF00",
                                        children: "Yellow"
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/_components/PDFViewer.jsx",
                                        lineNumber: 383,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                        value: "#00FF00",
                                        children: "Green"
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/_components/PDFViewer.jsx",
                                        lineNumber: 384,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                        value: "#0000FF",
                                        children: "Blue"
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/_components/PDFViewer.jsx",
                                        lineNumber: 385,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                        value: "#FFC0CB",
                                        children: "Pink"
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/_components/PDFViewer.jsx",
                                        lineNumber: 386,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                        value: "#FFA500",
                                        children: "Orange"
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/_components/PDFViewer.jsx",
                                        lineNumber: 387,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/_components/PDFViewer.jsx",
                                lineNumber: 378,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/_components/PDFViewer.jsx",
                        lineNumber: 376,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/_components/PDFViewer.jsx",
                lineNumber: 306,
                columnNumber: 9
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                ref: contentRef,
                style: {
                    padding: "20px",
                    marginTop: "50px",
                    overflow: "auto",
                    maxWidth: "100vw",
                    maxHeight: "calc(100vh - 70px)",
                    border: "1px solid red"
                },
                children: [
                    loading && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        children: "Loading PDF..."
                    }, void 0, false, {
                        fileName: "[project]/src/app/_components/PDFViewer.jsx",
                        lineNumber: 405,
                        columnNumber: 21
                    }, this),
                    !loading && pdf && Array.from({
                        length: Math.min(pagesToRender, numPages)
                    }, (_, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(PDFPage, {
                            pdf: pdf,
                            pageNumber: index + 1,
                            scale: scale,
                            estimatedHeight: pageDimensions[index],
                            highlightMode: highlightMode,
                            privateInfoMode: privateInfoMode,
                            highlights: highlights[index + 1] || [],
                            privateInfos: privateInfos[index + 1] || [],
                            onAddHighlight: handleAddHighlight,
                            onRemoveHighlight: handleRemoveHighlight,
                            onUpdateHighlight: handleUpdateHighlight,
                            onAddPrivateInfo: handleAddPrivateInfo,
                            onRemovePrivateInfo: handleRemovePrivateInfo,
                            onUpdatePrivateInfo: handleUpdatePrivateInfo,
                            highlightColor: highlightColor
                        }, index, false, {
                            fileName: "[project]/src/app/_components/PDFViewer.jsx",
                            lineNumber: 411,
                            columnNumber: 15
                        }, this)),
                    !loading && pdf && pagesToRender < numPages && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        ref: sentinelRef,
                        style: {
                            height: "20px"
                        }
                    }, void 0, false, {
                        fileName: "[project]/src/app/_components/PDFViewer.jsx",
                        lineNumber: 432,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/_components/PDFViewer.jsx",
                lineNumber: 394,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/app/_components/PDFViewer.jsx",
        lineNumber: 303,
        columnNumber: 5
    }, this);
};
_s(PDFViewer, "GAYahSzPNzUkHtBfnrIaez8k1ac=");
_c = PDFViewer;
const __TURBOPACK__default__export__ = PDFViewer;
var _c;
__turbopack_refresh__.register(_c, "PDFViewer");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_refresh__.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
}]);

//# sourceMappingURL=src_app__components_PDFViewer_jsx_45a66c._.js.map