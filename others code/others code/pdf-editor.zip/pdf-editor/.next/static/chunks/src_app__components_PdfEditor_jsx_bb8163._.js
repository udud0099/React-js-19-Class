(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app__components_PdfEditor_jsx_bb8163._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app__components_PdfEditor_jsx_bb8163._.js",
  "chunks": [
    "static/chunks/node_modules_979fd1._.js",
    "static/chunks/src_app__components_PdfEditor_jsx_c51545._.js"
  ],
  "source": "dynamic"
});
