(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push(["static/chunks/src_app_8ccaf3._.js", {

"[project]/src/app/_components/PDFViewer.jsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, k: __turbopack_refresh__, m: module, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$pdfjs$2d$dist$2f$build$2f$pdf$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/pdfjs-dist/build/pdf.mjs [app-client] (ecmascript)");
;
var _s = __turbopack_refresh__.signature(), _s1 = __turbopack_refresh__.signature();
"use client";
;
;
// Set PDF.js worker source – ensure pdf.worker.js is in your public/ folder.
__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$pdfjs$2d$dist$2f$build$2f$pdf$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__.GlobalWorkerOptions.workerSrc = "/pdf.worker.js";
// A component to render an individual PDF page into its own canvas.
const PDFPage = ({ page, scale, pageNumber })=>{
    _s();
    const canvasRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "PDFPage.useEffect": ()=>{
            // Get the viewport at the desired scale.
            const viewport = page.getViewport({
                scale
            });
            const canvas = canvasRef.current;
            // Determine the device pixel ratio for sharpness.
            const dpr = window.devicePixelRatio || 1;
            // Update canvas internal dimensions multiplied by the device pixel ratio.
            canvas.width = viewport.width * dpr;
            canvas.height = viewport.height * dpr;
            // Set the displayed size (CSS dimensions) to the original viewport size.
            canvas.style.width = `${viewport.width}px`;
            canvas.style.height = `${viewport.height}px`;
            // Scale the drawing context to account for the higher DPR.
            const context = canvas.getContext("2d");
            context.scale(dpr, dpr);
            // Render the page into the canvas and store the render task.
            const renderTask = page.render({
                canvasContext: context,
                viewport
            });
            // Catch cancellation errors so they don't appear in the console.
            renderTask.promise.catch({
                "PDFPage.useEffect": (error)=>{
                    if (error.name !== "RenderingCancelledException") {
                        console.error(error);
                    }
                }
            }["PDFPage.useEffect"]);
            // Cleanup: cancel the render task if the effect is re-run.
            return ({
                "PDFPage.useEffect": ()=>{
                    renderTask.cancel();
                }
            })["PDFPage.useEffect"];
        }
    }["PDFPage.useEffect"], [
        page,
        scale
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("canvas", {
        id: `page-${pageNumber}`,
        ref: canvasRef,
        style: {
            display: "block"
        }
    }, void 0, false, {
        fileName: "[project]/src/app/_components/PDFViewer.jsx",
        lineNumber: 53,
        columnNumber: 5
    }, this);
};
_s(PDFPage, "UJgi7ynoup7eqypjnwyX/s32POg=");
_c = PDFPage;
// Main PDFViewer component.
const PDFViewer = ({ pdfUrl })=>{
    _s1();
    const [pdf, setPdf] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [pages, setPages] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [currentPage, setCurrentPage] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(1);
    // Default scale is set to 1.5 but will be recalculated to auto-fit the page.
    const [scale, setScale] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(1.5);
    const containerRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const pinchStartRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    // Load the PDF document.
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "PDFViewer.useEffect": ()=>{
            const loadingTask = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$pdfjs$2d$dist$2f$build$2f$pdf$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__.getDocument(pdfUrl);
            loadingTask.promise.then({
                "PDFViewer.useEffect": (loadedPdf)=>{
                    setPdf(loadedPdf);
                    const numPages = loadedPdf.numPages;
                    let pagesArr = [];
                    for(let i = 1; i <= numPages; i++){
                        loadedPdf.getPage(i).then({
                            "PDFViewer.useEffect": (page)=>{
                                pagesArr.push({
                                    page,
                                    pageNumber: i
                                });
                                if (pagesArr.length === numPages) {
                                    pagesArr.sort({
                                        "PDFViewer.useEffect": (a, b)=>a.pageNumber - b.pageNumber
                                    }["PDFViewer.useEffect"]);
                                    setPages(pagesArr);
                                }
                            }
                        }["PDFViewer.useEffect"]);
                    }
                }
            }["PDFViewer.useEffect"]);
        }
    }["PDFViewer.useEffect"], [
        pdfUrl
    ]);
    // Auto-fit the PDF page to the container width when pages are loaded.
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "PDFViewer.useEffect": ()=>{
            if (pages.length > 0 && containerRef.current) {
                const containerWidth = containerRef.current.clientWidth;
                const firstPage = pages[0].page;
                const viewport = firstPage.getViewport({
                    scale: 1
                });
                const newScale = containerWidth * 0.9 / viewport.width;
                setScale(newScale);
            }
        }
    }["PDFViewer.useEffect"], [
        pages
    ]);
    // Re-calc the scale on window resize.
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "PDFViewer.useEffect": ()=>{
            const handleResize = {
                "PDFViewer.useEffect.handleResize": ()=>{
                    if (pages.length > 0 && containerRef.current) {
                        const containerWidth = containerRef.current.clientWidth;
                        const firstPage = pages[0].page;
                        const viewport = firstPage.getViewport({
                            scale: 1
                        });
                        const newScale = containerWidth * 0.9 / viewport.width;
                        setScale(newScale);
                    }
                }
            }["PDFViewer.useEffect.handleResize"];
            window.addEventListener("resize", handleResize);
            return ({
                "PDFViewer.useEffect": ()=>window.removeEventListener("resize", handleResize)
            })["PDFViewer.useEffect"];
        }
    }["PDFViewer.useEffect"], [
        pages
    ]);
    // When the currentPage changes, scroll that page into view (centered).
    // (We removed scale from the dependency so that zoom doesn't trigger scrolling.)
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "PDFViewer.useEffect": ()=>{
            const element = document.getElementById(`page-${currentPage}`);
            if (element) {
                element.scrollIntoView({
                    behavior: "smooth",
                    block: "center",
                    inline: "center"
                });
            }
        }
    }["PDFViewer.useEffect"], [
        currentPage
    ]);
    // Handle zooming with Ctrl + mouse wheel.
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "PDFViewer.useEffect": ()=>{
            const container = containerRef.current;
            if (!container) return;
            const handleWheel = {
                "PDFViewer.useEffect.handleWheel": (e)=>{
                    if (e.ctrlKey) {
                        e.preventDefault();
                        if (e.deltaY < 0) {
                            setScale({
                                "PDFViewer.useEffect.handleWheel": (prevScale)=>prevScale + 0.1
                            }["PDFViewer.useEffect.handleWheel"]); // Increase by 10%
                        } else {
                            setScale({
                                "PDFViewer.useEffect.handleWheel": (prevScale)=>Math.max(0.1, prevScale - 0.1)
                            }["PDFViewer.useEffect.handleWheel"]); // Decrease by 10%
                        }
                    }
                }
            }["PDFViewer.useEffect.handleWheel"];
            container.addEventListener("wheel", handleWheel, {
                passive: false
            });
            return ({
                "PDFViewer.useEffect": ()=>{
                    container.removeEventListener("wheel", handleWheel);
                }
            })["PDFViewer.useEffect"];
        }
    }["PDFViewer.useEffect"], []);
    // Handle pinch-to-zoom on touch devices.
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "PDFViewer.useEffect": ()=>{
            const container = containerRef.current;
            if (!container) return;
            const handleTouchStart = {
                "PDFViewer.useEffect.handleTouchStart": (e)=>{
                    if (e.touches.length === 2) {
                        const [touch1, touch2] = e.touches;
                        const dx = touch2.clientX - touch1.clientX;
                        const dy = touch2.clientY - touch1.clientY;
                        const distance = Math.hypot(dx, dy);
                        pinchStartRef.current = {
                            initialDistance: distance,
                            initialScale: scale
                        };
                        e.preventDefault();
                    }
                }
            }["PDFViewer.useEffect.handleTouchStart"];
            const handleTouchMove = {
                "PDFViewer.useEffect.handleTouchMove": (e)=>{
                    if (e.touches.length === 2 && pinchStartRef.current) {
                        const [touch1, touch2] = e.touches;
                        const dx = touch2.clientX - touch1.clientX;
                        const dy = touch2.clientY - touch1.clientY;
                        const newDistance = Math.hypot(dx, dy);
                        const { initialDistance, initialScale } = pinchStartRef.current;
                        const newScale = initialScale * (newDistance / initialDistance);
                        // Round the new scale to the nearest 0.1 to enforce 10% intervals.
                        setScale(Math.round(newScale * 10) / 10);
                        e.preventDefault();
                    }
                }
            }["PDFViewer.useEffect.handleTouchMove"];
            const handleTouchEnd = {
                "PDFViewer.useEffect.handleTouchEnd": (e)=>{
                    if (e.touches.length < 2) {
                        pinchStartRef.current = null;
                    }
                }
            }["PDFViewer.useEffect.handleTouchEnd"];
            container.addEventListener("touchstart", handleTouchStart, {
                passive: false
            });
            container.addEventListener("touchmove", handleTouchMove, {
                passive: false
            });
            container.addEventListener("touchend", handleTouchEnd, {
                passive: false
            });
            container.addEventListener("touchcancel", handleTouchEnd, {
                passive: false
            });
            return ({
                "PDFViewer.useEffect": ()=>{
                    container.removeEventListener("touchstart", handleTouchStart);
                    container.removeEventListener("touchmove", handleTouchMove);
                    container.removeEventListener("touchend", handleTouchEnd);
                    container.removeEventListener("touchcancel", handleTouchEnd);
                }
            })["PDFViewer.useEffect"];
        }
    }["PDFViewer.useEffect"], [
        scale
    ]);
    // Navigation button handlers.
    const handleNextPage = ()=>{
        if (currentPage < pages.length) {
            setCurrentPage(currentPage + 1);
        }
    };
    const handlePrevPage = ()=>{
        if (currentPage > 1) {
            setCurrentPage(currentPage - 1);
        }
    };
    // Zoom button handlers (10% intervals).
    const handleZoomIn = ()=>{
        setScale((prevScale)=>prevScale + 0.1);
    };
    const handleZoomOut = ()=>{
        setScale((prevScale)=>Math.max(0.1, prevScale - 0.1));
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                style: {
                    position: "fixed",
                    top: 0,
                    left: 0,
                    right: 0,
                    background: "black",
                    padding: "10px",
                    boxShadow: "0 2px 4px rgba(0,0,0,0.1)",
                    zIndex: 1000,
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    color: "white"
                },
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: handlePrevPage,
                        disabled: currentPage <= 1,
                        children: "Previous"
                    }, void 0, false, {
                        fileName: "[project]/src/app/_components/PDFViewer.jsx",
                        lineNumber: 250,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        style: {
                            margin: "0 10px"
                        },
                        children: [
                            "Page ",
                            currentPage,
                            " of ",
                            pages.length
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/_components/PDFViewer.jsx",
                        lineNumber: 253,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: handleNextPage,
                        disabled: currentPage >= pages.length,
                        children: "Next"
                    }, void 0, false, {
                        fileName: "[project]/src/app/_components/PDFViewer.jsx",
                        lineNumber: 256,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        style: {
                            margin: "0 10px"
                        },
                        children: [
                            "Zoom: ",
                            (scale * 100).toFixed(0),
                            "%"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/_components/PDFViewer.jsx",
                        lineNumber: 259,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: handleZoomOut,
                        disabled: scale <= 0.1,
                        children: "Zoom Out"
                    }, void 0, false, {
                        fileName: "[project]/src/app/_components/PDFViewer.jsx",
                        lineNumber: 262,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: handleZoomIn,
                        children: "Zoom In"
                    }, void 0, false, {
                        fileName: "[project]/src/app/_components/PDFViewer.jsx",
                        lineNumber: 265,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/_components/PDFViewer.jsx",
                lineNumber: 234,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                ref: containerRef,
                style: {
                    marginTop: "70px",
                    overflow: "auto",
                    width: "100%",
                    height: "calc(100vh - 70px)",
                    touchAction: "pan-x pan-y"
                },
                children: pages.map(({ page, pageNumber })=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        style: {
                            display: "flex",
                            justifyContent: "center",
                            marginBottom: "20px"
                        },
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(PDFPage, {
                            page: page,
                            scale: scale,
                            pageNumber: pageNumber
                        }, void 0, false, {
                            fileName: "[project]/src/app/_components/PDFViewer.jsx",
                            lineNumber: 288,
                            columnNumber: 13
                        }, this)
                    }, pageNumber, false, {
                        fileName: "[project]/src/app/_components/PDFViewer.jsx",
                        lineNumber: 280,
                        columnNumber: 11
                    }, this))
            }, void 0, false, {
                fileName: "[project]/src/app/_components/PDFViewer.jsx",
                lineNumber: 269,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/app/_components/PDFViewer.jsx",
        lineNumber: 232,
        columnNumber: 5
    }, this);
};
_s1(PDFViewer, "/0aIZspOR5ByGTO7RircIsFJ8AY=");
_c1 = PDFViewer;
const __TURBOPACK__default__export__ = PDFViewer;
var _c, _c1;
__turbopack_refresh__.register(_c, "PDFPage");
__turbopack_refresh__.register(_c1, "PDFViewer");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_refresh__.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/app/page.js [app-rsc] (ecmascript, Next.js server component, client modules)": ((__turbopack_context__) => {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, t: __turbopack_require_real__ } = __turbopack_context__;
{
}}),
}]);

//# sourceMappingURL=src_app_8ccaf3._.js.map