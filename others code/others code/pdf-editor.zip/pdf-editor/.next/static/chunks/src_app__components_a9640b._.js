(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push(["static/chunks/src_app__components_a9640b._.js", {

"[project]/src/app/_components/PDFPage.jsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, k: __turbopack_refresh__, m: module, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$pdfjs$2d$dist$2f$build$2f$pdf$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/pdfjs-dist/build/pdf.mjs [app-client] (ecmascript)");
;
var _s = __turbopack_refresh__.signature();
"use client";
;
;
// Set the PDF.js worker source – ensure pdf.worker.js is in your public/ folder.
__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$pdfjs$2d$dist$2f$build$2f$pdf$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__.GlobalWorkerOptions.workerSrc = "/pdf.worker.js";
// Fixed render scale for PDF.js (pages are rendered once at this scale)
const DEFAULT_SCALE = 1.5;
// Default font size for text annotations.
const DEFAULT_FONT_SIZE = 14;
// Long-press constants for mobile (touch events)
const LONG_PRESS_DURATION = 300; // milliseconds before long press is detected
const MOVE_THRESHOLD = 10; // maximum movement (in pixels) allowed before canceling long press
/**
 * computeNewAnnotation
 *
 * Given an original normalized annotation {x, y, width, height}, normalized
 * delta changes (ndx, ndy), and a handle direction (one of "nw", "n", "ne", "e",
 * "se", "s", "sw", "w"), compute a new annotation.
 */ function computeNewAnnotation(original, ndx, ndy, direction) {
    let newX = original.x;
    let newY = original.y;
    let newWidth = original.width;
    let newHeight = original.height;
    switch(direction){
        case "nw":
            newX = original.x + ndx;
            newY = original.y + ndy;
            newWidth = original.width - ndx;
            newHeight = original.height - ndy;
            break;
        case "n":
            newY = original.y + ndy;
            newHeight = original.height - ndy;
            break;
        case "ne":
            newY = original.y + ndy;
            newWidth = original.width + ndx;
            newHeight = original.height - ndy;
            break;
        case "e":
            newWidth = original.width + ndx;
            break;
        case "se":
            newWidth = original.width + ndx;
            newHeight = original.height + ndy;
            break;
        case "s":
            newHeight = original.height + ndy;
            break;
        case "sw":
            newX = original.x + ndx;
            newWidth = original.width - ndx;
            newHeight = original.height + ndy;
            break;
        case "w":
            newX = original.x + ndx;
            newWidth = original.width - ndx;
            break;
        default:
            break;
    }
    // Enforce a minimum size.
    const minSize = 0.05;
    if (newWidth < minSize) {
        newWidth = minSize;
        if ([
            "nw",
            "w",
            "sw"
        ].includes(direction)) {
            newX = original.x + original.width - minSize;
        }
    }
    if (newHeight < minSize) {
        newHeight = minSize;
        if ([
            "nw",
            "n",
            "ne"
        ].includes(direction)) {
            newY = original.y + original.height - minSize;
        }
    }
    // Clamp to boundaries (0 to 1)
    newX = Math.max(0, newX);
    newY = Math.max(0, newY);
    if (newX + newWidth > 1) {
        newWidth = 1 - newX;
    }
    if (newY + newHeight > 1) {
        newHeight = 1 - newY;
    }
    return {
        x: newX,
        y: newY,
        width: newWidth,
        height: newHeight
    };
}
/**
 * PDFPage Component
 *
 * Renders a PDF page on a canvas and overlays several kinds of annotations:
 * - Highlights
 * - Private info boxes (redact)
 * - Image annotations
 * - **Text annotations**
 *
 * When textMode is enabled the following text annotation functionality is active:
 * - Clicking (or tapping) on an empty part of the page adds a new text annotation and immediately
 *   activates its textarea (with a blinking I‑beam cursor).
 * - The textarea is initially one row tall and auto-resizes so that its height (and width)
 *   is not fixed.
 * - When not editing, text annotations are draggable and their hover cursor is set to "move".
 * - Double‑clicking an annotation enters edit mode.
 *
 * Additionally, if the user creates a new text annotation while a previously added one remains empty,
 * the previous empty annotation is removed before adding the new one.
 *
 * Now the user can also change the font size for each text annotation.
 */ const PDFPage = ({ pdf, pageNumber, scale = DEFAULT_SCALE, estimatedHeight, // Modes:
highlightMode = false, privateInfoMode = false, imageMode = false, textMode = false, // Annotation arrays:
highlights = [], privateInfos = [], images = [], texts = [], // Callbacks for highlights:
onAddHighlight = ()=>{}, onRemoveHighlight = ()=>{}, onUpdateHighlight = ()=>{}, // Callbacks for private info boxes:
onAddPrivateInfo = ()=>{}, onRemovePrivateInfo = ()=>{}, onUpdatePrivateInfo = ()=>{}, // Callbacks for image annotations:
onAddImage = ()=>{}, onRemoveImage = ()=>{}, onUpdateImage = ()=>{}, // Callbacks for text annotations:
onAddText = ()=>{}, onRemoveText = ()=>{}, onUpdateText = ()=>{}, // Colors and image source:
highlightColor = "#FFFF00", imageSrc = "" })=>{
    _s();
    const containerRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const canvasRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    // Refs for long-press detection (touch events)
    const longPressTimerRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const initialTouchRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])({
        x: 0,
        y: 0
    });
    const privateLongPressTimerRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const highlightLongPressTimerRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const imageLongPressTimerRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const textLongPressTimerRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    // Resizing state and refs for each annotation type
    const [resizingImageIndex, setResizingImageIndex] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const resizingImageDataRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const [resizingHighlightIndex, setResizingHighlightIndex] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const resizingHighlightDataRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const [resizingPrivateIndex, setResizingPrivateIndex] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const resizingPrivateDataRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    // State for text annotation dragging and editing
    const [draggingTextIndex, setDraggingTextIndex] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [dragTextOffset, setDragTextOffset] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        x: 0,
        y: 0
    });
    const [activeTextIndex, setActiveTextIndex] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [editingTextIndex, setEditingTextIndex] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    // Other state: dragging, drawing, active indices, canvas dimensions, etc.
    const [canvasDimensions, setCanvasDimensions] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        width: 1,
        height: 1
    });
    const [isVisible, setIsVisible] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [loaded, setLoaded] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const renderTaskRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    // For highlights and private info, we keep drawing states.
    const [drawingRect, setDrawingRect] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null); // for new highlights
    const [drawingPrivate, setDrawingPrivate] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null); // for new private info boxes
    // Removed drawingText state because text is now added immediately.
    const [drawingImage, setDrawingImage] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null); // for new image annotations
    const [draggingPrivateIndex, setDraggingPrivateIndex] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [dragOffset, setDragOffset] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        x: 0,
        y: 0
    });
    const [draggingHighlightIndex, setDraggingHighlightIndex] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [dragHighlightOffset, setDragHighlightOffset] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        x: 0,
        y: 0
    });
    const [draggingImageIndex, setDraggingImageIndex] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [dragImageOffset, setDragImageOffset] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        x: 0,
        y: 0
    });
    const [activeHighlightIndex, setActiveHighlightIndex] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [activePrivateIndex, setActivePrivateIndex] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [activeImageIndex, setActiveImageIndex] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    // Helper: convert hex color to rgba string.
    const hexToRgba = (hex, alpha = 0.3)=>{
        if (!hex) return `rgba(255,255,0,${alpha})`;
        hex = hex.replace("#", "");
        if (hex.length === 3) {
            hex = hex.split("").map((c)=>c + c).join("");
        }
        const r = parseInt(hex.substring(0, 2), 16);
        const g = parseInt(hex.substring(2, 4), 16);
        const b = parseInt(hex.substring(4, 6), 16);
        return `rgba(${r}, ${g}, ${b}, ${alpha})`;
    };
    // Update canvas dimensions.
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "PDFPage.useEffect": ()=>{
            const updateCanvasDimensions = {
                "PDFPage.useEffect.updateCanvasDimensions": ()=>{
                    if (canvasRef.current) {
                        const rect = canvasRef.current.getBoundingClientRect();
                        setCanvasDimensions({
                            width: rect.width,
                            height: rect.height
                        });
                    }
                }
            }["PDFPage.useEffect.updateCanvasDimensions"];
            updateCanvasDimensions();
            window.addEventListener("resize", updateCanvasDimensions);
            return ({
                "PDFPage.useEffect": ()=>window.removeEventListener("resize", updateCanvasDimensions)
            })["PDFPage.useEffect"];
        }
    }["PDFPage.useEffect"], [
        loaded,
        scale
    ]);
    // When scale or pdf changes, reset the loaded state so the page is re-rendered.
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "PDFPage.useEffect": ()=>{
            setLoaded(false);
        }
    }["PDFPage.useEffect"], [
        scale,
        pdf
    ]);
    // IntersectionObserver for lazy loading.
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "PDFPage.useEffect": ()=>{
            const observer = new IntersectionObserver({
                "PDFPage.useEffect": (entries)=>{
                    entries.forEach({
                        "PDFPage.useEffect": (entry)=>{
                            if (entry.isIntersecting) {
                                setIsVisible(true);
                                observer.unobserve(entry.target);
                            }
                        }
                    }["PDFPage.useEffect"]);
                }
            }["PDFPage.useEffect"], {
                threshold: 0.1
            });
            if (containerRef.current) observer.observe(containerRef.current);
            return ({
                "PDFPage.useEffect": ()=>{
                    if (containerRef.current) observer.unobserve(containerRef.current);
                }
            })["PDFPage.useEffect"];
        }
    }["PDFPage.useEffect"], []);
    // Load and render PDF page.
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "PDFPage.useEffect": ()=>{
            let isMounted = true;
            if (isVisible && !loaded) {
                pdf.getPage(pageNumber).then({
                    "PDFPage.useEffect": (page)=>{
                        if (!isMounted) return;
                        const viewport = page.getViewport({
                            scale
                        });
                        const canvas = canvasRef.current;
                        if (!canvas) return;
                        const devicePixelRatio = window.devicePixelRatio || 1;
                        canvas.width = viewport.width * devicePixelRatio;
                        canvas.height = viewport.height * devicePixelRatio;
                        canvas.style.width = `${viewport.width}px`;
                        canvas.style.height = `${viewport.height}px`;
                        const context = canvas.getContext("2d");
                        context.scale(devicePixelRatio, devicePixelRatio);
                        const renderContext = {
                            canvasContext: context,
                            viewport
                        };
                        renderTaskRef.current = page.render(renderContext);
                        renderTaskRef.current.promise.then({
                            "PDFPage.useEffect": ()=>{
                                if (isMounted) setLoaded(true);
                            }
                        }["PDFPage.useEffect"]).catch({
                            "PDFPage.useEffect": (error)=>{
                                if (error && error.name === "RenderingCancelledException") {
                                // Ignore cancellation.
                                } else {
                                    console.error("Error during rendering:", error);
                                }
                            }
                        }["PDFPage.useEffect"]);
                    }
                }["PDFPage.useEffect"]);
            }
            return ({
                "PDFPage.useEffect": ()=>{
                    isMounted = false;
                    if (renderTaskRef.current && renderTaskRef.current.cancel) {
                        renderTaskRef.current.cancel();
                    }
                }
            })["PDFPage.useEffect"];
        }
    }["PDFPage.useEffect"], [
        isVisible,
        loaded,
        pdf,
        pageNumber,
        scale
    ]);
    const getReferenceRect = ()=>{
        if (canvasRef.current) return canvasRef.current.getBoundingClientRect();
        return containerRef.current.getBoundingClientRect();
    };
    const clamp = (val, min, max)=>Math.max(min, Math.min(val, max));
    // --- Basic Mouse Handlers for Drawing & Dragging ---
    const handleMouseDown = (e)=>{
        // If any resizing is active, do nothing.
        if (resizingHighlightIndex !== null || resizingPrivateIndex !== null || resizingImageIndex !== null) return;
        const rect = getReferenceRect();
        const x = clamp(e.clientX - rect.left, 0, rect.width);
        const y = clamp(e.clientY - rect.top, 0, rect.height);
        if (highlightMode) {
            setDrawingRect({
                startX: x,
                startY: y,
                x,
                y,
                width: 0,
                height: 0
            });
        } else if (privateInfoMode) {
            setDrawingPrivate({
                startX: x,
                startY: y,
                x,
                y,
                width: 0,
                height: 0
            });
        } else if (textMode && e.target === containerRef.current) {
            // If there is an existing text annotation with empty text,
            // remove it before adding a new one.
            const emptyTextIndex = texts.findIndex((t)=>t.text.trim() === "");
            if (emptyTextIndex !== -1) {
                onRemoveText(pageNumber, emptyTextIndex);
            }
            // When textMode is on and the user clicks the background,
            // add a new text annotation with default dimensions and start editing.
            const defaultWidth = 100; // pixels
            const defaultHeight = 30; // pixels
            const normalizedText = {
                x: x / rect.width,
                y: y / rect.height,
                width: defaultWidth / rect.width,
                height: defaultHeight / rect.height,
                text: "",
                fontSize: DEFAULT_FONT_SIZE
            };
            onAddText(pageNumber, normalizedText);
            // Assume the new annotation is appended; set its index as the new text.
            const newIndex = texts.length;
            setActiveTextIndex(newIndex);
            setEditingTextIndex(newIndex);
        }
    };
    const handleMouseMove = (e)=>{
        // Do not process drag events if resizing is active.
        if (resizingHighlightIndex !== null || resizingPrivateIndex !== null || resizingImageIndex !== null) return;
        const rect = getReferenceRect();
        if (draggingHighlightIndex !== null) {
            let newX = (e.clientX - rect.left - dragHighlightOffset.x) / rect.width;
            let newY = (e.clientY - rect.top - dragHighlightOffset.y) / rect.height;
            const hl = highlights[draggingHighlightIndex];
            newX = clamp(newX, 0, 1 - hl.width);
            newY = clamp(newY, 0, 1 - hl.height);
            onUpdateHighlight(pageNumber, draggingHighlightIndex, {
                ...hl,
                x: newX,
                y: newY
            });
            return;
        }
        if (draggingPrivateIndex !== null) {
            const { x: offsetX, y: offsetY } = dragOffset;
            let newX = (e.clientX - rect.left - offsetX) / rect.width;
            let newY = (e.clientY - rect.top - offsetY) / rect.height;
            const box = privateInfos[draggingPrivateIndex];
            newX = clamp(newX, 0, 1 - box.width);
            newY = clamp(newY, 0, 1 - box.height);
            onUpdatePrivateInfo(pageNumber, draggingPrivateIndex, {
                ...box,
                x: newX,
                y: newY
            });
            return;
        }
        if (draggingImageIndex !== null) {
            // Handled in global pointer listeners.
            return;
        }
        if (draggingTextIndex !== null) {
            // Handled in its own global pointer listener.
            return;
        }
        const currentX = clamp(e.clientX - rect.left, 0, rect.width);
        const currentY = clamp(e.clientY - rect.top, 0, rect.height);
        if (highlightMode && drawingRect) {
            const x = Math.min(drawingRect.startX, currentX);
            const y = Math.min(drawingRect.startY, currentY);
            const width = Math.abs(currentX - drawingRect.startX);
            const height = Math.abs(currentY - drawingRect.startY);
            setDrawingRect({
                ...drawingRect,
                x,
                y,
                width,
                height
            });
        } else if (privateInfoMode && drawingPrivate) {
            const x = Math.min(drawingPrivate.startX, currentX);
            const y = Math.min(drawingPrivate.startY, currentY);
            const width = Math.abs(currentX - drawingPrivate.startX);
            const height = Math.abs(currentY - drawingPrivate.startY);
            setDrawingPrivate({
                ...drawingPrivate,
                x,
                y,
                width,
                height
            });
        }
    // No drawing state for text since it is added immediately.
    };
    const handleMouseUp = (e)=>{
        if (draggingHighlightIndex !== null) {
            setDraggingHighlightIndex(null);
            setDragHighlightOffset({
                x: 0,
                y: 0
            });
            return;
        }
        if (draggingPrivateIndex !== null) {
            setDraggingPrivateIndex(null);
            setDragOffset({
                x: 0,
                y: 0
            });
            return;
        }
        if (draggingImageIndex !== null) {
            setDraggingImageIndex(null);
            setDragImageOffset({
                x: 0,
                y: 0
            });
            return;
        }
        if (draggingTextIndex !== null) {
            // Handled by pointerup listener.
            return;
        }
        if (highlightMode && drawingRect) {
            if (drawingRect.width > 5 && drawingRect.height > 5) {
                const rect = getReferenceRect();
                const normalizedHighlight = {
                    x: drawingRect.x / rect.width,
                    y: drawingRect.y / rect.height,
                    width: drawingRect.width / rect.width,
                    height: drawingRect.height / rect.height,
                    color: highlightColor
                };
                onAddHighlight(pageNumber, normalizedHighlight);
            }
            setDrawingRect(null);
        } else if (privateInfoMode && drawingPrivate) {
            if (drawingPrivate.width > 5 && drawingPrivate.height > 5) {
                const rect = getReferenceRect();
                const normalizedPrivate = {
                    x: drawingPrivate.x / rect.width,
                    y: drawingPrivate.y / rect.height,
                    width: drawingPrivate.width / rect.width,
                    height: drawingPrivate.height / rect.height
                };
                onAddPrivateInfo(pageNumber, normalizedPrivate);
            }
            setDrawingPrivate(null);
        }
    // No text-mode handling needed on mouse up.
    };
    const handleHighlightMouseDown = (e, idx)=>{
        e.stopPropagation();
        const rect = getReferenceRect();
        const hl = highlights[idx];
        const absX = hl.x * rect.width;
        const absY = hl.y * rect.height;
        const offsetX = e.clientX - rect.left - absX;
        const offsetY = e.clientY - rect.top - absY;
        setDraggingHighlightIndex(idx);
        setDragHighlightOffset({
            x: offsetX,
            y: offsetY
        });
        setActiveHighlightIndex(idx);
    };
    const handlePrivateMouseDown = (e, idx)=>{
        e.stopPropagation();
        const rect = getReferenceRect();
        const box = privateInfos[idx];
        const absX = box.x * rect.width;
        const absY = box.y * rect.height;
        const offsetX = e.clientX - rect.left - absX;
        const offsetY = e.clientY - rect.top - absY;
        setDraggingPrivateIndex(idx);
        setDragOffset({
            x: offsetX,
            y: offsetY
        });
        setActivePrivateIndex(idx);
    };
    const handleImageMouseDown = (e, idx)=>{
        e.stopPropagation();
        const rect = getReferenceRect();
        const imgAnno = images[idx];
        const absX = imgAnno.x * rect.width;
        const absY = imgAnno.y * rect.height;
        const offsetX = e.clientX - rect.left - absX;
        const offsetY = e.clientY - rect.top - absY;
        setDraggingImageIndex(idx);
        setDragImageOffset({
            x: offsetX,
            y: offsetY
        });
        setActiveImageIndex(idx);
    };
    // --- TEXT ANNOTATION HANDLERS (Active only if textMode is enabled) ---
    const handleTextMouseDown = (e, idx)=>{
        if (!textMode) return;
        // If the annotation is in editing mode, do not start dragging.
        if (editingTextIndex === idx) return;
        e.stopPropagation();
        const rect = getReferenceRect();
        const textAnno = texts[idx];
        const absX = textAnno.x * canvasDimensions.width;
        const absY = textAnno.y * canvasDimensions.height;
        const offsetX = e.clientX - rect.left - absX;
        const offsetY = e.clientY - rect.top - absY;
        setDraggingTextIndex(idx);
        setDragTextOffset({
            x: offsetX,
            y: offsetY
        });
        setActiveTextIndex(idx);
    };
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "PDFPage.useEffect": ()=>{
            if (draggingTextIndex !== null && textMode) {
                const handlePointerMove = {
                    "PDFPage.useEffect.handlePointerMove": (e)=>{
                        const rect = getReferenceRect();
                        let newX = (e.clientX - rect.left - dragTextOffset.x) / rect.width;
                        let newY = (e.clientY - rect.top - dragTextOffset.y) / rect.height;
                        const textAnno = texts[draggingTextIndex];
                        // Allow moving the text freely by clamping between 0 and 1
                        newX = clamp(newX, 0, 1);
                        newY = clamp(newY, 0, 1);
                        onUpdateText(pageNumber, draggingTextIndex, {
                            ...textAnno,
                            x: newX,
                            y: newY
                        });
                    }
                }["PDFPage.useEffect.handlePointerMove"];
                const handlePointerUp = {
                    "PDFPage.useEffect.handlePointerUp": ()=>{
                        setDraggingTextIndex(null);
                        setDragTextOffset({
                            x: 0,
                            y: 0
                        });
                    }
                }["PDFPage.useEffect.handlePointerUp"];
                window.addEventListener("pointermove", handlePointerMove);
                window.addEventListener("pointerup", handlePointerUp);
                return ({
                    "PDFPage.useEffect": ()=>{
                        window.removeEventListener("pointermove", handlePointerMove);
                        window.removeEventListener("pointerup", handlePointerUp);
                    }
                })["PDFPage.useEffect"];
            }
        }
    }["PDFPage.useEffect"], [
        draggingTextIndex,
        dragTextOffset,
        texts,
        pageNumber,
        onUpdateText,
        textMode
    ]);
    const handleTextTouchStart = (e, idx)=>{
        if (!textMode) return;
        e.stopPropagation();
        if (e.touches.length !== 1) return;
        const touch = e.touches[0];
        const rect = getReferenceRect();
        initialTouchRef.current = {
            x: touch.clientX,
            y: touch.clientY,
            idx
        };
        textLongPressTimerRef.current = setTimeout(()=>{
            const textAnno = texts[idx];
            const absX = textAnno.x * canvasDimensions.width;
            const absY = textAnno.y * canvasDimensions.height;
            const offsetX = touch.clientX - rect.left - absX;
            const offsetY = touch.clientY - rect.top - absY;
            setDraggingTextIndex(idx);
            setDragTextOffset({
                x: offsetX,
                y: offsetY
            });
            setActiveTextIndex(idx);
            textLongPressTimerRef.current = null;
        }, LONG_PRESS_DURATION);
    };
    const handleTextTouchMove = (e, idx)=>{
        if (!textMode) return;
        if (e.touches.length !== 1) return;
        const touch = e.touches[0];
        const rect = getReferenceRect();
        const { x, y } = initialTouchRef.current;
        const distance = Math.hypot(touch.clientX - x, touch.clientY - y);
        if (textLongPressTimerRef.current && distance > MOVE_THRESHOLD) {
            clearTimeout(textLongPressTimerRef.current);
            textLongPressTimerRef.current = null;
        }
        if (draggingTextIndex === idx) {
            let newX = (touch.clientX - rect.left - dragTextOffset.x) / rect.width;
            let newY = (touch.clientY - rect.top - dragTextOffset.y) / rect.height;
            const textAnno = texts[idx];
            // Allow moving freely by clamping from 0 to 1
            newX = clamp(newX, 0, 1);
            newY = clamp(newY, 0, 1);
            onUpdateText(pageNumber, idx, {
                ...textAnno,
                x: newX,
                y: newY
            });
            e.preventDefault();
        }
    };
    const handleTextTouchEnd = (e, idx)=>{
        if (!textMode) return;
        if (textLongPressTimerRef.current) {
            clearTimeout(textLongPressTimerRef.current);
            textLongPressTimerRef.current = null;
        }
        if (draggingTextIndex === idx) {
            setDraggingTextIndex(null);
            setDragTextOffset({
                x: 0,
                y: 0
            });
            e.preventDefault();
        }
    };
    // Handlers for text editing.
    // We use an auto-resize technique by setting the height and width based on scrollHeight and scrollWidth.
    const handleTextChange = (e, idx)=>{
        e.target.style.height = "auto";
        e.target.style.width = "auto";
        e.target.style.height = e.target.scrollHeight + "px";
        const containerWidth = containerRef.current.getBoundingClientRect().width;
        e.target.style.width = Math.min(e.target.scrollWidth, containerWidth) + "px";
        const newText = e.target.value;
        const textAnno = texts[idx];
        onUpdateText(pageNumber, idx, {
            ...textAnno,
            text: newText
        });
    };
    const finishTextEditing = (idx)=>{
        setEditingTextIndex(null);
    };
    // --- RESIZING HANDLERS USING POINTER EVENTS (for images, highlights, private infos) ---
    // IMAGE RESIZING
    const handleImageResizePointerDown = (e, idx, direction)=>{
        e.stopPropagation();
        e.preventDefault();
        e.target.setPointerCapture(e.pointerId);
        const rect = getReferenceRect();
        const imgAnno = images[idx];
        resizingImageDataRef.current = {
            idx,
            startClientX: e.clientX,
            startClientY: e.clientY,
            original: {
                ...imgAnno
            },
            direction,
            canvasRect: rect
        };
        setResizingImageIndex(idx);
        window.addEventListener("pointermove", handleImageResizePointerMove);
        window.addEventListener("pointerup", handleImageResizePointerUp);
    };
    const handleImageResizePointerMove = (e)=>{
        if (!resizingImageDataRef.current) return;
        const { idx, canvasRect, original, direction, startClientX, startClientY } = resizingImageDataRef.current;
        const deltaX = e.clientX - startClientX;
        const deltaY = e.clientY - startClientY;
        const ndx = deltaX / canvasRect.width;
        const ndy = deltaY / canvasRect.height;
        const newAnno = computeNewAnnotation(original, ndx, ndy, direction);
        onUpdateImage(pageNumber, idx, newAnno);
    };
    const handleImageResizePointerUp = (e)=>{
        setResizingImageIndex(null);
        resizingImageDataRef.current = null;
        window.removeEventListener("pointermove", handleImageResizePointerMove);
        window.removeEventListener("pointerup", handleImageResizePointerUp);
    };
    // HIGHLIGHT RESIZING
    const handleHighlightResizePointerDown = (e, idx, direction)=>{
        e.stopPropagation();
        e.preventDefault();
        e.target.setPointerCapture(e.pointerId);
        const rect = getReferenceRect();
        const hl = highlights[idx];
        resizingHighlightDataRef.current = {
            idx,
            startClientX: e.clientX,
            startClientY: e.clientY,
            original: {
                ...hl
            },
            direction,
            canvasRect: rect
        };
        setResizingHighlightIndex(idx);
        window.addEventListener("pointermove", handleHighlightResizePointerMove);
        window.addEventListener("pointerup", handleHighlightResizePointerUp);
    };
    const handleHighlightResizePointerMove = (e)=>{
        if (!resizingHighlightDataRef.current) return;
        const { idx, canvasRect, original, direction, startClientX, startClientY } = resizingHighlightDataRef.current;
        const deltaX = e.clientX - startClientX;
        const deltaY = e.clientY - startClientY;
        const ndx = deltaX / canvasRect.width;
        const ndy = deltaY / canvasRect.height;
        const newAnno = computeNewAnnotation(original, ndx, ndy, direction);
        onUpdateHighlight(pageNumber, idx, newAnno);
    };
    const handleHighlightResizePointerUp = (e)=>{
        setResizingHighlightIndex(null);
        resizingHighlightDataRef.current = null;
        window.removeEventListener("pointermove", handleHighlightResizePointerMove);
        window.removeEventListener("pointerup", handleHighlightResizePointerUp);
    };
    // PRIVATE INFO (REDACT) RESIZING
    const handlePrivateResizePointerDown = (e, idx, direction)=>{
        e.stopPropagation();
        e.preventDefault();
        e.target.setPointerCapture(e.pointerId);
        const rect = getReferenceRect();
        const pi = privateInfos[idx];
        resizingPrivateDataRef.current = {
            idx,
            startClientX: e.clientX,
            startClientY: e.clientY,
            original: {
                ...pi
            },
            direction,
            canvasRect: rect
        };
        setResizingPrivateIndex(idx);
        window.addEventListener("pointermove", handlePrivateResizePointerMove);
        window.addEventListener("pointerup", handlePrivateResizePointerUp);
    };
    const handlePrivateResizePointerMove = (e)=>{
        if (!resizingPrivateDataRef.current) return;
        const { idx, canvasRect, original, direction, startClientX, startClientY } = resizingPrivateDataRef.current;
        const deltaX = e.clientX - startClientX;
        const deltaY = e.clientY - startClientY;
        const ndx = deltaX / canvasRect.width;
        const ndy = deltaY / canvasRect.height;
        const newAnno = computeNewAnnotation(original, ndx, ndy, direction);
        onUpdatePrivateInfo(pageNumber, idx, newAnno);
    };
    const handlePrivateResizePointerUp = (e)=>{
        setResizingPrivateIndex(null);
        resizingPrivateDataRef.current = null;
        window.removeEventListener("pointermove", handlePrivateResizePointerMove);
        window.removeEventListener("pointerup", handlePrivateResizePointerUp);
    };
    // --- Global Pointer Listeners for Image Dragging ---
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "PDFPage.useEffect": ()=>{
            if (draggingImageIndex !== null) {
                const handlePointerMove = {
                    "PDFPage.useEffect.handlePointerMove": (e)=>{
                        const rect = getReferenceRect();
                        let newX = (e.clientX - rect.left - dragImageOffset.x) / rect.width;
                        let newY = (e.clientY - rect.top - dragImageOffset.y) / rect.height;
                        const imgAnno = images[draggingImageIndex];
                        newX = clamp(newX, 0, 1 - imgAnno.width);
                        newY = clamp(newY, 0, 1 - imgAnno.height);
                        onUpdateImage(pageNumber, draggingImageIndex, {
                            ...imgAnno,
                            x: newX,
                            y: newY
                        });
                    }
                }["PDFPage.useEffect.handlePointerMove"];
                const handlePointerUp = {
                    "PDFPage.useEffect.handlePointerUp": ()=>{
                        setDraggingImageIndex(null);
                        setDragImageOffset({
                            x: 0,
                            y: 0
                        });
                    }
                }["PDFPage.useEffect.handlePointerUp"];
                window.addEventListener("pointermove", handlePointerMove);
                window.addEventListener("pointerup", handlePointerUp);
                return ({
                    "PDFPage.useEffect": ()=>{
                        window.removeEventListener("pointermove", handlePointerMove);
                        window.removeEventListener("pointerup", handlePointerUp);
                    }
                })["PDFPage.useEffect"];
            }
        }
    }["PDFPage.useEffect"], [
        draggingImageIndex,
        dragImageOffset,
        images,
        pageNumber,
        onUpdateImage
    ]);
    // --- Touch Handlers for New Annotations ---
    const handleTouchStart = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "PDFPage.useCallback[handleTouchStart]": (e)=>{
            // If the touch started on an interactive element, do nothing.
            if (e.target.closest("button, select, textarea")) {
                return;
            }
            if (e.touches.length !== 1) return;
            const touch = e.touches[0];
            const containerRect = containerRef.current.getBoundingClientRect();
            const x = clamp(touch.clientX - containerRect.left, 0, containerRect.width);
            const y = clamp(touch.clientY - containerRect.top, 0, containerRect.height);
            // Avoid starting a new annotation if tapping inside an existing one.
            if (highlightMode && highlights.length > 0) {
                for(let i = 0; i < highlights.length; i++){
                    const hl = highlights[i];
                    const hlX = hl.x * canvasDimensions.width;
                    const hlY = hl.y * canvasDimensions.height;
                    const hlW = hl.width * canvasDimensions.width;
                    const hlH = hl.height * canvasDimensions.height;
                    if (x >= hlX && x <= hlX + hlW && y >= hlY && y <= hlH + hlY) return;
                }
            }
            if (privateInfoMode && privateInfos.length > 0) {
                for(let i = 0; i < privateInfos.length; i++){
                    const pi = privateInfos[i];
                    const boxX = pi.x * canvasDimensions.width;
                    const boxY = pi.y * canvasDimensions.height;
                    const boxW = pi.width * canvasDimensions.width;
                    const boxH = pi.height * canvasDimensions.height;
                    if (x >= boxX && x <= boxX + boxW && y >= boxY && y <= boxY + boxH) return;
                }
            }
            if (imageMode && images.length > 0) {
                for(let i = 0; i < images.length; i++){
                    const imgAnno = images[i];
                    const imgX = imgAnno.x * canvasDimensions.width;
                    const imgY = imgAnno.y * canvasDimensions.height;
                    const imgW = imgAnno.width * canvasDimensions.width;
                    const imgH = imgAnno.height * canvasDimensions.height;
                    if (x >= imgX && x <= imgX + imgW && y >= imgY && y <= imgY + imgH) return;
                }
            }
            if (textMode) {
                // Check if the touch is inside an existing text annotation.
                for(let i = 0; i < texts.length; i++){
                    const textAnno = texts[i];
                    const textX = textAnno.x * canvasDimensions.width;
                    const textY = textAnno.y * canvasDimensions.height;
                    const textW = textAnno.width * canvasDimensions.width;
                    const textH = textAnno.height * canvasDimensions.height;
                    if (x >= textX && x <= textX + textW && y >= textY && y <= textY + textH) return;
                }
                // Remove previous empty text annotation if exists.
                const emptyTextIndex = texts.findIndex({
                    "PDFPage.useCallback[handleTouchStart].emptyTextIndex": (t)=>t.text.trim() === ""
                }["PDFPage.useCallback[handleTouchStart].emptyTextIndex"]);
                if (emptyTextIndex !== -1) {
                    onRemoveText(pageNumber, emptyTextIndex);
                }
                // Immediately add a text annotation on tap with default dimensions.
                const defaultWidth = 100;
                const defaultHeight = 30;
                const normalizedText = {
                    x: x / containerRect.width,
                    y: y / containerRect.height,
                    width: defaultWidth / containerRect.width,
                    height: defaultHeight / containerRect.height,
                    text: "",
                    fontSize: DEFAULT_FONT_SIZE
                };
                onAddText(pageNumber, normalizedText);
                const newIndex = texts.length;
                setActiveTextIndex(newIndex);
                setEditingTextIndex(newIndex);
                return; // Skip setting up the long-press timer.
            }
            initialTouchRef.current = {
                x,
                y
            };
            longPressTimerRef.current = setTimeout({
                "PDFPage.useCallback[handleTouchStart]": ()=>{
                    if (highlightMode) {
                        setDrawingRect({
                            startX: x,
                            startY: y,
                            x,
                            y,
                            width: 0,
                            height: 0
                        });
                    } else if (privateInfoMode) {
                        setDrawingPrivate({
                            startX: x,
                            startY: y,
                            x,
                            y,
                            width: 0,
                            height: 0
                        });
                    }
                    longPressTimerRef.current = null;
                }
            }["PDFPage.useCallback[handleTouchStart]"], LONG_PRESS_DURATION);
        }
    }["PDFPage.useCallback[handleTouchStart]"], [
        highlightMode,
        privateInfoMode,
        textMode,
        highlights,
        privateInfos,
        images,
        texts,
        canvasDimensions
    ]);
    const handleTouchMove = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "PDFPage.useCallback[handleTouchMove]": (e)=>{
            if (e.touches.length !== 1) return;
            const touch = e.touches[0];
            const containerRect = containerRef.current.getBoundingClientRect();
            const currentX = clamp(touch.clientX - containerRect.left, 0, containerRect.width);
            const currentY = clamp(touch.clientY - containerRect.top, 0, containerRect.height);
            if (longPressTimerRef.current) {
                const { x, y } = initialTouchRef.current;
                const distance = Math.hypot(currentX - x, currentY - y);
                if (distance > MOVE_THRESHOLD) {
                    clearTimeout(longPressTimerRef.current);
                    longPressTimerRef.current = null;
                }
            }
            if (highlightMode && drawingRect) {
                const x = Math.min(drawingRect.startX, currentX);
                const y = Math.min(drawingRect.startY, currentY);
                const width = Math.abs(currentX - drawingRect.startX);
                const height = Math.abs(currentY - drawingRect.startY);
                setDrawingRect({
                    ...drawingRect,
                    x,
                    y,
                    width,
                    height
                });
                e.preventDefault();
            } else if (privateInfoMode && drawingPrivate) {
                const x = Math.min(drawingPrivate.startX, currentX);
                const y = Math.min(drawingPrivate.startY, currentY);
                const width = Math.abs(currentX - drawingPrivate.startX);
                const height = Math.abs(currentY - drawingPrivate.startY);
                setDrawingPrivate({
                    ...drawingPrivate,
                    x,
                    y,
                    width,
                    height
                });
                e.preventDefault();
            } else if (imageMode && drawingImage) {
                const x = Math.min(drawingImage.startX, currentX);
                const y = Math.min(drawingImage.startY, currentY);
                const width = Math.abs(currentX - drawingImage.startX);
                const height = Math.abs(currentY - drawingImage.startY);
                setDrawingImage({
                    ...drawingImage,
                    x,
                    y,
                    width,
                    height
                });
                e.preventDefault();
            }
        }
    }["PDFPage.useCallback[handleTouchMove]"], [
        highlightMode,
        drawingRect,
        privateInfoMode,
        drawingPrivate,
        imageMode,
        drawingImage
    ]);
    const handleTouchEnd = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "PDFPage.useCallback[handleTouchEnd]": (e)=>{
            if (longPressTimerRef.current) {
                clearTimeout(longPressTimerRef.current);
                longPressTimerRef.current = null;
            }
            if (highlightMode && drawingRect) {
                if (drawingRect.width > 5 && drawingRect.height > 5) {
                    const rect = getReferenceRect();
                    const normalizedHighlight = {
                        x: drawingRect.x / rect.width,
                        y: drawingRect.y / rect.height,
                        width: drawingRect.width / rect.width,
                        height: drawingRect.height / rect.height,
                        color: highlightColor
                    };
                    onAddHighlight(pageNumber, normalizedHighlight);
                }
                setDrawingRect(null);
                e.preventDefault();
            } else if (privateInfoMode && drawingPrivate) {
                if (drawingPrivate.width > 5 && drawingPrivate.height > 5) {
                    const rect = getReferenceRect();
                    const normalizedPrivate = {
                        x: drawingPrivate.x / rect.width,
                        y: drawingPrivate.y / rect.height,
                        width: drawingPrivate.width / rect.width,
                        height: drawingPrivate.height / rect.height
                    };
                    onAddPrivateInfo(pageNumber, normalizedPrivate);
                }
                setDrawingPrivate(null);
                e.preventDefault();
            } else if (imageMode && drawingImage) {
                if (drawingImage.width > 5 && drawingImage.height > 5) {
                    const rect = getReferenceRect();
                    const normalizedImage = {
                        x: drawingImage.x / rect.width,
                        y: drawingImage.y / rect.height,
                        width: drawingImage.width / rect.width,
                        height: drawingImage.height / rect.height,
                        src: imageSrc
                    };
                    onAddImage(pageNumber, normalizedImage);
                }
                setDrawingImage(null);
                e.preventDefault();
            }
        }
    }["PDFPage.useCallback[handleTouchEnd]"], [
        highlightMode,
        drawingRect,
        privateInfoMode,
        drawingPrivate,
        imageMode,
        drawingImage,
        highlightColor,
        onAddHighlight,
        onAddPrivateInfo,
        onAddImage,
        pageNumber,
        imageSrc
    ]);
    // --- Touch Handlers for Existing Annotations ---
    const handlePrivateTouchStart = (e, idx)=>{
        e.stopPropagation();
        if (e.touches.length !== 1) return;
        const touch = e.touches[0];
        const rect = getReferenceRect();
        initialTouchRef.current = {
            x: touch.clientX,
            y: touch.clientY,
            idx
        };
        privateLongPressTimerRef.current = setTimeout(()=>{
            const box = privateInfos[idx];
            const absX = box.x * rect.width;
            const absY = box.y * rect.height;
            const offsetX = touch.clientX - rect.left - absX;
            const offsetY = touch.clientY - rect.top - absY;
            setDraggingPrivateIndex(idx);
            setDragOffset({
                x: offsetX,
                y: offsetY
            });
            setActivePrivateIndex(idx);
            privateLongPressTimerRef.current = null;
        }, LONG_PRESS_DURATION);
    };
    const handlePrivateTouchMove = (e, idx)=>{
        if (e.touches.length !== 1) return;
        const touch = e.touches[0];
        const rect = getReferenceRect();
        const { x, y } = initialTouchRef.current;
        const distance = Math.hypot(touch.clientX - x, touch.clientY - y);
        if (privateLongPressTimerRef.current && distance > MOVE_THRESHOLD) {
            clearTimeout(privateLongPressTimerRef.current);
            privateLongPressTimerRef.current = null;
        }
        if (draggingPrivateIndex === idx) {
            let newX = (touch.clientX - rect.left - dragOffset.x) / rect.width;
            let newY = (touch.clientY - rect.top - dragOffset.y) / rect.height;
            const box = privateInfos[idx];
            newX = clamp(newX, 0, 1 - box.width);
            newY = clamp(newY, 0, 1 - box.height);
            onUpdatePrivateInfo(pageNumber, idx, {
                ...box,
                x: newX,
                y: newY
            });
            e.preventDefault();
        }
    };
    const handlePrivateTouchEnd = (e, idx)=>{
        if (privateLongPressTimerRef.current) {
            clearTimeout(privateLongPressTimerRef.current);
            privateLongPressTimerRef.current = null;
        }
        if (draggingPrivateIndex === idx) {
            setDraggingPrivateIndex(null);
            setDragOffset({
                x: 0,
                y: 0
            });
            e.preventDefault();
        }
    };
    const handleHighlightTouchStart = (e, idx)=>{
        e.stopPropagation();
        if (e.touches.length !== 1) return;
        const touch = e.touches[0];
        const rect = getReferenceRect();
        initialTouchRef.current = {
            x: touch.clientX,
            y: touch.clientY,
            idx
        };
        highlightLongPressTimerRef.current = setTimeout(()=>{
            const hl = highlights[idx];
            const absX = hl.x * rect.width;
            const absY = hl.y * rect.height;
            const offsetX = touch.clientX - rect.left - absX;
            const offsetY = touch.clientY - rect.top - absY;
            setDraggingHighlightIndex(idx);
            setDragHighlightOffset({
                x: offsetX,
                y: offsetY
            });
            setActiveHighlightIndex(idx);
            highlightLongPressTimerRef.current = null;
        }, LONG_PRESS_DURATION);
    };
    const handleHighlightTouchMove = (e, idx)=>{
        if (e.touches.length !== 1) return;
        const touch = e.touches[0];
        const rect = getReferenceRect();
        const { x, y } = initialTouchRef.current;
        const distance = Math.hypot(touch.clientX - x, touch.clientY - y);
        if (highlightLongPressTimerRef.current && distance > MOVE_THRESHOLD) {
            clearTimeout(highlightLongPressTimerRef.current);
            highlightLongPressTimerRef.current = null;
        }
        if (draggingHighlightIndex === idx) {
            let newX = (touch.clientX - rect.left - dragHighlightOffset.x) / rect.width;
            let newY = (touch.clientY - rect.top - dragHighlightOffset.y) / rect.height;
            const hl = highlights[idx];
            newX = clamp(newX, 0, 1 - hl.width);
            newY = clamp(newY, 0, 1 - hl.height);
            onUpdateHighlight(pageNumber, idx, {
                ...hl,
                x: newX,
                y: newY
            });
            e.preventDefault();
        }
    };
    const handleHighlightTouchEnd = (e, idx)=>{
        if (highlightLongPressTimerRef.current) {
            clearTimeout(highlightLongPressTimerRef.current);
            highlightLongPressTimerRef.current = null;
        }
        if (draggingHighlightIndex === idx) {
            setDraggingHighlightIndex(null);
            setDragHighlightOffset({
                x: 0,
                y: 0
            });
            e.preventDefault();
        }
    };
    const handleImageTouchStart = (e, idx)=>{
        e.stopPropagation();
        if (e.touches.length !== 1) return;
        const touch = e.touches[0];
        const rect = getReferenceRect();
        initialTouchRef.current = {
            x: touch.clientX,
            y: touch.clientY,
            idx
        };
        imageLongPressTimerRef.current = setTimeout(()=>{
            const imgAnno = images[idx];
            const absX = imgAnno.x * rect.width;
            const absY = imgAnno.y * rect.height;
            const offsetX = touch.clientX - rect.left - absX;
            const offsetY = touch.clientY - rect.top - absY;
            setDraggingImageIndex(idx);
            setDragImageOffset({
                x: offsetX,
                y: offsetY
            });
            setActiveImageIndex(idx);
            imageLongPressTimerRef.current = null;
        }, LONG_PRESS_DURATION);
    };
    const handleImageTouchMove = (e, idx)=>{
        if (e.touches.length !== 1) return;
        const touch = e.touches[0];
        const rect = getReferenceRect();
        const { x, y } = initialTouchRef.current;
        const distance = Math.hypot(touch.clientX - x, touch.clientY - y);
        if (imageLongPressTimerRef.current && distance > MOVE_THRESHOLD) {
            clearTimeout(imageLongPressTimerRef.current);
            imageLongPressTimerRef.current = null;
        }
        if (draggingImageIndex === idx) {
            let newX = (touch.clientX - rect.left - dragImageOffset.x) / rect.width;
            let newY = (touch.clientY - rect.top - dragImageOffset.y) / rect.height;
            const imgAnno = images[idx];
            newX = clamp(newX, 0, 1 - imgAnno.width);
            newY = clamp(newY, 0, 1 - imgAnno.height);
            onUpdateImage(pageNumber, idx, {
                ...imgAnno,
                x: newX,
                y: newY
            });
            e.preventDefault();
        }
    };
    const handleImageTouchEnd = (e, idx)=>{
        if (imageLongPressTimerRef.current) {
            clearTimeout(imageLongPressTimerRef.current);
            imageLongPressTimerRef.current = null;
        }
        if (draggingImageIndex === idx) {
            setDraggingImageIndex(null);
            setDragImageOffset({
                x: 0,
                y: 0
            });
            e.preventDefault();
        }
    };
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "PDFPage.useEffect": ()=>{
            const container = containerRef.current;
            if (!container) return;
            container.addEventListener("touchstart", handleTouchStart, {
                passive: false
            });
            container.addEventListener("touchmove", handleTouchMove, {
                passive: false
            });
            container.addEventListener("touchend", handleTouchEnd, {
                passive: false
            });
            container.addEventListener("touchcancel", handleTouchEnd, {
                passive: false
            });
            return ({
                "PDFPage.useEffect": ()=>{
                    container.removeEventListener("touchstart", handleTouchStart);
                    container.removeEventListener("touchmove", handleTouchMove);
                    container.removeEventListener("touchend", handleTouchEnd);
                    container.removeEventListener("touchcancel", handleTouchEnd);
                }
            })["PDFPage.useEffect"];
        }
    }["PDFPage.useEffect"], [
        handleTouchStart,
        handleTouchMove,
        handleTouchEnd
    ]);
    // --- RENDER RESIZE HANDLES ---
    const renderResizeHandles = (type, idx)=>{
        const handlePositions = [
            {
                direction: "nw",
                style: {
                    left: -5,
                    top: -5
                }
            },
            {
                direction: "n",
                style: {
                    left: "50%",
                    top: -5,
                    transform: "translateX(-50%)"
                }
            },
            {
                direction: "ne",
                style: {
                    right: -5,
                    top: -5
                }
            },
            {
                direction: "e",
                style: {
                    right: -5,
                    top: "50%",
                    transform: "translateY(-50%)"
                }
            },
            {
                direction: "se",
                style: {
                    right: -5,
                    bottom: -5
                }
            },
            {
                direction: "s",
                style: {
                    left: "50%",
                    bottom: -5,
                    transform: "translateX(-50%)"
                }
            },
            {
                direction: "sw",
                style: {
                    left: -5,
                    bottom: -5
                }
            },
            {
                direction: "w",
                style: {
                    left: -5,
                    top: "50%",
                    transform: "translateY(-50%)"
                }
            }
        ];
        return handlePositions.map((handle)=>{
            const onPointerDown = (e)=>{
                e.stopPropagation();
                e.preventDefault();
                e.target.setPointerCapture(e.pointerId);
                if (type === "image") {
                    handleImageResizePointerDown(e, idx, handle.direction);
                } else if (type === "highlight") {
                    handleHighlightResizePointerDown(e, idx, handle.direction);
                } else if (type === "private") {
                    handlePrivateResizePointerDown(e, idx, handle.direction);
                }
            };
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                style: {
                    position: "absolute",
                    width: 10,
                    height: 10,
                    backgroundColor: "white",
                    border: "1px solid black",
                    cursor: "nwse-resize",
                    zIndex: 20,
                    touchAction: "none",
                    ...handle.style
                },
                onPointerDown: onPointerDown
            }, handle.direction, false, {
                fileName: "[project]/src/app/_components/PDFPage.jsx",
                lineNumber: 1244,
                columnNumber: 9
            }, this);
        });
    };
    // --- RENDERING ---
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        ref: containerRef,
        id: `page-${pageNumber}`,
        style: {
            marginBottom: "120px",
            position: "relative",
            margin: "0 auto",
            width: "fit-content"
        },
        onMouseDown: (e)=>{
            if (e.target === containerRef.current) {
                setActiveHighlightIndex(null);
                setActivePrivateIndex(null);
                setActiveImageIndex(null);
                // If a text annotation is currently being edited, exit edit mode without adding a new one.
                if (editingTextIndex !== null) {
                    setActiveTextIndex(null);
                    setEditingTextIndex(null);
                    return; // Do not call handleMouseDown further.
                }
                // Otherwise, clear any active text index.
                setActiveTextIndex(null);
            }
            handleMouseDown(e);
        },
        onMouseMove: handleMouseMove,
        onMouseUp: handleMouseUp,
        onMouseLeave: handleMouseUp,
        children: isVisible ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("canvas", {
                    ref: canvasRef,
                    style: {
                        display: "block",
                        opacity: loaded ? 1 : 0,
                        transition: "opacity 0.5s ease-in-out",
                        marginBottom: "20px",
                        pointerEvents: "none"
                    }
                }, void 0, false, {
                    fileName: "[project]/src/app/_components/PDFPage.jsx",
                    lineNumber: 1296,
                    columnNumber: 11
                }, this),
                highlights.map((hl, idx)=>{
                    const hlColor = hl.color || highlightColor;
                    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        style: {
                            cursor: "pointer",
                            position: "absolute",
                            left: hl.x * canvasDimensions.width,
                            top: hl.y * canvasDimensions.height,
                            width: hl.width * canvasDimensions.width,
                            height: hl.height * canvasDimensions.height,
                            touchAction: "none"
                        },
                        onMouseDown: (e)=>handleHighlightMouseDown(e, idx),
                        onTouchStart: (e)=>handleHighlightTouchStart(e, idx),
                        onTouchMove: (e)=>handleHighlightTouchMove(e, idx),
                        onTouchEnd: (e)=>handleHighlightTouchEnd(e, idx),
                        onClick: (e)=>{
                            e.stopPropagation();
                            setActiveHighlightIndex(idx);
                        },
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                style: {
                                    width: "100%",
                                    height: "100%",
                                    backgroundColor: hexToRgba(hlColor, 0.3),
                                    pointerEvents: "none",
                                    boxSizing: "border-box"
                                }
                            }, void 0, false, {
                                fileName: "[project]/src/app/_components/PDFPage.jsx",
                                lineNumber: 1330,
                                columnNumber: 17
                            }, this),
                            activeHighlightIndex === idx && renderResizeHandles("highlight", idx),
                            activeHighlightIndex === idx && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                style: {
                                    position: "absolute",
                                    bottom: "100%",
                                    left: 0,
                                    zIndex: 10,
                                    display: "flex",
                                    flexDirection: "column",
                                    alignItems: "flex-start"
                                },
                                onMouseDown: (e)=>e.stopPropagation(),
                                onClick: (e)=>e.stopPropagation(),
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        style: {
                                            fontSize: "10px",
                                            cursor: "pointer",
                                            backgroundColor: "black",
                                            color: "white",
                                            marginBottom: "2px",
                                            pointerEvents: "auto",
                                            touchAction: "auto"
                                        },
                                        // Using pointer events so that the remove action fires on mobile
                                        onPointerUp: (e)=>{
                                            e.stopPropagation();
                                            e.preventDefault();
                                            onRemoveHighlight(pageNumber, idx);
                                            setActiveHighlightIndex(null);
                                        },
                                        children: "Remove"
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/_components/PDFPage.jsx",
                                        lineNumber: 1355,
                                        columnNumber: 21
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                        value: hlColor,
                                        onChange: (e)=>onUpdateHighlight(pageNumber, idx, {
                                                color: e.target.value
                                            }),
                                        style: {
                                            fontSize: "10px",
                                            cursor: "pointer",
                                            color: "black",
                                            pointerEvents: "auto",
                                            touchAction: "auto"
                                        },
                                        onPointerDown: (e)=>e.stopPropagation(),
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                value: "#FFFF00",
                                                children: "Yellow"
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/_components/PDFPage.jsx",
                                                lineNumber: 1391,
                                                columnNumber: 23
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                value: "#00FF00",
                                                children: "Green"
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/_components/PDFPage.jsx",
                                                lineNumber: 1392,
                                                columnNumber: 23
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                value: "#0000FF",
                                                children: "Blue"
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/_components/PDFPage.jsx",
                                                lineNumber: 1393,
                                                columnNumber: 23
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                value: "#FFC0CB",
                                                children: "Pink"
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/_components/PDFPage.jsx",
                                                lineNumber: 1394,
                                                columnNumber: 23
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                value: "#FFA500",
                                                children: "Orange"
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/_components/PDFPage.jsx",
                                                lineNumber: 1395,
                                                columnNumber: 23
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/_components/PDFPage.jsx",
                                        lineNumber: 1375,
                                        columnNumber: 21
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/_components/PDFPage.jsx",
                                lineNumber: 1342,
                                columnNumber: 19
                            }, this)
                        ]
                    }, `hl-${idx}`, true, {
                        fileName: "[project]/src/app/_components/PDFPage.jsx",
                        lineNumber: 1310,
                        columnNumber: 15
                    }, this);
                }),
                privateInfos.map((pi, idx)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        style: {
                            cursor: "move",
                            position: "absolute",
                            left: pi.x * canvasDimensions.width,
                            top: pi.y * canvasDimensions.height,
                            width: pi.width * canvasDimensions.width,
                            height: pi.height * canvasDimensions.height,
                            touchAction: "none"
                        },
                        onMouseDown: (e)=>handlePrivateMouseDown(e, idx),
                        onTouchStart: (e)=>handlePrivateTouchStart(e, idx),
                        onTouchMove: (e)=>handlePrivateTouchMove(e, idx),
                        onTouchEnd: (e)=>handlePrivateTouchEnd(e, idx),
                        onClick: (e)=>{
                            e.stopPropagation();
                            setActivePrivateIndex(idx);
                        },
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                style: {
                                    width: "100%",
                                    height: "100%",
                                    backgroundColor: "black",
                                    pointerEvents: "none",
                                    boxSizing: "border-box"
                                }
                            }, void 0, false, {
                                fileName: "[project]/src/app/_components/PDFPage.jsx",
                                lineNumber: 1424,
                                columnNumber: 15
                            }, this),
                            activePrivateIndex === idx && renderResizeHandles("private", idx),
                            activePrivateIndex === idx && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                style: {
                                    position: "absolute",
                                    bottom: "100%",
                                    left: 0,
                                    zIndex: 10,
                                    display: "flex",
                                    flexDirection: "column",
                                    alignItems: "flex-start"
                                },
                                onClick: (e)=>e.stopPropagation(),
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    style: {
                                        fontSize: "10px",
                                        cursor: "pointer",
                                        backgroundColor: "black",
                                        color: "white",
                                        marginBottom: "2px"
                                    },
                                    onClick: (e)=>{
                                        e.stopPropagation();
                                        onRemovePrivateInfo(pageNumber, idx);
                                        setActivePrivateIndex(null);
                                    },
                                    children: "Remove"
                                }, void 0, false, {
                                    fileName: "[project]/src/app/_components/PDFPage.jsx",
                                    lineNumber: 1448,
                                    columnNumber: 19
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/app/_components/PDFPage.jsx",
                                lineNumber: 1436,
                                columnNumber: 17
                            }, this)
                        ]
                    }, `pi-${idx}`, true, {
                        fileName: "[project]/src/app/_components/PDFPage.jsx",
                        lineNumber: 1404,
                        columnNumber: 13
                    }, this)),
                images.map((img, idx)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        style: {
                            cursor: "move",
                            position: "absolute",
                            left: img.x * canvasDimensions.width,
                            top: img.y * canvasDimensions.height,
                            width: img.width * canvasDimensions.width,
                            height: img.height * canvasDimensions.height,
                            touchAction: "none"
                        },
                        onMouseDown: (e)=>handleImageMouseDown(e, idx),
                        onTouchStart: (e)=>handleImageTouchStart(e, idx),
                        onTouchMove: (e)=>handleImageTouchMove(e, idx),
                        onTouchEnd: (e)=>handleImageTouchEnd(e, idx),
                        onClick: (e)=>{
                            e.stopPropagation();
                            setActiveImageIndex(idx);
                        },
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                src: img.src,
                                alt: "",
                                style: {
                                    width: "100%",
                                    height: "100%",
                                    pointerEvents: "none",
                                    objectFit: "cover"
                                }
                            }, void 0, false, {
                                fileName: "[project]/src/app/_components/PDFPage.jsx",
                                lineNumber: 1490,
                                columnNumber: 15
                            }, this),
                            activeImageIndex === idx && renderResizeHandles("image", idx),
                            activeImageIndex === idx && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                style: {
                                    position: "absolute",
                                    bottom: "100%",
                                    left: 0,
                                    zIndex: 10,
                                    display: "flex",
                                    flexDirection: "column",
                                    alignItems: "flex-start"
                                },
                                onClick: (e)=>e.stopPropagation(),
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    style: {
                                        fontSize: "10px",
                                        cursor: "pointer",
                                        backgroundColor: "black",
                                        color: "white",
                                        marginBottom: "2px"
                                    },
                                    onClick: (e)=>{
                                        e.stopPropagation();
                                        onRemoveImage(pageNumber, idx);
                                        setActiveImageIndex(null);
                                    },
                                    children: "Remove"
                                }, void 0, false, {
                                    fileName: "[project]/src/app/_components/PDFPage.jsx",
                                    lineNumber: 1514,
                                    columnNumber: 19
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/app/_components/PDFPage.jsx",
                                lineNumber: 1502,
                                columnNumber: 17
                            }, this)
                        ]
                    }, `img-${idx}`, true, {
                        fileName: "[project]/src/app/_components/PDFPage.jsx",
                        lineNumber: 1470,
                        columnNumber: 13
                    }, this)),
                texts.map((textAnno, idx)=>{
                    // Compute available width for the annotation so it stays within the container.
                    const containerRect = containerRef.current ? containerRef.current.getBoundingClientRect() : {
                        width: canvasDimensions.width
                    };
                    const leftPos = textAnno.x * canvasDimensions.width;
                    const maxTextWidth = containerRect.width - leftPos;
                    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        style: {
                            position: "absolute",
                            left: textAnno.x * canvasDimensions.width,
                            top: textAnno.y * canvasDimensions.height,
                            maxWidth: `${maxTextWidth}px`,
                            wordBreak: "break-word",
                            overflowWrap: "break-word",
                            cursor: textMode ? editingTextIndex === idx ? "text" : "move" : "default",
                            touchAction: "none",
                            border: textMode && activeTextIndex === idx ? "1px dashed blue" : "1px solid transparent",
                            padding: "2px",
                            backgroundColor: "transparent",
                            boxSizing: "border-box",
                            userSelect: "none",
                            textAlign: "left",
                            overflow: "visible"
                        },
                        onMouseDown: textMode && editingTextIndex !== idx ? (e)=>handleTextMouseDown(e, idx) : undefined,
                        onDoubleClick: textMode ? (e)=>{
                            e.stopPropagation();
                            setEditingTextIndex(idx);
                        } : undefined,
                        onClick: textMode ? (e)=>{
                            e.stopPropagation();
                            setActiveTextIndex(idx);
                        } : undefined,
                        children: [
                            editingTextIndex === idx ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                style: {
                                    position: "relative"
                                },
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("textarea", {
                                    ref: (el)=>{
                                        if (el) {
                                            el.style.height = "auto";
                                            el.style.width = "auto";
                                            el.style.height = el.scrollHeight + "px";
                                            el.style.width = Math.min(el.scrollWidth, maxTextWidth) + "px";
                                        }
                                    },
                                    style: {
                                        overflow: "hidden",
                                        resize: "none",
                                        textAlign: "left",
                                        border: "none",
                                        background: "transparent",
                                        outline: "none",
                                        color: "black",
                                        whiteSpace: "pre",
                                        width: "fit-content",
                                        maxWidth: "100%",
                                        fontSize: `${(textAnno.fontSize || DEFAULT_FONT_SIZE) * scale}px`
                                    },
                                    value: textAnno.text,
                                    onInput: (e)=>{
                                        e.target.style.height = "auto";
                                        e.target.style.width = "auto";
                                        e.target.style.height = e.target.scrollHeight + "px";
                                        e.target.style.width = `${Math.min(e.target.scrollWidth, maxTextWidth)}px`;
                                        handleTextChange(e, idx);
                                    },
                                    onBlur: ()=>finishTextEditing(idx),
                                    autoFocus: true
                                }, void 0, false, {
                                    fileName: "[project]/src/app/_components/PDFPage.jsx",
                                    lineNumber: 1593,
                                    columnNumber: 21
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/app/_components/PDFPage.jsx",
                                lineNumber: 1592,
                                columnNumber: 19
                            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                style: {
                                    color: "black",
                                    whiteSpace: "pre-wrap",
                                    textWrap: "no-wrap",
                                    fontSize: `${(textAnno.fontSize || DEFAULT_FONT_SIZE) * scale}px`
                                },
                                children: textAnno.text || "New Text"
                            }, void 0, false, {
                                fileName: "[project]/src/app/_components/PDFPage.jsx",
                                lineNumber: 1634,
                                columnNumber: 19
                            }, this),
                            textMode && activeTextIndex === idx && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                style: {
                                    position: "absolute",
                                    bottom: "100%",
                                    left: 0,
                                    zIndex: 10,
                                    display: "flex",
                                    flexDirection: "column",
                                    alignItems: "flex-start",
                                    pointerEvents: "auto",
                                    touchAction: "auto"
                                },
                                onMouseDown: (e)=>e.stopPropagation(),
                                onTouchStart: (e)=>e.stopPropagation(),
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        style: {
                                            fontSize: "10px",
                                            cursor: "pointer",
                                            backgroundColor: "black",
                                            color: "white",
                                            marginBottom: "2px",
                                            pointerEvents: "auto",
                                            touchAction: "auto",
                                            padding: "4px 6px"
                                        },
                                        onPointerUp: (e)=>{
                                            e.stopPropagation();
                                            e.preventDefault();
                                            onRemoveText(pageNumber, idx);
                                            setActiveTextIndex(null);
                                        },
                                        children: "Remove"
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/_components/PDFPage.jsx",
                                        lineNumber: 1663,
                                        columnNumber: 21
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                        value: textAnno.fontSize || DEFAULT_FONT_SIZE,
                                        onChange: (e)=>{
                                            const newFontSize = parseInt(e.target.value, 10);
                                            onUpdateText(pageNumber, idx, {
                                                ...textAnno,
                                                fontSize: newFontSize
                                            });
                                        },
                                        style: {
                                            fontSize: "10px",
                                            cursor: "pointer",
                                            pointerEvents: "auto",
                                            touchAction: "auto",
                                            color: "black"
                                        },
                                        onPointerDown: (e)=>e.stopPropagation(),
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                value: "10",
                                                children: "10px"
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/_components/PDFPage.jsx",
                                                lineNumber: 1701,
                                                columnNumber: 23
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                value: "12",
                                                children: "12px"
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/_components/PDFPage.jsx",
                                                lineNumber: 1702,
                                                columnNumber: 23
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                value: "14",
                                                children: "14px"
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/_components/PDFPage.jsx",
                                                lineNumber: 1703,
                                                columnNumber: 23
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                value: "16",
                                                children: "16px"
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/_components/PDFPage.jsx",
                                                lineNumber: 1704,
                                                columnNumber: 23
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                value: "18",
                                                children: "18px"
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/_components/PDFPage.jsx",
                                                lineNumber: 1705,
                                                columnNumber: 23
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                value: "20",
                                                children: "20px"
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/_components/PDFPage.jsx",
                                                lineNumber: 1706,
                                                columnNumber: 23
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                value: "24",
                                                children: "24px"
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/_components/PDFPage.jsx",
                                                lineNumber: 1707,
                                                columnNumber: 23
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                value: "28",
                                                children: "28px"
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/_components/PDFPage.jsx",
                                                lineNumber: 1708,
                                                columnNumber: 23
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                value: "32",
                                                children: "32px"
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/_components/PDFPage.jsx",
                                                lineNumber: 1709,
                                                columnNumber: 23
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/_components/PDFPage.jsx",
                                        lineNumber: 1683,
                                        columnNumber: 21
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/_components/PDFPage.jsx",
                                lineNumber: 1648,
                                columnNumber: 19
                            }, this)
                        ]
                    }, `text-${idx}`, true, {
                        fileName: "[project]/src/app/_components/PDFPage.jsx",
                        lineNumber: 1543,
                        columnNumber: 15
                    }, this);
                }),
                drawingRect && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    style: {
                        position: "absolute",
                        left: drawingRect.x,
                        top: drawingRect.y,
                        width: drawingRect.width,
                        height: drawingRect.height,
                        backgroundColor: hexToRgba(highlightColor, 0.3),
                        border: `1px solid ${highlightColor}`,
                        pointerEvents: "none",
                        boxSizing: "border-box"
                    }
                }, void 0, false, {
                    fileName: "[project]/src/app/_components/PDFPage.jsx",
                    lineNumber: 1718,
                    columnNumber: 13
                }, this),
                drawingPrivate && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    style: {
                        position: "absolute",
                        left: drawingPrivate.x,
                        top: drawingPrivate.y,
                        width: drawingPrivate.width,
                        height: drawingPrivate.height,
                        backgroundColor: "black",
                        border: "1px solid white",
                        pointerEvents: "none",
                        boxSizing: "border-box"
                    }
                }, void 0, false, {
                    fileName: "[project]/src/app/_components/PDFPage.jsx",
                    lineNumber: 1733,
                    columnNumber: 13
                }, this),
                drawingImage && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    style: {
                        position: "absolute",
                        left: drawingImage.x,
                        top: drawingImage.y,
                        width: drawingImage.width,
                        height: drawingImage.height,
                        backgroundColor: "rgba(255,255,255,0.7)",
                        border: "1px solid black",
                        pointerEvents: "none",
                        boxSizing: "border-box",
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                        color: "black",
                        fontSize: "12px",
                        userSelect: "none"
                    },
                    children: "New Image"
                }, void 0, false, {
                    fileName: "[project]/src/app/_components/PDFPage.jsx",
                    lineNumber: 1748,
                    columnNumber: 13
                }, this)
            ]
        }, void 0, true) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            style: {
                height: estimatedHeight ? `${estimatedHeight}px` : `${scale * 800}px`,
                backgroundColor: "#f0f0f0",
                border: "1px solid #ccc"
            }
        }, void 0, false, {
            fileName: "[project]/src/app/_components/PDFPage.jsx",
            lineNumber: 1772,
            columnNumber: 9
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/app/_components/PDFPage.jsx",
        lineNumber: 1265,
        columnNumber: 5
    }, this);
};
_s(PDFPage, "JUbTl9+W1BIOOPkVguT/IlLJFGE=");
_c = PDFPage;
const __TURBOPACK__default__export__ = PDFPage;
var _c;
__turbopack_refresh__.register(_c, "PDFPage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_refresh__.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/app/_components/PDFViewer.jsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, k: __turbopack_refresh__, m: module, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$pdfjs$2d$dist$2f$build$2f$pdf$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/pdfjs-dist/build/pdf.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$_components$2f$PDFPage$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/app/_components/PDFPage.jsx [app-client] (ecmascript)");
;
var _s = __turbopack_refresh__.signature();
"use client";
;
;
;
__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$pdfjs$2d$dist$2f$build$2f$pdf$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__.GlobalWorkerOptions.workerSrc = "/pdf.worker.js";
const DEFAULT_SCALE = 1.5;
const SCALE_STEP = 0.1;
const MIN_SCALE = 0.1;
const PDFViewer = ({ pdfUrl })=>{
    _s();
    const [pdf, setPdf] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [numPages, setNumPages] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    const [pageDimensions, setPageDimensions] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(true);
    const [currentPage, setCurrentPage] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(1);
    const [pageInput, setPageInput] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("1");
    const [pagesToRender, setPagesToRender] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(5);
    const [scale, setScale] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(DEFAULT_SCALE);
    const [highlightMode, setHighlightMode] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [privateInfoMode, setPrivateInfoMode] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [imageMode, setImageMode] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false); // image annotation mode
    const [highlightColor, setHighlightColor] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("#FFFF00");
    const [texts, setTexts] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({}); // Text annotations per page
    const [textMode, setTextMode] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false); // Track text annotation mode
    // Data stored per page.
    const [highlights, setHighlights] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({});
    const [privateInfos, setPrivateInfos] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({});
    const [images, setImages] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({}); // image annotations per page
    const sentinelRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const contentRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const ignoreScrollRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(false);
    const pinchStartDistanceRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const pinchStartScaleRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    // New: state to hold the imported image data URL.
    const [imageSrc, setImageSrc] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    // State to hold a target page that needs scrolling after rendering.
    const [targetPage, setTargetPage] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [drawingText, setDrawingText] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null); // for new text annotations
    const [activeTextIndex, setActiveTextIndex] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null); // Active text index
    const [textInput, setTextInput] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(""); // input for text annotation
    // Load the PDF document.
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "PDFViewer.useEffect": ()=>{
            setLoading(true);
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$pdfjs$2d$dist$2f$build$2f$pdf$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__.getDocument(pdfUrl).promise.then({
                "PDFViewer.useEffect": (pdfDoc)=>{
                    setPdf(pdfDoc);
                    setNumPages(pdfDoc.numPages);
                    setLoading(false);
                }
            }["PDFViewer.useEffect"]).catch({
                "PDFViewer.useEffect": (error)=>{
                    console.error("Error loading PDF:", error);
                    setLoading(false);
                }
            }["PDFViewer.useEffect"]);
        }
    }["PDFViewer.useEffect"], [
        pdfUrl
    ]);
    // Pre-fetch page dimensions.
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "PDFViewer.useEffect": ()=>{
            if (pdf && numPages > 0) {
                let cancelled = false;
                const promises = [];
                for(let i = 1; i <= numPages; i++){
                    promises.push(pdf.getPage(i).then({
                        "PDFViewer.useEffect": (page)=>{
                            const viewport = page.getViewport({
                                scale
                            });
                            return viewport.height;
                        }
                    }["PDFViewer.useEffect"]));
                }
                Promise.all(promises).then({
                    "PDFViewer.useEffect": (heights)=>{
                        if (!cancelled) setPageDimensions(heights);
                    }
                }["PDFViewer.useEffect"]);
                return ({
                    "PDFViewer.useEffect": ()=>{
                        cancelled = true;
                    }
                })["PDFViewer.useEffect"];
            }
        }
    }["PDFViewer.useEffect"], [
        pdf,
        numPages,
        scale
    ]);
    // Automatically add an image annotation when an image is imported.
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "PDFViewer.useEffect": ()=>{
            if (imageSrc) {
                // Add the image to the current page with a default rectangle.
                // (Normalized: x=0.1, y=0.1, width=0.3, height=0.3)
                handleAddImage(currentPage, {
                    x: 0.1,
                    y: 0.1,
                    width: 0.3,
                    height: 0.3,
                    src: imageSrc
                });
                setImageSrc(""); // Reset after adding
            }
        }
    }["PDFViewer.useEffect"], [
        imageSrc,
        currentPage
    ]);
    // --- Navigation Functions ---
    const scrollToPage = (page, instant = false)=>{
        const pageElement = document.getElementById(`page-${page}`);
        if (pageElement && contentRef.current) {
            const containerRect = contentRef.current.getBoundingClientRect();
            const elementRect = pageElement.getBoundingClientRect();
            const offset = elementRect.top - containerRect.top;
            contentRef.current.scrollTo({
                top: contentRef.current.scrollTop + offset,
                behavior: instant ? "auto" : "smooth"
            });
            ignoreScrollRef.current = true;
            setTimeout(()=>{
                ignoreScrollRef.current = false;
            }, 500);
            setCurrentPage(page);
            setPageInput(page.toString());
        }
    };
    const goToPage = (page, instant = false)=>{
        if (page < 1 || page > numPages) return;
        if (page > pagesToRender) {
            setPagesToRender(page);
            setTargetPage({
                page,
                instant
            });
        } else {
            scrollToPage(page, instant);
        }
    };
    const handlePrevious = ()=>{
        if (currentPage > 1) goToPage(currentPage - 1);
    };
    const handleNext = ()=>{
        if (currentPage < numPages) goToPage(currentPage + 1);
    };
    const handleGoToPage = ()=>{
        const page = Number(pageInput);
        if (!isNaN(page)) goToPage(page, true);
    };
    const handleZoomIn = ()=>setScale((prev)=>prev + SCALE_STEP);
    const handleZoomOut = ()=>setScale((prev)=>Math.max(MIN_SCALE, prev - SCALE_STEP));
    // --- Mode Toggles ---
    const toggleHighlightMode = ()=>{
        setHighlightMode((prev)=>!prev);
        // Turn off the other modes
        if (privateInfoMode) setPrivateInfoMode(false);
        if (imageMode) setImageMode(false);
        if (textMode) setTextMode(false);
    };
    const togglePrivateInfoMode = ()=>{
        setPrivateInfoMode((prev)=>!prev);
        // Turn off the other modes
        if (highlightMode) setHighlightMode(false);
        if (imageMode) setImageMode(false);
        if (textMode) setTextMode(false);
    };
    const toggleImageMode = ()=>{
        setImageMode((prev)=>!prev);
        // Turn off the other modes
        if (highlightMode) setHighlightMode(false);
        if (privateInfoMode) setPrivateInfoMode(false);
        if (textMode) setTextMode(false);
    };
    const toggleTextMode = ()=>{
        setTextMode((prev)=>!prev);
        // Turn off the other modes
        if (highlightMode) setHighlightMode(false);
        if (privateInfoMode) setPrivateInfoMode(false);
        if (imageMode) setImageMode(false);
    };
    // --- Handlers for Highlights ---
    const handleAddHighlight = (pageNumber, highlightRect)=>{
        setHighlights((prev)=>{
            const pageHighlights = prev[pageNumber] || [];
            return {
                ...prev,
                [pageNumber]: [
                    ...pageHighlights,
                    highlightRect
                ]
            };
        });
    };
    const handleRemoveHighlight = (pageNumber, indexToRemove)=>{
        setHighlights((prev)=>{
            const pageHighlights = prev[pageNumber] || [];
            return {
                ...prev,
                [pageNumber]: pageHighlights.filter((_, idx)=>idx !== indexToRemove)
            };
        });
    };
    const handleUpdateHighlight = (pageNumber, indexToUpdate, newData)=>{
        setHighlights((prev)=>{
            const pageHighlights = prev[pageNumber] || [];
            const updatedHighlights = pageHighlights.map((hl, idx)=>idx === indexToUpdate ? {
                    ...hl,
                    ...newData
                } : hl);
            return {
                ...prev,
                [pageNumber]: updatedHighlights
            };
        });
    };
    // --- Handlers for Private Info Boxes ---
    const handleAddPrivateInfo = (pageNumber, boxRect)=>{
        setPrivateInfos((prev)=>{
            const pageBoxes = prev[pageNumber] || [];
            return {
                ...prev,
                [pageNumber]: [
                    ...pageBoxes,
                    boxRect
                ]
            };
        });
    };
    const handleRemovePrivateInfo = (pageNumber, indexToRemove)=>{
        setPrivateInfos((prev)=>{
            const pageBoxes = prev[pageNumber] || [];
            return {
                ...prev,
                [pageNumber]: pageBoxes.filter((_, idx)=>idx !== indexToRemove)
            };
        });
    };
    const handleUpdatePrivateInfo = (pageNumber, indexToUpdate, newRect)=>{
        setPrivateInfos((prev)=>{
            const pageBoxes = prev[pageNumber] || [];
            const updatedBoxes = pageBoxes.map((box, idx)=>idx === indexToUpdate ? {
                    ...box,
                    ...newRect
                } : box);
            return {
                ...prev,
                [pageNumber]: updatedBoxes
            };
        });
    };
    // --- Handlers for Image Annotations (NEW) ---
    const handleAddImage = (pageNumber, imageRect)=>{
        setImages((prev)=>{
            const pageImages = prev[pageNumber] || [];
            return {
                ...prev,
                [pageNumber]: [
                    ...pageImages,
                    imageRect
                ]
            };
        });
    };
    const handleRemoveImage = (pageNumber, indexToRemove)=>{
        setImages((prev)=>{
            const pageImages = prev[pageNumber] || [];
            return {
                ...prev,
                [pageNumber]: pageImages.filter((_, idx)=>idx !== indexToRemove)
            };
        });
    };
    const handleUpdateImage = (pageNumber, indexToUpdate, newRect)=>{
        setImages((prev)=>{
            const pageImages = prev[pageNumber] || [];
            const updatedImages = pageImages.map((img, idx)=>idx === indexToUpdate ? {
                    ...img,
                    ...newRect
                } : img);
            return {
                ...prev,
                [pageNumber]: updatedImages
            };
        });
    };
    // --- Handler for Text Annotations ---
    const handleAddText = (pageNumber, textData)=>{
        setTexts((prev)=>{
            const pageTexts = prev[pageNumber] || [];
            return {
                ...prev,
                [pageNumber]: [
                    ...pageTexts,
                    textData
                ]
            };
        });
    };
    const handleUpdateText = (pageNumber, indexToUpdate, newTextData)=>{
        setTexts((prev)=>{
            const pageTexts = prev[pageNumber] || [];
            const updatedTexts = pageTexts.map((text, idx)=>idx === indexToUpdate ? {
                    ...text,
                    ...newTextData
                } : text);
            return {
                ...prev,
                [pageNumber]: updatedTexts
            };
        });
    };
    // Add this function to remove the text annotation
    const handleRemoveText = (pageNumber, textIndex)=>{
        // Remove the text annotation based on the page number and text index
        setTexts((prevTexts)=>{
            const pageTexts = prevTexts[pageNumber] || [];
            return {
                ...prevTexts,
                [pageNumber]: pageTexts.filter((_, idx)=>idx !== textIndex)
            };
        });
    };
    // --- Update Current Page Based on Scrolling ---
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "PDFViewer.useEffect": ()=>{
            const container = contentRef.current;
            if (!container) return;
            const handleScroll = {
                "PDFViewer.useEffect.handleScroll": ()=>{
                    if (ignoreScrollRef.current) return;
                    const pages = container.querySelectorAll("[id^='page-']");
                    let bestPageNumber = null;
                    let maxVisible = 0;
                    pages.forEach({
                        "PDFViewer.useEffect.handleScroll": (page)=>{
                            const rect = page.getBoundingClientRect();
                            const containerRect = container.getBoundingClientRect();
                            const visibleHeight = Math.max(0, Math.min(rect.bottom, containerRect.bottom) - Math.max(rect.top, containerRect.top));
                            const pageNumber = parseInt(page.id.replace("page-", ""), 10);
                            if (visibleHeight > maxVisible) {
                                maxVisible = visibleHeight;
                                bestPageNumber = pageNumber;
                            }
                        }
                    }["PDFViewer.useEffect.handleScroll"]);
                    if (bestPageNumber !== null) {
                        setCurrentPage({
                            "PDFViewer.useEffect.handleScroll": (prev)=>{
                                if (bestPageNumber !== prev) {
                                    setPageInput(bestPageNumber.toString());
                                    return bestPageNumber;
                                }
                                return prev;
                            }
                        }["PDFViewer.useEffect.handleScroll"]);
                    }
                }
            }["PDFViewer.useEffect.handleScroll"];
            container.addEventListener("scroll", handleScroll);
            return ({
                "PDFViewer.useEffect": ()=>container.removeEventListener("scroll", handleScroll)
            })["PDFViewer.useEffect"];
        }
    }["PDFViewer.useEffect"], []);
    // When pagesToRender updates, check if there is a pending target page to scroll to.
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "PDFViewer.useEffect": ()=>{
            if (targetPage) {
                const timeout = setTimeout({
                    "PDFViewer.useEffect.timeout": ()=>{
                        scrollToPage(targetPage.page, targetPage.instant);
                        setTargetPage(null);
                    }
                }["PDFViewer.useEffect.timeout"], 100);
                return ({
                    "PDFViewer.useEffect": ()=>clearTimeout(timeout)
                })["PDFViewer.useEffect"];
            }
        }
    }["PDFViewer.useEffect"], [
        pagesToRender,
        targetPage
    ]);
    // --- Lazy-Load More Pages When Scrolling Near the End ---
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "PDFViewer.useEffect": ()=>{
            if (!loading && pdf && pagesToRender < numPages && sentinelRef.current) {
                const observer = new IntersectionObserver({
                    "PDFViewer.useEffect": (entries)=>{
                        entries.forEach({
                            "PDFViewer.useEffect": (entry)=>{
                                if (entry.isIntersecting) {
                                    setPagesToRender({
                                        "PDFViewer.useEffect": (prev)=>Math.min(prev + 5, numPages)
                                    }["PDFViewer.useEffect"]);
                                }
                            }
                        }["PDFViewer.useEffect"]);
                    }
                }["PDFViewer.useEffect"], {
                    threshold: 0.1
                });
                observer.observe(sentinelRef.current);
                return ({
                    "PDFViewer.useEffect": ()=>observer.disconnect()
                })["PDFViewer.useEffect"];
            }
        }
    }["PDFViewer.useEffect"], [
        loading,
        pdf,
        pagesToRender,
        numPages
    ]);
    // --- Zoom Handling via Mouse Wheel (with Ctrl key) ---
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "PDFViewer.useEffect": ()=>{
            const container = contentRef.current;
            if (!container) return;
            let lastCall = 0;
            const handleWheel = {
                "PDFViewer.useEffect.handleWheel": (event)=>{
                    if (event.ctrlKey) {
                        event.preventDefault();
                        const now = Date.now();
                        if (now - lastCall < 50) return;
                        lastCall = now;
                        const zoomSensitivity = 0.002;
                        setScale({
                            "PDFViewer.useEffect.handleWheel": (prevScale)=>Math.max(MIN_SCALE, prevScale - event.deltaY * zoomSensitivity)
                        }["PDFViewer.useEffect.handleWheel"]);
                    }
                }
            }["PDFViewer.useEffect.handleWheel"];
            container.addEventListener("wheel", handleWheel, {
                passive: false
            });
            return ({
                "PDFViewer.useEffect": ()=>container.removeEventListener("wheel", handleWheel)
            })["PDFViewer.useEffect"];
        }
    }["PDFViewer.useEffect"], []);
    // --- Pinch-to-Zoom Handling on Touch Devices ---
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "PDFViewer.useEffect": ()=>{
            const container = contentRef.current;
            if (!container) return;
            const handleTouchStart = {
                "PDFViewer.useEffect.handleTouchStart": (e)=>{
                    if (e.touches.length === 2) {
                        const dx = e.touches[0].clientX - e.touches[1].clientX;
                        const dy = e.touches[0].clientY - e.touches[1].clientY;
                        const distance = Math.hypot(dx, dy);
                        pinchStartDistanceRef.current = distance;
                        pinchStartScaleRef.current = scale;
                    }
                }
            }["PDFViewer.useEffect.handleTouchStart"];
            const handleTouchMove = {
                "PDFViewer.useEffect.handleTouchMove": (e)=>{
                    if (e.touches.length === 2 && pinchStartDistanceRef.current) {
                        e.preventDefault();
                        const dx = e.touches[0].clientX - e.touches[1].clientX;
                        const dy = e.touches[0].clientY - e.touches[1].clientY;
                        const currentDistance = Math.hypot(dx, dy);
                        const pinchRatio = currentDistance / pinchStartDistanceRef.current;
                        const TOUCH_SENSITIVITY = 0.8;
                        const adjustedRatio = 1 + (pinchRatio - 1) * TOUCH_SENSITIVITY;
                        const newScale = Math.max(MIN_SCALE, pinchStartScaleRef.current * adjustedRatio);
                        setScale(newScale);
                    }
                }
            }["PDFViewer.useEffect.handleTouchMove"];
            const handleTouchEnd = {
                "PDFViewer.useEffect.handleTouchEnd": (e)=>{
                    if (e.touches.length < 2) {
                        pinchStartDistanceRef.current = null;
                        pinchStartScaleRef.current = null;
                    }
                }
            }["PDFViewer.useEffect.handleTouchEnd"];
            container.addEventListener("touchstart", handleTouchStart, {
                passive: false
            });
            container.addEventListener("touchmove", handleTouchMove, {
                passive: false
            });
            container.addEventListener("touchend", handleTouchEnd, {
                passive: false
            });
            container.addEventListener("touchcancel", handleTouchEnd, {
                passive: false
            });
            return ({
                "PDFViewer.useEffect": ()=>{
                    container.removeEventListener("touchstart", handleTouchStart);
                    container.removeEventListener("touchmove", handleTouchMove);
                    container.removeEventListener("touchend", handleTouchEnd);
                    container.removeEventListener("touchcancel", handleTouchEnd);
                }
            })["PDFViewer.useEffect"];
        }
    }["PDFViewer.useEffect"], [
        scale
    ]);
    // --- Handler for Importing Image (NEW) ---
    const handleImageFileChange = (e)=>{
        const file = e.target.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onloadend = ()=>{
                setImageSrc(reader.result);
            };
            reader.readAsDataURL(file);
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        style: {
            fontFamily: "Arial, sans-serif"
        },
        children: [
            !loading && numPages > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                style: {
                    position: "fixed",
                    top: 0,
                    left: 0,
                    right: 0,
                    padding: "10px 20px",
                    backgroundColor: "black",
                    color: "white",
                    boxShadow: "0 2px 5px rgba(0,0,0,0.3)",
                    zIndex: 1000,
                    textAlign: "center",
                    display: "flex",
                    flexWrap: "wrap",
                    alignItems: "center",
                    justifyContent: "center",
                    gap: "10px",
                    overflowX: "auto"
                },
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: handlePrevious,
                        disabled: currentPage <= 1,
                        children: "Previous"
                    }, void 0, false, {
                        fileName: "[project]/src/app/_components/PDFViewer.jsx",
                        lineNumber: 473,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        children: [
                            "Page ",
                            currentPage,
                            " of ",
                            numPages
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/_components/PDFViewer.jsx",
                        lineNumber: 476,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: handleNext,
                        disabled: currentPage >= numPages,
                        children: "Next"
                    }, void 0, false, {
                        fileName: "[project]/src/app/_components/PDFViewer.jsx",
                        lineNumber: 479,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        children: [
                            "Go to page:",
                            " ",
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                type: "number",
                                min: "1",
                                max: numPages,
                                value: pageInput,
                                onChange: (e)=>setPageInput(e.target.value),
                                style: {
                                    width: "50px",
                                    color: "black"
                                }
                            }, void 0, false, {
                                fileName: "[project]/src/app/_components/PDFViewer.jsx",
                                lineNumber: 484,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: handleGoToPage,
                                children: "Go"
                            }, void 0, false, {
                                fileName: "[project]/src/app/_components/PDFViewer.jsx",
                                lineNumber: 492,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/_components/PDFViewer.jsx",
                        lineNumber: 482,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: handleZoomOut,
                                disabled: scale <= MIN_SCALE,
                                children: "Zoom Out"
                            }, void 0, false, {
                                fileName: "[project]/src/app/_components/PDFViewer.jsx",
                                lineNumber: 495,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                style: {
                                    margin: "0 5px"
                                },
                                children: [
                                    (scale * 100).toFixed(0),
                                    "%"
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/_components/PDFViewer.jsx",
                                lineNumber: 498,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: handleZoomIn,
                                children: "Zoom In"
                            }, void 0, false, {
                                fileName: "[project]/src/app/_components/PDFViewer.jsx",
                                lineNumber: 499,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/_components/PDFViewer.jsx",
                        lineNumber: 494,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            onClick: toggleHighlightMode,
                            style: {
                                backgroundColor: highlightMode ? "yellow" : "white",
                                color: "black"
                            },
                            children: highlightMode ? "Exit Highlight" : "Highlight"
                        }, void 0, false, {
                            fileName: "[project]/src/app/_components/PDFViewer.jsx",
                            lineNumber: 502,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/app/_components/PDFViewer.jsx",
                        lineNumber: 501,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            onClick: togglePrivateInfoMode,
                            style: {
                                backgroundColor: privateInfoMode ? "gray" : "white",
                                color: "black"
                            },
                            children: privateInfoMode ? "Exit Private Info" : "Private Info"
                        }, void 0, false, {
                            fileName: "[project]/src/app/_components/PDFViewer.jsx",
                            lineNumber: 513,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/app/_components/PDFViewer.jsx",
                        lineNumber: 512,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            onClick: toggleImageMode,
                            style: {
                                backgroundColor: imageMode ? "#ADD8E6" : "white",
                                color: "black"
                            },
                            children: imageMode ? "Exit Image" : "Image Annotation"
                        }, void 0, false, {
                            fileName: "[project]/src/app/_components/PDFViewer.jsx",
                            lineNumber: 524,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/app/_components/PDFViewer.jsx",
                        lineNumber: 523,
                        columnNumber: 11
                    }, this),
                    imageMode && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                htmlFor: "image-file",
                                children: "Import Image: "
                            }, void 0, false, {
                                fileName: "[project]/src/app/_components/PDFViewer.jsx",
                                lineNumber: 536,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                id: "image-file",
                                type: "file",
                                accept: "image/*",
                                onChange: handleImageFileChange
                            }, void 0, false, {
                                fileName: "[project]/src/app/_components/PDFViewer.jsx",
                                lineNumber: 537,
                                columnNumber: 15
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/_components/PDFViewer.jsx",
                        lineNumber: 535,
                        columnNumber: 13
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            onClick: toggleTextMode,
                            style: {
                                backgroundColor: textMode ? "#90EE90" : "white",
                                color: "black"
                            },
                            children: textMode ? "Exit Text" : "Text Annotation"
                        }, void 0, false, {
                            fileName: "[project]/src/app/_components/PDFViewer.jsx",
                            lineNumber: 546,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/app/_components/PDFViewer.jsx",
                        lineNumber: 545,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                htmlFor: "highlight-color",
                                children: "Highlight Color: "
                            }, void 0, false, {
                                fileName: "[project]/src/app/_components/PDFViewer.jsx",
                                lineNumber: 558,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                id: "highlight-color",
                                style: {
                                    color: "black"
                                },
                                value: highlightColor,
                                onChange: (e)=>setHighlightColor(e.target.value),
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                        value: "#FFFF00",
                                        children: "Yellow"
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/_components/PDFViewer.jsx",
                                        lineNumber: 565,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                        value: "#00FF00",
                                        children: "Green"
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/_components/PDFViewer.jsx",
                                        lineNumber: 566,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                        value: "#0000FF",
                                        children: "Blue"
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/_components/PDFViewer.jsx",
                                        lineNumber: 567,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                        value: "#FFC0CB",
                                        children: "Pink"
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/_components/PDFViewer.jsx",
                                        lineNumber: 568,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                        value: "#FFA500",
                                        children: "Orange"
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/_components/PDFViewer.jsx",
                                        lineNumber: 569,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/_components/PDFViewer.jsx",
                                lineNumber: 559,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/_components/PDFViewer.jsx",
                        lineNumber: 557,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/_components/PDFViewer.jsx",
                lineNumber: 453,
                columnNumber: 9
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                ref: contentRef,
                style: {
                    height: "calc(100vh - 70px)",
                    overflowY: "auto",
                    padding: "20px",
                    marginTop: "50px",
                    display: "flex",
                    flexDirection: "column",
                    touchAction: "pan-x pan-y"
                },
                children: [
                    loading && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        children: "Loading PDF..."
                    }, void 0, false, {
                        fileName: "[project]/src/app/_components/PDFViewer.jsx",
                        lineNumber: 588,
                        columnNumber: 21
                    }, this),
                    !loading && pdf && Array.from({
                        length: Math.min(pagesToRender, numPages)
                    }, (_, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$_components$2f$PDFPage$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            pdf: pdf,
                            pageNumber: index + 1,
                            scale: scale,
                            estimatedHeight: pageDimensions[index],
                            highlightMode: highlightMode,
                            privateInfoMode: privateInfoMode,
                            imageMode: imageMode,
                            highlights: highlights[index + 1] || [],
                            privateInfos: privateInfos[index + 1] || [],
                            images: images[index + 1] || [],
                            onAddHighlight: handleAddHighlight,
                            onRemoveHighlight: handleRemoveHighlight,
                            onUpdateHighlight: handleUpdateHighlight,
                            onAddPrivateInfo: handleAddPrivateInfo,
                            onRemovePrivateInfo: handleRemovePrivateInfo,
                            onUpdatePrivateInfo: handleUpdatePrivateInfo,
                            onAddImage: handleAddImage,
                            onRemoveImage: handleRemoveImage,
                            onUpdateImage: handleUpdateImage,
                            highlightColor: highlightColor,
                            imageSrc: imageSrc,
                            texts: texts[index + 1] || [],
                            textMode: textMode,
                            onAddText: handleAddText,
                            onUpdateText: handleUpdateText,
                            onRemoveText: handleRemoveText
                        }, index, false, {
                            fileName: "[project]/src/app/_components/PDFViewer.jsx",
                            lineNumber: 594,
                            columnNumber: 15
                        }, this)),
                    !loading && pdf && pagesToRender < numPages && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        ref: sentinelRef,
                        style: {
                            height: "20px"
                        }
                    }, void 0, false, {
                        fileName: "[project]/src/app/_components/PDFViewer.jsx",
                        lineNumber: 626,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/_components/PDFViewer.jsx",
                lineNumber: 576,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/app/_components/PDFViewer.jsx",
        lineNumber: 450,
        columnNumber: 5
    }, this);
};
_s(PDFViewer, "+c7hWkSGICwM9k7LP6xmNndzOBM=");
_c = PDFViewer;
const __TURBOPACK__default__export__ = PDFViewer;
var _c;
__turbopack_refresh__.register(_c, "PDFViewer");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_refresh__.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
}]);

//# sourceMappingURL=src_app__components_a9640b._.js.map