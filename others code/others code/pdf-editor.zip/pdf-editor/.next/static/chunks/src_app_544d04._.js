(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push(["static/chunks/src_app_544d04._.js", {

"[project]/src/app/context/PDFContext.jsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, k: __turbopack_refresh__, m: module, z: __turbopack_require_stub__ } = __turbopack_context__;
{
// PDFContext.jsx
__turbopack_esm__({
    "PDFProvider": (()=>PDFProvider),
    "usePDF": (()=>usePDF)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$pdfjs$2d$dist$2f$build$2f$pdf$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/pdfjs-dist/build/pdf.mjs [app-client] (ecmascript)");
;
var _s = __turbopack_refresh__.signature(), _s1 = __turbopack_refresh__.signature();
"use client";
;
;
// Set PDF.js worker (make sure pdf.worker.js is in your public folder)
__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$pdfjs$2d$dist$2f$build$2f$pdf$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__.GlobalWorkerOptions.workerSrc = "/pdf.worker.js";
// Some constants
const DEFAULT_SCALE = 1.5;
const SCALE_STEP = 0.1;
const MIN_SCALE = 0.1;
const PDFContext = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])();
function PDFProvider({ pdfUrl, children }) {
    _s();
    // Global states (copied from your original PDFViewer)
    const [pdf, setPdf] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [numPages, setNumPages] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    const [pageDimensions, setPageDimensions] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(true);
    const [currentPage, setCurrentPage] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(1);
    const [pageInput, setPageInput] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("1");
    const [pagesToRender, setPagesToRender] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(5);
    const [scale, setScale] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(DEFAULT_SCALE);
    const [highlightMode, setHighlightMode] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [privateInfoMode, setPrivateInfoMode] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [imageMode, setImageMode] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [highlightColor, setHighlightColor] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("#FFFF00");
    const [texts, setTexts] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({}); // per-page text annotations
    const [textMode, setTextMode] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [highlights, setHighlights] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({}); // per-page highlights
    const [privateInfos, setPrivateInfos] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({}); // per-page private info boxes
    const [images, setImages] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({}); // per-page image annotations
    const [imageSrc, setImageSrc] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [targetPage, setTargetPage] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [drawingText, setDrawingText] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [activeTextIndex, setActiveTextIndex] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [textInput, setTextInput] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    // Refs used by the PDF viewer
    const sentinelRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const contentRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const ignoreScrollRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(false);
    const pinchStartDistanceRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const pinchStartScaleRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    // ── PDF LOADING ──────────────────────────────────────────────
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "PDFProvider.useEffect": ()=>{
            setLoading(true);
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$pdfjs$2d$dist$2f$build$2f$pdf$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__.getDocument(pdfUrl).promise.then({
                "PDFProvider.useEffect": (pdfDoc)=>{
                    setPdf(pdfDoc);
                    setNumPages(pdfDoc.numPages);
                    setLoading(false);
                }
            }["PDFProvider.useEffect"]).catch({
                "PDFProvider.useEffect": (error)=>{
                    console.error("Error loading PDF:", error);
                    setLoading(false);
                }
            }["PDFProvider.useEffect"]);
        }
    }["PDFProvider.useEffect"], [
        pdfUrl
    ]);
    // ── PRE-FETCH PAGE DIMENSIONS ──────────────────────────────────
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "PDFProvider.useEffect": ()=>{
            if (pdf && numPages > 0) {
                let cancelled = false;
                const promises = [];
                for(let i = 1; i <= numPages; i++){
                    promises.push(pdf.getPage(i).then({
                        "PDFProvider.useEffect": (page)=>{
                            const viewport = page.getViewport({
                                scale
                            });
                            return viewport.height;
                        }
                    }["PDFProvider.useEffect"]));
                }
                Promise.all(promises).then({
                    "PDFProvider.useEffect": (heights)=>{
                        if (!cancelled) setPageDimensions(heights);
                    }
                }["PDFProvider.useEffect"]);
                return ({
                    "PDFProvider.useEffect": ()=>{
                        cancelled = true;
                    }
                })["PDFProvider.useEffect"];
            }
        }
    }["PDFProvider.useEffect"], [
        pdf,
        numPages,
        scale
    ]);
    // ── AUTOMATIC IMAGE ANNOTATION WHEN AN IMAGE IS IMPORTED ──────────
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "PDFProvider.useEffect": ()=>{
            if (imageSrc) {
                // Add the image to the current page with a default rectangle.
                handleAddImage(currentPage, {
                    x: 0.1,
                    y: 0.1,
                    width: 0.3,
                    height: 0.3,
                    src: imageSrc
                });
                setImageSrc("");
            }
        }
    }["PDFProvider.useEffect"], [
        imageSrc,
        currentPage
    ]);
    // ── NAVIGATION FUNCTIONS ─────────────────────────────────────────
    const scrollToPage = (page, instant = false)=>{
        const pageElement = document.getElementById(`page-${page}`);
        if (pageElement && contentRef.current) {
            const containerRect = contentRef.current.getBoundingClientRect();
            const elementRect = pageElement.getBoundingClientRect();
            const offset = elementRect.top - containerRect.top;
            contentRef.current.scrollTo({
                top: contentRef.current.scrollTop + offset,
                behavior: instant ? "auto" : "smooth"
            });
            ignoreScrollRef.current = true;
            setTimeout(()=>{
                ignoreScrollRef.current = false;
            }, 500);
            setCurrentPage(page);
            setPageInput(page.toString());
        }
    };
    const goToPage = (page, instant = false)=>{
        if (page < 1 || page > numPages) return;
        if (page > pagesToRender) {
            setPagesToRender(page);
            setTargetPage({
                page,
                instant
            });
        } else {
            scrollToPage(page, instant);
        }
    };
    const handlePrevious = ()=>{
        if (currentPage > 1) goToPage(currentPage - 1);
    };
    const handleNext = ()=>{
        if (currentPage < numPages) goToPage(currentPage + 1);
    };
    const handleGoToPage = ()=>{
        const page = Number(pageInput);
        if (!isNaN(page)) goToPage(page, true);
    };
    const handleZoomIn = ()=>setScale((prev)=>prev + SCALE_STEP);
    const handleZoomOut = ()=>setScale((prev)=>Math.max(MIN_SCALE, prev - SCALE_STEP));
    // ── MODE TOGGLES ─────────────────────────────────────────────────
    const toggleHighlightMode = ()=>{
        setHighlightMode((prev)=>!prev);
        if (privateInfoMode) setPrivateInfoMode(false);
        if (imageMode) setImageMode(false);
        if (textMode) setTextMode(false);
    };
    const togglePrivateInfoMode = ()=>{
        setPrivateInfoMode((prev)=>!prev);
        if (highlightMode) setHighlightMode(false);
        if (imageMode) setImageMode(false);
        if (textMode) setTextMode(false);
    };
    const toggleImageMode = ()=>{
        setImageMode((prev)=>!prev);
        if (highlightMode) setHighlightMode(false);
        if (privateInfoMode) setPrivateInfoMode(false);
        if (textMode) setTextMode(false);
    };
    const toggleTextMode = ()=>{
        setTextMode((prev)=>!prev);
        if (highlightMode) setHighlightMode(false);
        if (privateInfoMode) setPrivateInfoMode(false);
        if (imageMode) setImageMode(false);
    };
    // ── HANDLERS FOR HIGHLIGHTS ────────────────────────────────────────
    const handleAddHighlight = (pageNumber, highlightRect)=>{
        setHighlights((prev)=>{
            const pageHighlights = prev[pageNumber] || [];
            return {
                ...prev,
                [pageNumber]: [
                    ...pageHighlights,
                    highlightRect
                ]
            };
        });
    };
    const handleRemoveHighlight = (pageNumber, indexToRemove)=>{
        setHighlights((prev)=>{
            const pageHighlights = prev[pageNumber] || [];
            return {
                ...prev,
                [pageNumber]: pageHighlights.filter((_, idx)=>idx !== indexToRemove)
            };
        });
    };
    const handleUpdateHighlight = (pageNumber, indexToUpdate, newData)=>{
        setHighlights((prev)=>{
            const pageHighlights = prev[pageNumber] || [];
            const updatedHighlights = pageHighlights.map((hl, idx)=>idx === indexToUpdate ? {
                    ...hl,
                    ...newData
                } : hl);
            return {
                ...prev,
                [pageNumber]: updatedHighlights
            };
        });
    };
    // ── HANDLERS FOR PRIVATE INFO BOXES ──────────────────────────────────
    const handleAddPrivateInfo = (pageNumber, boxRect)=>{
        setPrivateInfos((prev)=>{
            const pageBoxes = prev[pageNumber] || [];
            return {
                ...prev,
                [pageNumber]: [
                    ...pageBoxes,
                    boxRect
                ]
            };
        });
    };
    const handleRemovePrivateInfo = (pageNumber, indexToRemove)=>{
        setPrivateInfos((prev)=>{
            const pageBoxes = prev[pageNumber] || [];
            return {
                ...prev,
                [pageNumber]: pageBoxes.filter((_, idx)=>idx !== indexToRemove)
            };
        });
    };
    const handleUpdatePrivateInfo = (pageNumber, indexToUpdate, newRect)=>{
        setPrivateInfos((prev)=>{
            const pageBoxes = prev[pageNumber] || [];
            const updatedBoxes = pageBoxes.map((box, idx)=>idx === indexToUpdate ? {
                    ...box,
                    ...newRect
                } : box);
            return {
                ...prev,
                [pageNumber]: updatedBoxes
            };
        });
    };
    // ── HANDLERS FOR IMAGE ANNOTATIONS ───────────────────────────────────
    const handleAddImage = (pageNumber, imageRect)=>{
        setImages((prev)=>{
            const pageImages = prev[pageNumber] || [];
            return {
                ...prev,
                [pageNumber]: [
                    ...pageImages,
                    imageRect
                ]
            };
        });
    };
    const handleRemoveImage = (pageNumber, indexToRemove)=>{
        setImages((prev)=>{
            const pageImages = prev[pageNumber] || [];
            return {
                ...prev,
                [pageNumber]: pageImages.filter((_, idx)=>idx !== indexToRemove)
            };
        });
    };
    const handleUpdateImage = (pageNumber, indexToUpdate, newRect)=>{
        setImages((prev)=>{
            const pageImages = prev[pageNumber] || [];
            const updatedImages = pageImages.map((img, idx)=>idx === indexToUpdate ? {
                    ...img,
                    ...newRect
                } : img);
            return {
                ...prev,
                [pageNumber]: updatedImages
            };
        });
    };
    // ── HANDLERS FOR TEXT ANNOTATIONS ────────────────────────────────────
    const handleAddText = (pageNumber, textData)=>{
        setTexts((prev)=>{
            const pageTexts = prev[pageNumber] || [];
            return {
                ...prev,
                [pageNumber]: [
                    ...pageTexts,
                    textData
                ]
            };
        });
    };
    const handleUpdateText = (pageNumber, indexToUpdate, newTextData)=>{
        setTexts((prev)=>{
            const pageTexts = prev[pageNumber] || [];
            const updatedTexts = pageTexts.map((text, idx)=>idx === indexToUpdate ? {
                    ...text,
                    ...newTextData
                } : text);
            return {
                ...prev,
                [pageNumber]: updatedTexts
            };
        });
    };
    const handleRemoveText = (pageNumber, textIndex)=>{
        setTexts((prev)=>{
            const pageTexts = prev[pageNumber] || [];
            return {
                ...prev,
                [pageNumber]: pageTexts.filter((_, idx)=>idx !== textIndex)
            };
        });
    };
    // ── PROVIDE ALL STATE AND FUNCTIONS VIA CONTEXT ─────────────────────
    const value = {
        pdf,
        numPages,
        pageDimensions,
        loading,
        currentPage,
        pageInput,
        pagesToRender,
        scale,
        highlightMode,
        privateInfoMode,
        imageMode,
        highlightColor,
        texts,
        textMode,
        highlights,
        privateInfos,
        images,
        imageSrc,
        targetPage,
        drawingText,
        activeTextIndex,
        textInput,
        sentinelRef,
        contentRef,
        ignoreScrollRef,
        pinchStartDistanceRef,
        pinchStartScaleRef,
        setImageSrc,
        setTargetPage,
        setDrawingText,
        setActiveTextIndex,
        setTextInput,
        // Navigation functions
        scrollToPage,
        goToPage,
        handlePrevious,
        handleNext,
        handleGoToPage,
        handleZoomIn,
        handleZoomOut,
        // Mode toggles
        toggleHighlightMode,
        togglePrivateInfoMode,
        toggleImageMode,
        toggleTextMode,
        // Annotation handlers
        handleAddHighlight,
        handleRemoveHighlight,
        handleUpdateHighlight,
        handleAddPrivateInfo,
        handleRemovePrivateInfo,
        handleUpdatePrivateInfo,
        handleAddImage,
        handleRemoveImage,
        handleUpdateImage,
        handleAddText,
        handleUpdateText,
        handleRemoveText,
        // Also expose setters if needed
        setPdf,
        setNumPages,
        setPageInput,
        setPagesToRender,
        setScale,
        setHighlightMode,
        setPrivateInfoMode,
        setImageMode,
        setHighlightColor,
        setTexts,
        setTextMode,
        setHighlights,
        setPrivateInfos,
        setImages
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(PDFContext.Provider, {
        value: value,
        children: children
    }, void 0, false, {
        fileName: "[project]/src/app/context/PDFContext.jsx",
        lineNumber: 372,
        columnNumber: 10
    }, this);
}
_s(PDFProvider, "ftYrfM9e/a63uWqokwOW9myIsrI=");
_c = PDFProvider;
function usePDF() {
    _s1();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(PDFContext);
}
_s1(usePDF, "gDsCjeeItUuvgOWf1v4qoK9RF6k=");
var _c;
__turbopack_refresh__.register(_c, "PDFProvider");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_refresh__.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/app/_components/PDFPage.jsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, k: __turbopack_refresh__, m: module, z: __turbopack_require_stub__ } = __turbopack_context__;
{
// PDFPage.jsx
__turbopack_esm__({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$context$2f$PDFContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/app/context/PDFContext.jsx [app-client] (ecmascript)");
;
var _s = __turbopack_refresh__.signature();
"use client";
;
;
const DEFAULT_FONT_SIZE = 14;
const LONG_PRESS_DURATION = 300;
const MOVE_THRESHOLD = 10;
const PDFPage = ({ pageNumber, scale, estimatedHeight })=>{
    _s();
    const { pdf, highlightMode, privateInfoMode, imageMode, textMode, highlights, privateInfos, images, texts, highlightColor, handleAddHighlight, handleRemoveHighlight, handleUpdateHighlight, handleAddPrivateInfo, handleRemovePrivateInfo, handleUpdatePrivateInfo, handleAddImage, handleRemoveImage, handleUpdateImage, handleAddText, handleUpdateText, handleRemoveText } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$context$2f$PDFContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePDF"])();
    const containerRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const canvasRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const [canvasDimensions, setCanvasDimensions] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        width: 1,
        height: 1
    });
    const [isVisible, setIsVisible] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [loaded, setLoaded] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const renderTaskRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    // Update canvas dimensions on mount and resize.
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "PDFPage.useEffect": ()=>{
            const updateCanvasDimensions = {
                "PDFPage.useEffect.updateCanvasDimensions": ()=>{
                    if (canvasRef.current) {
                        const rect = canvasRef.current.getBoundingClientRect();
                        setCanvasDimensions({
                            width: rect.width,
                            height: rect.height
                        });
                    }
                }
            }["PDFPage.useEffect.updateCanvasDimensions"];
            updateCanvasDimensions();
            window.addEventListener("resize", updateCanvasDimensions);
            return ({
                "PDFPage.useEffect": ()=>window.removeEventListener("resize", updateCanvasDimensions)
            })["PDFPage.useEffect"];
        }
    }["PDFPage.useEffect"], [
        loaded,
        scale
    ]);
    // Reset loaded state when scale or pdf changes.
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "PDFPage.useEffect": ()=>{
            setLoaded(false);
        }
    }["PDFPage.useEffect"], [
        scale,
        pdf
    ]);
    // IntersectionObserver for lazy loading.
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "PDFPage.useEffect": ()=>{
            const observer = new IntersectionObserver({
                "PDFPage.useEffect": (entries)=>{
                    entries.forEach({
                        "PDFPage.useEffect": (entry)=>{
                            if (entry.isIntersecting) {
                                setIsVisible(true);
                                observer.unobserve(entry.target);
                            }
                        }
                    }["PDFPage.useEffect"]);
                }
            }["PDFPage.useEffect"], {
                threshold: 0.1
            });
            if (containerRef.current) observer.observe(containerRef.current);
            return ({
                "PDFPage.useEffect": ()=>{
                    if (containerRef.current) observer.unobserve(containerRef.current);
                }
            })["PDFPage.useEffect"];
        }
    }["PDFPage.useEffect"], []);
    // Load and render the PDF page.
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "PDFPage.useEffect": ()=>{
            let isMounted = true;
            if (isVisible && !loaded) {
                pdf.getPage(pageNumber).then({
                    "PDFPage.useEffect": (page)=>{
                        if (!isMounted) return;
                        const viewport = page.getViewport({
                            scale
                        });
                        const canvas = canvasRef.current;
                        if (!canvas) return;
                        const devicePixelRatio = window.devicePixelRatio || 1;
                        canvas.width = viewport.width * devicePixelRatio;
                        canvas.height = viewport.height * devicePixelRatio;
                        canvas.style.width = `${viewport.width}px`;
                        canvas.style.height = `${viewport.height}px`;
                        const context = canvas.getContext("2d");
                        context.scale(devicePixelRatio, devicePixelRatio);
                        const renderContext = {
                            canvasContext: context,
                            viewport
                        };
                        renderTaskRef.current = page.render(renderContext);
                        renderTaskRef.current.promise.then({
                            "PDFPage.useEffect": ()=>{
                                if (isMounted) setLoaded(true);
                            }
                        }["PDFPage.useEffect"]).catch({
                            "PDFPage.useEffect": (error)=>{
                                if (error && error.name === "RenderingCancelledException") {
                                // Ignore cancellation.
                                } else {
                                    console.error("Error during rendering:", error);
                                }
                            }
                        }["PDFPage.useEffect"]);
                    }
                }["PDFPage.useEffect"]);
            }
            return ({
                "PDFPage.useEffect": ()=>{
                    isMounted = false;
                    if (renderTaskRef.current && renderTaskRef.current.cancel) {
                        renderTaskRef.current.cancel();
                    }
                }
            })["PDFPage.useEffect"];
        }
    }["PDFPage.useEffect"], [
        isVisible,
        loaded,
        pdf,
        pageNumber,
        scale
    ]);
    const getReferenceRect = ()=>{
        if (canvasRef.current) return canvasRef.current.getBoundingClientRect();
        return containerRef.current.getBoundingClientRect();
    };
    const clamp = (val, min, max)=>Math.max(min, Math.min(val, max));
    // (Your mouse and touch event handlers here will use the context functions.)
    // For example, when drawing a new highlight, you might call:
    // handleAddHighlight(pageNumber, normalizedHighlight);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        ref: containerRef,
        id: `page-${pageNumber}`,
        style: {
            marginBottom: "120px",
            position: "relative",
            margin: "0 auto",
            width: "fit-content"
        },
        children: isVisible ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("canvas", {
                    ref: canvasRef,
                    style: {
                        display: "block",
                        opacity: loaded ? 1 : 0,
                        transition: "opacity 0.5s ease-in-out",
                        marginBottom: "20px",
                        pointerEvents: "none"
                    }
                }, void 0, false, {
                    fileName: "[project]/src/app/_components/PDFPage.jsx",
                    lineNumber: 146,
                    columnNumber: 11
                }, this),
                (highlights[pageNumber] || []).map((hl, idx)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        style: {
                            position: "absolute",
                            left: hl.x * canvasDimensions.width,
                            top: hl.y * canvasDimensions.height,
                            width: hl.width * canvasDimensions.width,
                            height: hl.height * canvasDimensions.height,
                            backgroundColor: highlightColor,
                            opacity: 0.3,
                            boxSizing: "border-box",
                            cursor: "pointer"
                        },
                        onMouseDown: (e)=>{
                            e.stopPropagation();
                        // Call handleUpdateHighlight or initiate dragging/resizing as needed.
                        },
                        onClick: (e)=>e.stopPropagation()
                    }, `hl-${idx}`, false, {
                        fileName: "[project]/src/app/_components/PDFPage.jsx",
                        lineNumber: 160,
                        columnNumber: 13
                    }, this))
            ]
        }, void 0, true) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            style: {
                height: estimatedHeight ? `${estimatedHeight}px` : `${scale * 800}px`,
                backgroundColor: "#f0f0f0",
                border: "1px solid #ccc"
            }
        }, void 0, false, {
            fileName: "[project]/src/app/_components/PDFPage.jsx",
            lineNumber: 183,
            columnNumber: 9
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/app/_components/PDFPage.jsx",
        lineNumber: 134,
        columnNumber: 5
    }, this);
};
_s(PDFPage, "bvzIjqaqYx3J7ZkVkZOhXbUECzA=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$context$2f$PDFContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePDF"]
    ];
});
_c = PDFPage;
const __TURBOPACK__default__export__ = PDFPage;
var _c;
__turbopack_refresh__.register(_c, "PDFPage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_refresh__.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/app/_components/PDFViewer.jsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, k: __turbopack_refresh__, m: module, z: __turbopack_require_stub__ } = __turbopack_context__;
{
// PDFViewer.jsx
__turbopack_esm__({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$_components$2f$PDFPage$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/app/_components/PDFPage.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$context$2f$PDFContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/app/context/PDFContext.jsx [app-client] (ecmascript)");
;
var _s = __turbopack_refresh__.signature();
"use client";
;
;
;
const PDFViewerContent = ()=>{
    _s();
    const { pdf, loading, numPages, pagesToRender, currentPage, pageInput, scale, highlightMode, privateInfoMode, imageMode, highlightColor, texts, textMode, contentRef, sentinelRef, pageDimensions, handlePrevious, handleNext, handleGoToPage, handleZoomOut, handleZoomIn, toggleHighlightMode, togglePrivateInfoMode, toggleImageMode, toggleTextMode, setImageSrc, MIN_SCALE } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$context$2f$PDFContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePDF"])();
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        style: {
            fontFamily: "Arial, sans-serif"
        },
        children: [
            !loading && numPages > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                style: {
                    position: "fixed",
                    top: 0,
                    left: 0,
                    right: 0,
                    padding: "10px 20px",
                    backgroundColor: "black",
                    color: "white",
                    boxShadow: "0 2px 5px rgba(0,0,0,0.3)",
                    zIndex: 1000,
                    textAlign: "center",
                    display: "flex",
                    flexWrap: "wrap",
                    alignItems: "center",
                    justifyContent: "center",
                    gap: "10px",
                    overflowX: "auto"
                },
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: handlePrevious,
                        disabled: currentPage <= 1,
                        children: "Previous"
                    }, void 0, false, {
                        fileName: "[project]/src/app/_components/PDFViewer.jsx",
                        lineNumber: 62,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        children: [
                            "Page ",
                            currentPage,
                            " of ",
                            numPages
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/_components/PDFViewer.jsx",
                        lineNumber: 65,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: handleNext,
                        disabled: currentPage >= numPages,
                        children: "Next"
                    }, void 0, false, {
                        fileName: "[project]/src/app/_components/PDFViewer.jsx",
                        lineNumber: 68,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        children: [
                            "Go to page:",
                            " ",
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                type: "number",
                                min: "1",
                                max: numPages,
                                value: pageInput,
                                onChange: (e)=>{
                                /* You can update pageInput via context if desired */ },
                                style: {
                                    width: "50px",
                                    color: "black"
                                }
                            }, void 0, false, {
                                fileName: "[project]/src/app/_components/PDFViewer.jsx",
                                lineNumber: 73,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: handleGoToPage,
                                children: "Go"
                            }, void 0, false, {
                                fileName: "[project]/src/app/_components/PDFViewer.jsx",
                                lineNumber: 83,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/_components/PDFViewer.jsx",
                        lineNumber: 71,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: handleZoomOut,
                                disabled: scale <= MIN_SCALE,
                                children: "Zoom Out"
                            }, void 0, false, {
                                fileName: "[project]/src/app/_components/PDFViewer.jsx",
                                lineNumber: 86,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                style: {
                                    margin: "0 5px"
                                },
                                children: [
                                    (scale * 100).toFixed(0),
                                    "%"
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/_components/PDFViewer.jsx",
                                lineNumber: 89,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: handleZoomIn,
                                children: "Zoom In"
                            }, void 0, false, {
                                fileName: "[project]/src/app/_components/PDFViewer.jsx",
                                lineNumber: 90,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/_components/PDFViewer.jsx",
                        lineNumber: 85,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            onClick: toggleHighlightMode,
                            style: {
                                backgroundColor: highlightMode ? "yellow" : "white",
                                color: "black"
                            },
                            children: highlightMode ? "Exit Highlight" : "Highlight"
                        }, void 0, false, {
                            fileName: "[project]/src/app/_components/PDFViewer.jsx",
                            lineNumber: 93,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/app/_components/PDFViewer.jsx",
                        lineNumber: 92,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            onClick: togglePrivateInfoMode,
                            style: {
                                backgroundColor: privateInfoMode ? "gray" : "white",
                                color: "black"
                            },
                            children: privateInfoMode ? "Exit Private Info" : "Private Info"
                        }, void 0, false, {
                            fileName: "[project]/src/app/_components/PDFViewer.jsx",
                            lineNumber: 104,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/app/_components/PDFViewer.jsx",
                        lineNumber: 103,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            onClick: toggleImageMode,
                            style: {
                                backgroundColor: imageMode ? "#ADD8E6" : "white",
                                color: "black"
                            },
                            children: imageMode ? "Exit Image" : "Image Annotation"
                        }, void 0, false, {
                            fileName: "[project]/src/app/_components/PDFViewer.jsx",
                            lineNumber: 115,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/app/_components/PDFViewer.jsx",
                        lineNumber: 114,
                        columnNumber: 11
                    }, this),
                    imageMode && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                htmlFor: "image-file",
                                children: "Import Image: "
                            }, void 0, false, {
                                fileName: "[project]/src/app/_components/PDFViewer.jsx",
                                lineNumber: 127,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                id: "image-file",
                                type: "file",
                                accept: "image/*",
                                onChange: (e)=>{
                                    const file = e.target.files[0];
                                    if (file) {
                                        const reader = new FileReader();
                                        reader.onloadend = ()=>{
                                            setImageSrc(reader.result);
                                        };
                                        reader.readAsDataURL(file);
                                    }
                                }
                            }, void 0, false, {
                                fileName: "[project]/src/app/_components/PDFViewer.jsx",
                                lineNumber: 128,
                                columnNumber: 15
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/_components/PDFViewer.jsx",
                        lineNumber: 126,
                        columnNumber: 13
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            onClick: toggleTextMode,
                            style: {
                                backgroundColor: textMode ? "#90EE90" : "white",
                                color: "black"
                            },
                            children: textMode ? "Exit Text" : "Text Annotation"
                        }, void 0, false, {
                            fileName: "[project]/src/app/_components/PDFViewer.jsx",
                            lineNumber: 146,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/app/_components/PDFViewer.jsx",
                        lineNumber: 145,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                htmlFor: "highlight-color",
                                children: "Highlight Color: "
                            }, void 0, false, {
                                fileName: "[project]/src/app/_components/PDFViewer.jsx",
                                lineNumber: 157,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                id: "highlight-color",
                                style: {
                                    color: "black"
                                },
                                value: highlightColor,
                                onChange: (e)=>{
                                /* update highlightColor via context if needed */ },
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                        value: "#FFFF00",
                                        children: "Yellow"
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/_components/PDFViewer.jsx",
                                        lineNumber: 166,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                        value: "#00FF00",
                                        children: "Green"
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/_components/PDFViewer.jsx",
                                        lineNumber: 167,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                        value: "#0000FF",
                                        children: "Blue"
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/_components/PDFViewer.jsx",
                                        lineNumber: 168,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                        value: "#FFC0CB",
                                        children: "Pink"
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/_components/PDFViewer.jsx",
                                        lineNumber: 169,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                        value: "#FFA500",
                                        children: "Orange"
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/_components/PDFViewer.jsx",
                                        lineNumber: 170,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/_components/PDFViewer.jsx",
                                lineNumber: 158,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/_components/PDFViewer.jsx",
                        lineNumber: 156,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/_components/PDFViewer.jsx",
                lineNumber: 42,
                columnNumber: 9
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                ref: contentRef,
                style: {
                    height: "calc(100vh - 70px)",
                    overflowY: "auto",
                    padding: "20px",
                    marginTop: "50px",
                    display: "flex",
                    flexDirection: "column",
                    touchAction: "pan-x pan-y"
                },
                children: [
                    loading && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        children: "Loading PDF..."
                    }, void 0, false, {
                        fileName: "[project]/src/app/_components/PDFViewer.jsx",
                        lineNumber: 189,
                        columnNumber: 21
                    }, this),
                    !loading && pdf && Array.from({
                        length: Math.min(pagesToRender, numPages)
                    }, (_, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$_components$2f$PDFPage$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            pageNumber: index + 1,
                            scale: scale,
                            estimatedHeight: pageDimensions[index]
                        }, index, false, {
                            fileName: "[project]/src/app/_components/PDFViewer.jsx",
                            lineNumber: 195,
                            columnNumber: 15
                        }, this)),
                    !loading && pdf && pagesToRender < numPages && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        ref: sentinelRef,
                        style: {
                            height: "20px"
                        }
                    }, void 0, false, {
                        fileName: "[project]/src/app/_components/PDFViewer.jsx",
                        lineNumber: 204,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/_components/PDFViewer.jsx",
                lineNumber: 177,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/app/_components/PDFViewer.jsx",
        lineNumber: 39,
        columnNumber: 5
    }, this);
};
_s(PDFViewerContent, "oK0fJEZ2gH3WinAmB93TrS8iOns=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$context$2f$PDFContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePDF"]
    ];
});
_c = PDFViewerContent;
const PDFViewer = ({ pdfUrl })=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$context$2f$PDFContext$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PDFProvider"], {
        pdfUrl: pdfUrl,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(PDFViewerContent, {}, void 0, false, {
            fileName: "[project]/src/app/_components/PDFViewer.jsx",
            lineNumber: 214,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/app/_components/PDFViewer.jsx",
        lineNumber: 213,
        columnNumber: 5
    }, this);
};
_c1 = PDFViewer;
const __TURBOPACK__default__export__ = PDFViewer;
var _c, _c1;
__turbopack_refresh__.register(_c, "PDFViewerContent");
__turbopack_refresh__.register(_c1, "PDFViewer");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_refresh__.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
}]);

//# sourceMappingURL=src_app_544d04._.js.map