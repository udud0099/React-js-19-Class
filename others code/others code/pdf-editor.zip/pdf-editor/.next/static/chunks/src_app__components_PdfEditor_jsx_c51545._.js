(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push(["static/chunks/src_app__components_PdfEditor_jsx_c51545._.js", {

"[project]/src/app/_components/PdfEditor.jsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, k: __turbopack_refresh__, m: module, z: __turbopack_require_stub__ } = __turbopack_context__;
{
// components/PdfEditor.js
__turbopack_esm__({
    "default": (()=>PdfEditor)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
// Import PDF.js APIs from pdfjs-dist.
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$pdfjs$2d$dist$2f$build$2f$pdf$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/pdfjs-dist/build/pdf.mjs [app-client] (ecmascript)");
;
var _s = __turbopack_refresh__.signature();
;
;
function PdfEditor({ pdfUrl }) {
    _s();
    const canvasRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const containerRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const [pdfDoc, setPdfDoc] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [currentPage, setCurrentPage] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(1);
    // Simple state for annotations – each annotation contains x/y coordinates and text.
    const [annotations, setAnnotations] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    // Step 4.1: Set the PDF.js worker source.
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "PdfEditor.useEffect": ()=>{
            // IMPORTANT: Ensure that pdf.worker.js is placed in your public folder.
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$pdfjs$2d$dist$2f$build$2f$pdf$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalWorkerOptions"].workerSrc = "/pdf.worker.js";
        }
    }["PdfEditor.useEffect"], []);
    // Step 4.2: Load the PDF document on component mount.
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "PdfEditor.useEffect": ()=>{
            async function loadPdf() {
                try {
                    const loadingTask = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$pdfjs$2d$dist$2f$build$2f$pdf$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDocument"])(pdfUrl);
                    const pdf = await loadingTask.promise;
                    setPdfDoc(pdf);
                    // Render the first page.
                    renderPage(pdf, currentPage);
                } catch (error) {
                    console.error("Error loading PDF:", error);
                }
            }
            loadPdf();
        }
    }["PdfEditor.useEffect"], [
        pdfUrl
    ]);
    // Step 4.3: Function to render a specific page.
    async function renderPage(pdf, pageNumber) {
        const page = await pdf.getPage(pageNumber);
        // Set a scale factor for rendering.
        const scale = 1.5;
        const viewport = page.getViewport({
            scale
        });
        const canvas = canvasRef.current;
        const context = canvas.getContext("2d");
        // Adjust canvas size to match the PDF page viewport.
        canvas.width = viewport.width;
        canvas.height = viewport.height;
        const renderContext = {
            canvasContext: context,
            viewport: viewport
        };
        const renderTask = page.render(renderContext);
        await renderTask.promise;
    }
    // Step 4.4: Page navigation handlers.
    async function handlePrevPage() {
        if (pdfDoc && currentPage > 1) {
            const newPage = currentPage - 1;
            setCurrentPage(newPage);
            await renderPage(pdfDoc, newPage);
        }
    }
    async function handleNextPage() {
        if (pdfDoc && currentPage < pdfDoc.numPages) {
            const newPage = currentPage + 1;
            setCurrentPage(newPage);
            await renderPage(pdfDoc, newPage);
        }
    }
    // Step 4.5: Handle clicks on the canvas to add annotations.
    function handleCanvasClick(e) {
        // Get click coordinates relative to the canvas.
        const rect = canvasRef.current.getBoundingClientRect();
        const x = e.clientX - rect.left;
        const y = e.clientY - rect.top;
        // Prompt the user for annotation text.
        const text = prompt("Enter annotation text:");
        if (text) {
            setAnnotations((prev)=>[
                    ...prev,
                    {
                        x,
                        y,
                        text
                    }
                ]);
        }
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        ref: containerRef,
        style: {
            position: "relative",
            display: "inline-block"
        },
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("canvas", {
                ref: canvasRef,
                onClick: handleCanvasClick,
                style: {
                    cursor: "crosshair",
                    display: "block"
                }
            }, void 0, false, {
                fileName: "[project]/src/app/_components/PdfEditor.jsx",
                lineNumber: 94,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(AnnotationLayer, {
                annotations: annotations
            }, void 0, false, {
                fileName: "[project]/src/app/_components/PdfEditor.jsx",
                lineNumber: 101,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                style: {
                    marginTop: "10px"
                },
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: handlePrevPage,
                        disabled: !pdfDoc || currentPage <= 1,
                        children: "Previous Page"
                    }, void 0, false, {
                        fileName: "[project]/src/app/_components/PdfEditor.jsx",
                        lineNumber: 104,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        style: {
                            margin: "0 10px"
                        },
                        children: [
                            "Page ",
                            currentPage,
                            " of ",
                            pdfDoc ? pdfDoc.numPages : "..."
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/_components/PdfEditor.jsx",
                        lineNumber: 107,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: handleNextPage,
                        disabled: !pdfDoc || currentPage >= pdfDoc.numPages,
                        children: "Next Page"
                    }, void 0, false, {
                        fileName: "[project]/src/app/_components/PdfEditor.jsx",
                        lineNumber: 110,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/_components/PdfEditor.jsx",
                lineNumber: 103,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/app/_components/PdfEditor.jsx",
        lineNumber: 89,
        columnNumber: 5
    }, this);
}
_s(PdfEditor, "bk/QOFVwDy2ey0jlWV5i5BgBVB4=");
_c = PdfEditor;
// A simple component that renders annotations as absolutely positioned elements.
function AnnotationLayer({ annotations }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        style: {
            position: "absolute",
            top: 0,
            left: 0,
            pointerEvents: "none",
            width: "100%",
            height: "100%"
        },
        children: annotations.map((ann, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                style: {
                    position: "absolute",
                    left: ann.x,
                    top: ann.y,
                    backgroundColor: "rgba(255,255,0,0.7)",
                    padding: "2px 4px",
                    border: "1px solid #888",
                    borderRadius: "2px",
                    pointerEvents: "auto"
                },
                children: ann.text
            }, index, false, {
                fileName: "[project]/src/app/_components/PdfEditor.jsx",
                lineNumber: 135,
                columnNumber: 9
            }, this))
    }, void 0, false, {
        fileName: "[project]/src/app/_components/PdfEditor.jsx",
        lineNumber: 124,
        columnNumber: 5
    }, this);
}
_c1 = AnnotationLayer;
var _c, _c1;
__turbopack_refresh__.register(_c, "PdfEditor");
__turbopack_refresh__.register(_c1, "AnnotationLayer");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_refresh__.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
}]);

//# sourceMappingURL=src_app__components_PdfEditor_jsx_c51545._.js.map