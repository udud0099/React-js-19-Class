(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_page_71263d.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_page_71263d.js",
  "chunks": [
    "static/chunks/_01d1b7._.js",
    "static/chunks/src_app__components_PDFViewer_jsx_28adea._.js"
  ],
  "source": "dynamic"
});
