import { beforeEach } from 'vitest';

beforeEach(() => {
  document.body.innerHTML = '';
});
