import Block from '../blots/block.js';

class Blockquote extends Block {
  static blotName = 'blockquote';
  static tagName = 'blockquote';
}

export default Blockquote;
