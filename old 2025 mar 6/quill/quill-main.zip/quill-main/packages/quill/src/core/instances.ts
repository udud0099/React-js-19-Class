import type Quill from '../core.js';

export default new WeakMap<Node, Quill>();
