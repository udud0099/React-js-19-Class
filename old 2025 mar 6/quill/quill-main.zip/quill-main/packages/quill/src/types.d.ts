declare module '*.svg' {
  const content: string;
  export default content;
}

declare const QUILL_VERSION: string | undefined;
