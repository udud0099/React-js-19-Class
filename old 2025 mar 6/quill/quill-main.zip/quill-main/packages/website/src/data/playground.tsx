const playground = [
  {
    title: 'Basic setup with snow theme',
    url: '/playground/snow',
  },
  {
    title: 'Using Quill inside a form',
    url: '/playground/form',
  },
  {
    title: 'Custom font and formats',
    url: '/playground/custom-formats',
  },
  {
    title: 'Using Quill with React',
    url: '/playground/react',
  },
];

export default playground;
